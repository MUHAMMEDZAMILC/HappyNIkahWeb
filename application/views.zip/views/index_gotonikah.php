<html>
<head>
<meta charset="UTF-8">

    <title>Goto Nikah | Kerala Muslim Matrimony Site | Nikah Matrimony in Kerala</title>

    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />

    <meta name="description" content="Gotonikah.com is an emerging muslim matrimony site in Kerala that helps Muslim bachelors to find and matchmake with the perfect partner. Nikah matrimony in Kerala">

   <meta name="robots" content="noindex, nofollow">

    <link rel="icon" type="image/png" sizes="32x32" href="<?php echo base_url();?>/happyadmin/assets/images/gotonikh.jpg">

  <!--<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">-->
  
      <meta name="viewport" content="width=device-width, initial-scale=1">
  <!--<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">-->
  

    <link rel="preconnect" href="https://fonts.googleapis.com">

    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

   <link href="https://fonts.googleapis.com/css2?family=Archivo:wght@300;400;500;600;700;900&family=Noto+Sans+Malayalam:wght@400;500;600&family=Poppins:wght@300;400;500;600;700;800;900&family=Roboto:wght@400;500&display=swap" rel="stylesheet">

  
      <link rel="stylesheet" href="<?php echo base_url() ?>assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo base_url() ?>assets/css/owl.carousel.min.css">

    <link rel="stylesheet" href="<?php echo base_url() ?>assets/css/owl.theme.default.min.css">

    <link href="//netdna.bootstrapcdn.com/font-awesome/3.2.1/css/font-awesome.css" rel="stylesheet">
    
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet">




    <link rel="stylesheet" href="<?php echo base_url() ?>assets/css/style.css">

    <!-- Global site tag (gtag.js) - Google Analytics -->

    <script async src="https://www.googletagmanager.com/gtag/js?id=G-X44BV75LEC"></script>

      <link rel="stylesheet" href="<?php echo base_url() ?>assets/css/intlTelInput.css">

    <script>

        window.dataLayer = window.dataLayer || [];



        function gtag() {

            dataLayer.push(arguments);

        }

        gtag('js', new Date());



        gtag('config', 'G-X44BV75LEC');

    </script>

    <!-- Meta Pixel Code -->

    <script>

        ! function(f, b, e, v, n, t, s) {

            if (f.fbq) return;

            n = f.fbq = function() {

                n.callMethod ?

                    n.callMethod.apply(n, arguments) : n.queue.push(arguments)

            };

            if (!f._fbq) f._fbq = n;

            n.push = n;

            n.loaded = !0;

            n.version = '2.0';

            n.queue = [];

            t = b.createElement(e);

            t.async = !0;

            t.src = v;

            s = b.getElementsByTagName(e)[0];

            s.parentNode.insertBefore(t, s)

        }(window, document, 'script',

            'https://connect.facebook.net/en_US/fbevents.js');

        fbq('init', '435890978249652');

        fbq('track', 'PageView');

    </script>

    <noscript><img height="1" width="1" style="display:none" src="https://www.facebook.com/tr?id=435890978249652&ev=PageView&noscript=1" /></noscript>

    <!-- End Meta Pixel Code -->

    <style type="text/css">
    
    #findPartner .connectBtn
    {
        
    }
    
    
        iframe
        {
        margin-left: 22px;
        
        }
        
        #header .nav-link
        {
    color: #000;
        }
    
     @media only screen   
and (min-width: 1030px)   
and (max-width: 1366px)   

    {
       p#headtitle
       {
           font-size:30px;
       }
    } 
    
    
    @media only screen   
and (min-width: 1370px)  
and (max-width: 1605px)  


    {
       p#headtitle
       {
           font-size:30px;
       }
    } 
    
    
    select#countryCode
    {
    -webkit-appearance: menulist!important;
    -moz-appearance: menulist!important;
    -ms-appearance: menulist!important;
    -o-appearance: menulist!important;
    appearance: menulist!important;
    }
    
    div#termsModal
    {
    overflow-y: scroll;
    }
    
    .validationclass {
    
    color: red;
    
    font-size: 12px;
    
    padding: 5px 2px;
    font-weight:700;
    
    }
     .malereq
    {
    font-weight: 700;
    margin-left: 30px;
    }
    .agereq
    {
    margin-left: 160px;
    font-weight: 700;
    
    }
    
    
    .otpInputs {
    
    display: flex;
    
    flex-direction: row;
    
    flex-wrap: wrap;
    
    align-content: space-around;
    
    justify-content: space-evenly;
    
    }
    
    
    
    .errorotp {
    
    text-align: center;
    
    color: red;
    
    background: #ff00000f;
    
    padding: 5px;
    
    }
    
    
    
    .already-member {
    
    float: left;
    
    width: 89px;
    
    font-size: 10px;
    
    color: white;
    
    padding-top: 7px;
    
    }
    
    
    
    .loginbtn {
    
    background: #fdfdfd;
    
    width: 90px;
    
    margin-left: 8px;
    
    padding: 2px 0px;
    
    
    
    }
    
    
    
    #banner .overlay {
    
    background-color: rgb(253 232 232 / 0%);
    
    }
    
    
    
    #more {
    
    display: none;
    
    }
    
    
    
    #banner .bannerPara {
    
    background: #ffffff38;
    
    padding: 15px 4px;
    
    }
    
    
    
    @media only screen and (max-width: 600px) {
    
    .already-member {
    
    float: left;
    
    /*width: 89px;*/
    
    font-size: 10px;
    
    color: white;
    
    }
    
    
    
    .loginbtn {
    
    background: #fdfdfd;
    
    width: 60px;
    
    margin-left: 8px;
    
    padding: 2px 0px;
    
    font-size: 12px;
    
    }
    
    
    
    }
    
    #homeback
    {
    background-color: rgb(90 186 71 / 6%) !important;
    
    /*rgb(255 255 255 / 22%) !important;*/
    }
        
 @media (min-width: 280px) and (max-width: 991px)
    { 
    
    a#headicon
    {
    margin-left:130px;
    }
    
    #header 
    {
    background-color: #ff5b85;
    padding: 0px 0;
    position: absolute;
    }
    
    img#apple{
        margin-left: 0px !important;
    }
    
    .agereq {
    color: red;
    font-size: 12px;
    margin-left: 0px !important;

}
    h2.pOne
    {
        color: #ff5b85 !important;
    }
    
    
    
     #homeback
    {
            /*background-color: #fff !important;*/
            background-color: rgb(255 255 255 / 27%) !important;
    }
    
    p.bannerPara.mb-4.mb-md-0.pe-md-4 
    {
    display: none;
   }
   
   .form-control
   {
           width: 100% !important;
   }
   
   h3.hTwo {
    display: none;
}



label#ml
{
        margin-left: 12px !important;
        margin-top:-12px;
}

input#name
{
    margin-top: 56px !important;
}

input#male
{
    /*margin-left: -4px !important;*/
    
    margin-top: -6px;
    margin-left: -6px !important;
}
label.form-check-label
{
    /*margin-left: 15px !important; */
      margin-left: 0px !important; 
}
.vl
{
margin-left: 70px !important;
    
}
input#female {
margin-left: 80px !important;
}
label#fml
{
 margin-left: 98px !important;   
}
.v2{
    
 border-left: 0px solid #ff5b85 !important;
}
img#ml {
    margin-left: 42px !important;
}
img#fl {
    margin-left: 145px !important;
}
select#user_age
{
   margin-left: -110px !important;   
}

#ctphone
{
    margin-left:-3px !important;
}
select#countryCode
{
    
     /*margin-left: -13px !important;  */
     margin-left: -7px !important;  
}

input#phone 
{
    margin-left: -10px !important;
    width: 111% !important;
    /*margin-top: 13px;*/
     /*margin-left: -13px !important;  */
}


select#country
{
    width:113% !important;
}

select#home_district
{
   width:104% !important; 
}
select#state
{
   width:113% !important;  
}
.regsub
{
    margin-left:82px !important;
}

/*html {*/
/*    overflow-y: hidden;*/
/*    overflow-x: hidden;*/
/*}*/

body
{
   overflow-y: hidden;
    overflow-x: hidden;  
}

.subHead {
    font-size: 24px;
    margin-bottom: 16px;
    margin-top: 30px !important;

}

 img#play
        {
        width: 100% !important;
        position: absolute;
        left: 0px !important;
        top: -540px !important;
        z-index: 1;
        }  
        
         .search
        {
        margin-top:170px;
        }
        
        
        h2.subHead1.mb-4 {
    font-size: 30px !important;
}

#homeDownload .pOne {
    font-size: 18px;
}
#homeDownload .pTwo {
    font-size: 18px;
}
#homeDownload .storeIcon {
    height: 45px !important;
}

.lPull{
    display:none;
}

.search
{
    width: unset;
    margin-left: unset;
}



.mobText.mb-0 {
    font-size: 18px !important;
}
#homeVid
{
    display:none;
}
#homeContact {
    padding: 10px 0;
}

#moblogin

{
    visibility:visible;
}
.already-member
{
color: #fff !important;
width:100px;
}

button#logmob {
    visibility: visible !important;
}
.web-login
{
   visibility: hidden !important;
}

p#txt
{
    font-size:16px !important;
}
p#mob
{
    font-size:16px !important;
}
p#mail_happy
{
  font-size:17px !important;  
}

p#phone_val {
    margin-left: -7px !important;
}

div#gender_field
{
        padding: 18px 12px !important;
}

}
/*Mobile view */


 @media (min-width: 280px) and (max-width:991px)
 {
    input#phone
    {
        /*margin-top: 13px !important;*/
    }
    
    select#countryCode 
    {
    width: 95% !important;
    height:40px;
    }
    
    span#countrycode_val
    {
            margin-left: -117px !important;
    }
 }
 
/*  @media (min-width: 768px) and (max-width:991px)*/
/* {*/
/* select#countryCode */
/*{*/
/*   width:100% !important;*/
/*}*/
/*}*/


html {
    overflow-y: scroll;
    overflow-x: hidden;
}

.subHead 
{
    margin-top:90px;
}


        #moblogin {
    margin-left: -105px;
    visibility: hidden;
}


.already-member
{
color: transparent;
}

button#logmob {
    visibility: hidden;
}
.web-login
{
   visibility: visible;  
}

.modal 
{
  overflow-y: hidden;   
}


    /*@media only screen and (max-width: 600px) */
    /*{*/
    /*#return-to-top */
    /*{*/
    /*display: block !important;*/
    /*}*/
    /*}*/
    </style>

</head>

</head>
   


 <body>
    
    <section id="header" style="background-color: white;padding: 0px 0;position: fixed;top: 0;left: 0;right: 0;z-index: 11;box-shadow: 1px 5px #8e8c8c1c;">

        <nav class="navbar navbar-expand-lg">

            <div class="container">

                <a class="navbar-brand" href="<?php echo site_url('user/gotonikah'); ?>">

         <img src="https://happynikah.com/happyadmin/assets/images/goto nikah logo.png" alt="Go to Nikah" class="gotoNikahlogo" style="width:150px !important;" height="auto">

                </a>



                 <div class="mob-login" id="moblogin">

                    <n class="already-member" style="color:#000;">Already a member?</n>

                    <button type="button" class="btn loginbtn" data-bs-toggle="modal" data-bs-target="#loginModal" id="logmob" style="background: #5ABA47;color:#fff;">
                        Login</button>

                </div>
                
                
                

                <!--<n class="already-member">Already a member?</n><button type="button" class="btn loginbtn" data-bs-toggle="modal" data-bs-target="#loginModal">Login</button>-->

                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarGoToNikah" aria-controls="navbarGoToNikah" aria-expanded="false" aria-label="Toggle navigation">

                    <div class="hamburger" id="hamburger-1">

                        <span class="line" style="background-color:#000;"></span>

                        <span class="line" style="background-color:#000;"></span>

                        <span class="line" style="background-color:#000;"></span>

                    </div>

                </button>

                <div class="collapse navbar-collapse" id="navbarGoToNikah">
                    
                    
                

                    <ul class="navbar-nav mx-auto mb-2 mb-lg-0 mt-3 mt-lg-0">

                        <li class="nav-item">

                            <a class="nav-link active" aria-current="page" href="<?php echo site_url('user/gotonikah'); ?>">Home</a>

                        </li>

                        <li class="nav-item">

                            <a class="nav-link" href="<?php echo site_url('user/about_gotonikah'); ?>">About us</a>

                        </li>
                        
                         

                        <li class="nav-item">

                            <a class="nav-link" href="<?php echo site_url('user/download_gotonikah'); ?>">Download</a>

                        </li>

                        <li class="nav-item">

                            <a class="nav-link" href="<?php echo site_url('user/contactus_gotonikah'); ?>">Contact</a>

                        </li>
                        
                       
                

                    </ul>
                    
                     <div class="d-flex" style="margin-left: 0px;">
                    <a href="javascript:void(0)" style="margin-top: -84px;" id="headicon">
                        <img src="<?php echo base_url() ?>assets/images/appleStoreF.png" alt="appleStore" id="apple" width="auto" height="auto" style="width: 90px;
    margin-bottom: -23px;" class="storeIcon me-3">
                    </a>
                    <a target="_blank" href="https://play.google.com/store/apps/details?id=com.sysol.goto_nikah" style="margin-top: -84px;">
                        <img src="<?php echo base_url() ?>assets/images/playStoreF.png" alt="playStore" width="auto"  style="width:90px;"   height="auto" class="storeIcon">
                    </a>
                </div>

                    <div class="web-login">

                        <n class="already-member" style="color:#000;">Already a member?</n>

                        <button type="button" class="btn loginbtn" data-bs-toggle="modal" data-bs-target="#loginModal" style="background: #5ABA47;width: 90px;margin-left: 8px;
    padding: 2px 0px;color: #ffff;">Login</button>

                    </div>

                    <!--<ul class="d-flex logList align-items-center mb-3 mb-lg-0">-->

                    <!--    <li>Already Member</li>-->

                    <!--    <li>-->

                    <!--        <button type="button" class="btn" data-bs-toggle="modal" data-bs-target="#loginModal">Login</button>-->

                    <!--    </li>-->

                    <!--</ul>-->



                </div>

            </div>

        </nav>

    </section> 
  
     
<div class="registration section-wrap" 
style="background: url(https://happynikah.com/assets/images/Go2Nikahhome.jpg);
    background-repeat: no-repeat;
    background-size: cover;
    background-position: inherit;
    position: static;
    margin-top: 65px;
    padding: 80px 0;">
        
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-5 text-center">

                   <!--  <div class="top-head w-100 text-center">
                        <h3>Register Now for Free!</h3>
                        <p>Find your Special Someone from Lakhs of Verified Profiles</p>
                    </div> -->
                    <p class="bannerPara mb-4 mb-md-0 pe-md-4" id="headtitle" align="center" 
              style="font-weight: 700;background: #d2cacab5;padding: 15px 4px;color: #362a2a;font-size: 92%;display:none;
              position: relative;z-index: 1;/* font-family: 'APPLE_CARDS_ABBAS'; */font-family: "Noto Sans Malayalam", sans-serif;">നിങ്ങള്&zwj;ക്ക് സമാധാനപൂര്&zwj;വ്വം ഒത്തുചേരേണ്ടതിനായി നിങ്ങളില്&zwj; നിന്ന് തന്നെ നിങ്ങള്&zwj;ക്ക് ഇണകളെ സൃഷ്ടിക്കുകയും, നിങ്ങള്&zwj;ക്കിടയില്&zwj; സ്നേഹവും കാരുണ്യവും ഉണ്ടാക്കുകയും ചെയ്തതും അവന്റെ ദൃഷ്ടാന്തങ്ങളില്&zwj; പെട്ടതത്രെ. തീര്&zwj;ച്ചയായും അതില്&zwj; ചിന്തിക്കുന്ന ജനങ്ങള്&zwj;ക്ക് ദൃഷ്ടാന്തങ്ങളുണ്ട് <br><span class="verse-number"> (വിശുദ്ധ ഖുര്&zwj;ആന്&zwj; 30:21)</span></p>
            
            </div>
                
                
              <div class="col-lg-7">
                    <!-- <div class="top-head w-100   text-center">
                         <img src="https://www.waytonikah.com/images/waytonikah/reg-step-01.png" class="img-fluid side-img" alt="image">
                    </div> -->


                    <div class="form-reg position-relative">


                        <div class="shadow"></div>

                        <div class="content bg-white position-relative" id="homeback" style="margin-top:-30px;">

                          <div class="regHeadBar mb-4">

                        <div class="regHeadBox borderRight d-flex align-items-center">
                        <!--style="border-right: 2px solid #ff5b85;padding-right: 15px;"-->

                            <div class="w-100 register-heading-desk">
                             <h2 align="left" style="font-size:31px;font-weight:750; font-family: ;width: 100%;color:#065006;margin-top:34px;">No.1 Choice for Muslim Matrimony</h2>
                            
                        </div>

                        </div>
                        
                        
                  
        

                        <div class="regHeadBox borderRight d-flex align-items-center" style="border-right: 0px solid transparent;padding-right: 15px;margin-top: -90px;margin-left: 4px;">

                        <span style="color:#c50909;font-size:19px;font-weight: 600;margin-top:95px;">It's free!...</span>
                              <span style="color:#000;font-size:19px;font-weight: 600;margin-top:95px;">Register Now</span>
                        

                        </div>

                        <!--<div class="regHeadBox d-flex align-items-center">-->

                        <!--    <div class="">-->

                        <!--        <p class="pTwo">Register using</p>-->

                        <!--        <div class="d-flex justify-content-lg-between">-->

                        <!--            <a href="javascript:void(0);" class="regalterIcon me-4">-->

                        <!--                <img src="https://happynikah.com/assets/images/google.png" class="regalterIcon" width="auto" height="auto" alt="google">-->

                        <!--            </a>-->

                        <!--            <a href="javascript:void(0);" class="regalterIcon">-->

                        <!--                <img src="https://happynikah.com/assets/images/facebook.png" width="auto" height="auto" alt="facebook">-->

                        <!--            </a>-->

                        <!--        </div>-->

                        <!--    </div>-->

                        <!--</div>-->

                    </div>
    <form  method="post" class="col-12" onsubmit="if (!window.__cfRLUnblockHandlers) return false; return ValidationBasic();">
    <div class="row">
    
    
    
    
    <div class="col-md-12">
    <div class="form-group">
    
    <input type="text" class="form-control" id="name"   name="name" onkeypress="if (!window.__cfRLUnblockHandlers) return false; return lettersOnly(event)" placeholder="Bride / Groom Name *" style="display: block;
    width: 90%;
    padding: 0.375rem 0.75rem;
    font-size: 1rem;
    font-weight: 400;
    border-radius: 10px !important;
    line-height: 1.5;
    color: #212529;
    background-color: #fff;
    background-clip: padding-box;
    border: 1px solid #ced4da;
    -webkit-appearance: none;
    -moz-appearance: none;
    appearance: none;
    border-radius: 0.25rem;
    transition: border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;margin-bottom: 0px;
    margin-top:-24px;">
    <p id="name_val" class="validationclass"></p>
    </div>
    </div>
    
    <div class="col-md-12" style="">
    
    
    <div class="form-control" style="width:90%;border-radius: 10px;" id="gender_field">
    
    <input class="form-check-input" type="radio" name="gender" id="male" value="1" style="margin-left: 6px;">
    
    <label class="form-check-label" for="male" style="margin-left: 32px;" id="ml">Male </label>
    
    <img style="margin-left: 74px;margin-top: -23px;" src="https://happynikah.com/assets/images/male.jpg"  id="ml" alt="male" width="24px" height="24px">
    
    <!-- <img style="margin-left: px;" src="https://happynikah.com/assets/images/vertical.svg" alt="vertical"  width="24px" height="24px"> -->
    
    <!--<span id="ml" style="border-left: 2px solid #ff5b85;height: 1rem !important;margin-left: 14px;padding-top: 30px;line-height: 20px;padding-bottom: 20px;"></span>-->
    
    <div class="vl" style="border-left: 2px solid #5aba47;height: 35px;margin-left: 127px;margin-top: -28px;"></div>
    
    
    <input class="form-check-input" type="radio" name="gender" id="female" value="2" style="margin-left: 151px;margin-top: -23px;">
    
    <label class="form-check-label" for="female" style="margin-top: -28px;margin-left: 183px;" id="fml">Female</label>
    
    <img style="margin-left: 240px;margin-top: -27px;" src="https://happynikah.com/assets/images/female_new.jpg" id="fl" alt="male" width="24px" height="24px">
    
    <!--<span style="border-left: 2px solid #ff5b85;height: 24px;margin-left:10px;padding-top: 35px;padding-bottom:12px;"></span>-->
    
    <div class="v2" style="border-left: 2px solid #5aba47;height: 36px;margin-left: 292px;margin-top: -36px;">
    
    
    <select style="width: auto;margin-left: 53px;margin-top: 6px;border: none;background-color: white;" name="user_age" id="user_age" class="">
    
    <option value="">Age</option>
    
    
    
    </select>
    
    <img style="margin-left: 5px; color:#0892FD;" src="https://happynikah.com/assets/images/calendar.png" alt="calendar" width="24px" height="24px;">
    
    </div>
    
  
    
    <span>
    
    
    </span>  
    
    </div>
    
    <span class="malereq" id="malereq"></span>
    
    <span class="femalereq"></span>
    
    <span class="agereq" id="agereq"></span>
    
    </div>
    
    
    <div class="row" style="margin-left: -8px;margin-top:20px;" id="ctphone">
    
    <div class="col-lg-4 col-4">
    
    <select style="width: 85%;    border-radius: 10px;" name="countryCode" id="countryCode" class="cusform-control code-country" required="">
    
    <!-- <img src="https://happynikah.com/assets/images/in.svg" width="24px" height="24px"> -->
    
    <option value="0">ISD</option>
    
    <option value="91-10">+91</option>
    
    
    <option value="973-8">+973</option>
    
    
    <option value="965-8">+965</option>
    
    
    <option value="968-8">+968</option>
    
    
    <option value="974-8">+974</option>
    
    
    <option value="966-9">+966</option>
    
    
    <option value="971-9">+971</option>
    
    </select>
    
    </div>
    
    <div class="col-lg-8 col-8">
    
    <!-- <label class="form-label me-4 mb-0 reg_label">Phone:</label> -->
    
    <!--<input style="margin-left: -74px;width: 113%;" type="text" class="cusform-control" placeholder="Phone Number" id="phone" name="phone" maxlength="10" onkeypress="if (!window.__cfRLUnblockHandlers) return false; if (!window.__cfRLUnblockHandlers) return false; if (!window.__cfRLUnblockHandlers) return false; return event.charCode > 47 &amp;&amp; event.charCode < 58;">-->
    
    
    <input style="width: 90%;border-radius: 10px;" type="text" class="cusform-control" placeholder="Phone Number" id="phone" name="phone" maxlength="10" onkeypress="if (!window.__cfRLUnblockHandlers) return false; if (!window.__cfRLUnblockHandlers) return false; if (!window.__cfRLUnblockHandlers) return false; return event.charCode > 47 &amp;&amp; event.charCode < 58;">


    <span id="countrycode_val" style="color: red;font-size: 12px;margin-left: -174px;font-weight: 700;"></span>
    
    <br>
    
    <p style="margin-left: 20px;margin-top: -17px;" id="phone_val" class="validationclass"></p>
    
    </div>
    <?php $country= $this->db->select('*')->from('tbl_country')->get()->result_array();?>
                                                <div class="row">
                                                <div class="col-12 col-md-6 mb-3">
                                                    <!--<label class="form-label">Country</label>-->
                                                     <select id="country" class="form-control form-select" name="country" required>
                                                      <option value="">--Please select a Country--</option>
                                                      <?php foreach ($country as $value) { ?>
                                                        <option value="<?php echo $value['id'] ?>" ><?php echo $value['name']; ?></option> 
                                                      <?php } ?>
                                                    </select>     
                                                    <p id="country_val" ></p>

                                                </div>
                                                 
                                                  <div class="col-12 col-md-6 mb-3">
                                                    
                                                  <select id="state" class="form-control form-select" name="state" style="width:96%;" required>
                                                    <option value="">--Please select a State--</option>
                                                       
                                                    </select>
                                                  <p id="state_val" ></p>

                                                </div>
                                                </div>
                                                 <div class="col-12 col-md-6 mb-3">
                                                    <select id="home_district" class="form-control form-select" name="home_district"  style="width:95%;"  required>
                                                          <option value="">--Please select a District--</option>
                                                        </select>  
                                                        <p id="home_district_val" ></p>

                                                </div>
    
    
    
    
    <!-- <div class="col-lg-6 col-md-6">
    
    <label class="form-label me-4 mb-0 reg_label">Email:</label>
    
    <input type="email" class="form-control" placeholder="abc@mail.com" name="email" id="email">
    
    <p id="email_val" class="validationclass"></p>
    
    </div> -->
    
    
    
    </div>
    
    
    
    
    
    
    
    
    
    
    
                        
                                <!--<div class="col-md-6">-->
                                <!--<div class="form-group">-->
                                <!--<label for="">Phone Number *</label>-->
                                <!--<div class="row phone-row">-->
                                <!--<div class="col-auto">-->
                                <!--<div class="select-wrap">-->
                                <!--<select class="form-control isd-input" id="txtcntycode" name="Countrycode">-->
                                <!--<option value="">ISD</option>-->
                                
                                <!--<optgroup label="Frequent Countries"><option value="4">Afghanistan (+93)</option><option value="5">Algeria (+213)</option><option value="94">Australia (+61)</option><option value="21">Bangladesh (+880)</option><option value="15">Bahrain (+973)</option><option value="34">Canada (+1)</option><option value="58">Egypt (+20)</option><option value="72">France (+33)</option><option value="12">India (+91)</option><option value="93">Indonesia (+62)</option><option value="95">Iran (+98)</option><option value="103">Jordan (+962)</option><option value="110">Kuwait (+965)</option><option value="140">Malaysia (+60)</option><option value="113">Morocco (+212)</option><option value="137">Oman (+968)</option><option value="159">Pakistan (+92)</option><option value="165">Qatar (+974)</option><option value="171">Saudi Arabia (+966)</option><option value="181">Singapore (+65)</option><option value="175">South Africa (+27)</option><option value="35">Sri Lanka (+94)</option><option value="199">Tunisia (+216)</option><option value="3">UAE (+971)</option><option value="207">United Kingdom (+44)</option><option value="209">United States of America (+1)</option><option value="" disabled=""></option></optgroup>  <option value="4">Afghanistan (93)</option>  <option value="218">Aland Islands(358)</option>  <option value="7">Albania (355)</option>  <option value="5">Algeria (213)</option>  <option value="223">American Samoa (684)</option>  <option value="9">Andorra (376)</option>  <option value="10">Angola (244)</option>  <option value="14">Anguilla (1)</option>  <option value="239">Antarctica (672)</option>  <option value="2">Antigua and Barbuda (1)</option>  <option value="11">Argentina (54)</option>  <option value="8">Armenia (374)</option>  <option value="1">Aruba (297)</option>  <option value="94">Australia (61)</option>  <option value="13">Austria (43)</option>  <option value="6">Azerbaijan (994)</option>  <option value="20">Bahamas (1)</option>  <option value="15">Bahrain (973)</option>  <option value="21">Bangladesh (880)</option>  <option value="16">Barbados (1)</option>  <option value="27">Belarus (375)</option>  <option value="19">Belgium (32)</option>  <option value="22">Belize (501)</option>  <option value="26">Benin (229)</option>  <option value="18">Bermuda (1)</option>  <option value="30">Bhutan (975)</option>  <option value="24">Bolivia (591)</option>  <option value="23">Bosnia and Herzegovina (387)</option>  <option value="17">Botswana (267)</option>  <option value="29">Brazil (55)</option>  <option value="32">Brunei(673)</option>  <option value="31">Bulgaria (359)</option>  <option value="210">Burkina Faso (226)</option>  <option value="33">Burundi (257)</option>  <option value="35">Cambodia (855)</option>  <option value="44">Cameroon (237)</option>  <option value="34">Canada (1)</option>  <option value="50">Cape Verde (238)</option>  <option value="42">Cayman Islands (1)</option>  <option value="48">Central African Republic (236)</option>  <option value="36">Chad (235)</option>  <option value="41">Chile (56)</option>  <option value="40">China (86)</option>  <option value="109">Christmas Island (672)</option>  <option value="43">Cocos (Keeling) Islands(891)</option>  <option value="46">Colombia (57)</option>  <option value="45">Comoros (269)</option>  <option value="38">Congo (242)</option>  <option value="39">Congo,The Democratic Republic(243)</option>  <option value="51">Cook Islands (682)</option>  <option value="47">Costa Rica (506)</option>  <option value="98">Cote d'Ivoire(225)</option>  <option value="90">Croatia (385)</option>  <option value="49">Cuba (53)</option>  <option value="52">Cyprus (357)</option>  <option value="65">Czech Republic (420)</option>  <option value="53">Denmark (45)</option>  <option value="54">Djibouti (253)</option>  <option value="55">Dominica (1)</option>  <option value="56">Dominican Republic (1)</option>  <option value="57">Ecuador (593)</option>  <option value="58">Egypt (20)</option>  <option value="63">El Salvador (503)</option>  <option value="60">Equatorial Guinea (240)</option>  <option value="62">Eritrea (291)</option>  <option value="61">Estonia (372)</option>  <option value="64">Ethiopia (251)</option>  <option value="69">Falkland Islands (Malvinas)(500)</option>  <option value="70">Faroe Islands (298)</option>  <option value="68">Fiji (679)</option>  <option value="67">Finland (358)</option>  <option value="72">France (33)</option>  <option value="66">French Guiana (594)</option>  <option value="71">French Polynesia (689)</option>  <option value="74">Gabon (241)</option>  <option value="73">Gambia (220)</option>  <option value="75">Georgia (995)</option>  <option value="81">Germany (49)</option>  <option value="76">Ghana (233)</option>  <option value="77">Gibraltar (350)</option>  <option value="83">Greece (30)</option>  <option value="80">Greenland (299)</option>  <option value="78">Grenada (1)</option>  <option value="82">Guadeloupe (590)</option>  <option value="227">Guam (1)</option>  <option value="84">Guatemala (502)</option>  <option value="79">Guernsey(44)</option>  <option value="85">Guinea (224)</option>  <option value="164">Guinea-Bissau (245)</option>  <option value="86">Guyana (592)</option>  <option value="87">Haiti (509)</option>  <option value="89">Honduras (504)</option>  <option value="88">Hong Kong (852)</option>  <option value="91">Hungary (36)</option>  <option value="92">Iceland (354)</option>  <option value="12">India (91)</option>  <option value="93">Indonesia (62)</option>  <option value="95">Iran(98)</option>  <option value="99">Iraq (964)</option>  <option value="59">Ireland (353)</option>  <option value="228">Isle of Man(44)</option>  <option value="96">Israel (972)</option>  <option value="97">Italy (39)</option>  <option value="102">Jamaica (1)</option>  <option value="100">Japan (81)</option>  <option value="229">Jersey(44)</option>  <option value="103">Jordan (962)</option>  <option value="111">Kazakhstan (7)</option>  <option value="104">Kenya (254)</option>  <option value="107">Kiribati (686)</option>  <option value="110">Kuwait (965)</option>  <option value="105">Kyrgyzstan (996)</option>  <option value="112">Lao People's (856)</option>  <option value="240">Laos (856)</option>  <option value="114">Latvia (371)</option>  <option value="113">Lebanon (961)</option>  <option value="119">Lesotho (266)</option>  <option value="116">Liberia (231)</option>  <option value="121">Libya (218)</option>  <option value="118">Liechtenstein (423)</option>  <option value="115">Lithuania (370)</option>  <option value="120">Luxembourg (352)</option>  <option value="124">Macao(853)</option>  <option value="130">Macedonia(389)</option>  <option value="122">Madagascar (261)</option>  <option value="129">Malawi (265)</option>  <option value="140">Malaysia (60)</option>  <option value="138">Maldives (960)</option>  <option value="131">Mali (223)</option>  <option value="136">Malta (356)</option>  <option value="231">Marshall Islands (692)</option>  <option value="123">Martinique (596)</option>  <option value="135">Mauritania (222)</option>  <option value="134">Mauritius (230)</option>  <option value="126">Mayotte (269)</option>  <option value="139">Mexico (52)</option>  <option value="101">Micronesia, Federated States of(691)</option>  <option value="125">Moldova(373)</option>  <option value="132">Monaco (377)</option>  <option value="127">Mongolia (976)</option>  <option value="230">Montenegro(382)</option>  <option value="128">Montserrat (1)</option>  <option value="133">Morocco (212)</option>  <option value="141">Mozambique (258)</option>  <option value="25">Myanmar (95)</option>  <option value="217">Namibia (264)</option>  <option value="151">Nauru (674)</option>  <option value="150">Nepal (977)</option>  <option value="148">Netherlands (31)</option>  <option value="153">Netherlands Antilles (599)</option>  <option value="142">New Caledonia (687)</option>  <option value="155">New Zealand (64)</option>  <option value="154">Nicaragua (505)</option>  <option value="145">Niger (227)</option>  <option value="147">Nigeria (234)</option>  <option value="143">Niue (683)</option>  <option value="144">Norfolk Island(672)</option>  <option value="108">North Korea(82)</option>  <option value="232">Northern Mariana Islands (1)</option>  <option value="149">Norway (47)</option>  <option value="137">Oman (968)</option>  <option value="159">Pakistan (92)</option>  <option value="235">Palau (680)</option>  <option value="234">Palestine(970)</option>  <option value="161">Panama (507)</option>  <option value="163">Papua New Guinea (675)</option>  <option value="156">Paraguay (595)</option>  <option value="158">Peru (51)</option>  <option value="168">Philippines (63)</option>  <option value="157">Pitcairn(64)</option>  <option value="160">Poland (48)</option>  <option value="162">Portugal (351)</option>  <option value="233">Puerto Rico (1)</option>  <option value="165">Qatar (974)</option>  <option value="166">Reunion (262)</option>  <option value="167">Romania (40)</option>  <option value="169">Russian Federation(7)</option>  <option value="170">Rwanda (250)</option>  <option value="177">Saint Helena(290)</option>  <option value="173">Saint Kitts and Nevis(1869)</option>  <option value="184">Saint Lucia (1)</option>  <option value="172">Saint Pierre and Miquelon(508)</option>  <option value="213">Saint Vincent and the Grenadines(1-784)</option>  <option value="221">Samoa (685)</option>  <option value="180">San Marino (378)</option>  <option value="198">Sao Tome and Principe (239)</option>  <option value="171">Saudi Arabia (966)</option>  <option value="176">Senegal (221)</option>  <option value="236">Serbia(381)</option>  <option value="174">Seychelles (248)</option>  <option value="179">Sierra Leone (232)</option>  <option value="181">Singapore (65)</option>  <option value="117">Slovakia (421)</option>  <option value="178">Slovenia (386)</option>  <option value="28">Solomon Islands(677)</option>  <option value="182">Somalia (252)</option>  <option value="175">South Africa (27)</option>  <option value="188">South Georgia(500)</option>  <option value="106">South Korea(82)</option>  <option value="183">Spain (34)</option>  <option value="37">Sri Lanka (94)</option>  <option value="185">Sudan (249)</option>  <option value="152">Suriname (597)</option>  <option value="186">Svalbard(47)</option>  <option value="222">Swaziland (268)</option>  <option value="187">Sweden (46)</option>  <option value="190">Switzerland (41)</option>  <option value="189">Syria(963)</option>  <option value="203">Taiwan(886)</option>  <option value="193">Tajikistan (992)</option>  <option value="205">Tanzania(255)</option>  <option value="192">Thailand (66)</option>  <option value="200">Timor-Leste(670)</option>  <option value="197">Togo (228)</option>  <option value="195">Tokelau (690)</option>  <option value="196">Tonga (676)</option>  <option value="191">Trinidad and Tobago(1 (868))</option>  <option value="199">Tunisia (216)</option>  <option value="201">Turkey (90)</option>  <option value="204">Turkmenistan (993)</option>  <option value="194">Turks and Caicos Islands(1‑649)</option>  <option value="202">Tuvalu (688)</option>  <option value="206">Uganda (256)</option>  <option value="208">Ukraine (380)</option>  <option value="3">United Arab Emirates (971)</option>  <option value="207">United Kingdom (44)</option>  <option value="209">United States(1)</option>  <option value="211">Uruguay (598)</option>  <option value="212">Uzbekistan (998)</option>  <option value="146">Vanuatu (678)</option>  <option value="238">Vatican City (379)</option>  <option value="214">Venezuela (58)</option>  <option value="216">Vietnam (84)</option>  <option value="215">Virgin Islands, British(1284)</option>  <option value="237">Virgin Islands, U.S.(1340)</option>  <option value="219">Wallis and Futuna(681)</option>  <option value="220">Western Sahara (212)</option>  <option value="224">Yemen (967)</option>  <option value="241">Yugoslavia (Former) (381)</option>  <option value="225">Zambia (260)</option>  <option value="226">Zimbabwe (263)</option>   -->
                                
                                <!--</select>-->
                                <!--</div>-->
                                <!--</div>-->
                                <!--<div class="col">-->
                                <!--<input type="number" class="form-control" id="txtMobile" name="Mobile" placeholder="Phone Number">-->
                                <!--</div>-->
                                <!--</div>-->
                                <!--</div>-->
                                <!--</div>-->
                                
                                
                                <!--<div class="col-md-6">-->
                                <!--<div class="form-group">-->
                                <!--<label class="radio-label" for="">Gender *</label>-->
                                <!--<div class="custom-control custom-radio custom-control-inline">-->
                                <!--<input type="radio" id="customRadioInline1" value="Male" name="Gender" class="custom-control-input">-->
                                <!--<label class="custom-control-label" for="customRadioInline1">Male</label>-->
                                <!--</div>-->
                                <!--<div class="custom-control custom-radio custom-control-inline">-->
                                <!--<input type="radio" id="customRadioInline2" name="Gender" value="Female" class="custom-control-input">-->
                                <!--<label class="custom-control-label" for="customRadioInline2">Female</label>-->
                                <!--</div>-->
                                <!--<div class="errorlabel" id="gendererror"></div>-->
                                <!--</div>-->
                                <!--</div>-->
                                        
                                        
                               
                               <div class="d-sm-flexs justify-content-between align-items-center">

                            <div class="form-check mb-4 mb-sm-01">

                                <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault"  required>

                              <label class="form-check-label" for="flexCheckDefault" id="chk" style="COLOR: #020202;margin-left: 0px;">
                            I have read and agree to the <a href="#" data-bs-toggle="modal" data-bs-target="#termsModal">Terms and Condition</a></label>
                                <p class="validationclass" id="terms_val"></p>

                                <span id="error-mob" class="alrdyreg"></span>

                            </div>

                            

                        </div>
                        
                        <!--<div class="col-md-6  mt-5 ">-->
                        <!--<div class="form-group bottom-row">-->
                        <!--<button type="submit" class="button primary-button w-100">Next</button>-->
                        <!--</div>-->
                        <!--</div>-->
                                        
            <div class="regsub" style="margin-left:172px;">
            
            <button type="button" onclick="if (!window.__cfRLUnblockHandlers) return false; if (!window.__cfRLUnblockHandlers) return false; checkvalidation()" 
            class="btn cstmBtnColrs registernow" style="background-color: #5ABA47;color:#fff;margin-left: -155px;margin-top: -9px;">
                Register Now</button>
            
            
            
            <button type="submit" id="submitbtn" class="btn cstmBtnColr" style="display:none;">REG</button>
            
            </div>
            
            </div>
            </form>
            
            
            </div>
            </div>
            <!--<p class="text-center mt-4">Already have an account? <a href="https://www.waytonikah.com/login">Login</a></p>-->
            </div>
            
            
            </div>
            </div>
            </div>
            
            
            
            
              <a href="https://wa.me/+918943777666" class="btn btn-success"  id="whatsapp55"   style="border-radius: 20px;width: 60px;float: right;
                    text-decoration: none;background-color: #0da738;border-color: #0da738;margin-top: -562px;display: inline;margin-right: 10px;">
                    <i class="fab fa-whatsapp" style="font-size: 30px;"></i>
                    <!--WhatsApp-->
                    </a>
                    
                    
                    <a href="tel:+918943777666" class="btn btn-primary mr-2" style="border-radius: 20px;width: 60px;float: right;text-decoration: none;
                    background-color: #0d6efd;border-color: #0d6efd;margin-top: -500px;display: inline;margin-right: 10px;"  id="call55">
                    <i class="fas fa-phone-alt" style="font-size: 30px;"></i> 
                    <!--Call-->
                    </a>

    
  



    <section id="homeAbout" style="background: #f9f9ff;">

    <div class="container">

        <div class="row">

            <div class="col-12 col-md-10 mx-auto text-center">

                <h2 class="subHead">Get ready <span style="color:#5ABA47;">with us</span></h2>

                <p class="para1 mb-5">Goto Nikah is India’s most trusted and user friendly online matrimony portal for Muslims.

                    Goto Nikah has helped thousands of Muslim singles to find their perfect soul mate.</p>

            </div>

        </div>

        <div class="row mt-5">

            <div class="col-12 col-sm-12 col-lg-3 text-center mb-4 mb-lg-0">

                <img src="<?php echo base_url() ?>assets/images/Trusted_goto.png" alt="Trusted Matrimonial Service" width="auto" height="auto" class="readyIcon">

                <h3>No.1 & Trusted</br>Matrimonial Service</h3>

                <p>Our largest number of profiles<br>increases your chances.</p>

            </div>

            <div class="col-12 col-sm-12 col-lg-3 text-center mb-4 mb-lg-0">

                <img src="<?php echo base_url() ?>assets/images/Charge_goto.png" alt="No Charge for Registration" width="auto" height="auto" class="readyIcon">

                <h3>No Charge for</br>Registration</h3>

                <p>Registering with us is completely<br>free and simple.</p>

            </div>

            <div class="col-12 col-sm-12 col-lg-3 text-center mb-4 mb-sm-0">

                <img src="<?php echo base_url() ?>assets/images/Validation_goto.png" alt="Manual Screening and Validation" width="auto" height="auto" class="readyIcon">

                <h3>Manual Screening</br>and Validation</h3>

                <p>Our experts manually screen<br>and validate each profile.</p>

            </div>

            <div class="col-12 col-sm-12 col-lg-3 text-center">

                <img src="<?php echo base_url() ?>assets/images/Security_goto.png" alt="Best Data Security and Privacy" width="auto" height="auto" class="readyIcon">

                <h3>Best Data Security</br>and Privacy</h3>

                <p>We follow best practices to<br>keep your data safe.</p>

            </div>

        </div>

    </div>

</section>

 


<section id="findPartner" style="background: #f9f9ff;">

    <div class="container">

        <div class="row mb-4">

            <div class="col-12 col-md-10 mx-auto text-center">

                <h2 class="subHead" style="margin-top: 30px;"><svg style="margin-bottom: 45px;color:#5ABA47;" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="currentColor" class="bi bi-hearts" viewBox="0 0 16 16">

                        <path fill-rule="evenodd" d="M4.931.481c1.627-1.671 5.692 1.254 0 5.015-5.692-3.76-1.626-6.686 0-5.015Zm6.84 1.794c1.084-1.114 3.795.836 0 3.343-3.795-2.507-1.084-4.457 0-3.343ZM7.84 7.642c2.71-2.786 9.486 2.09 0 8.358-9.487-6.268-2.71-11.144 0-8.358Z" />

                    </svg>Find Your <span style="color:#5ABA47;">Life Partner</span><svg style="margin-bottom: 45px;" xmlns="http://www.w3.org/2000/svg" width="24" height="24" fill="currentColor" class="bi bi-hearts" viewBox="0 0 16 16">

                        <path fill-rule="evenodd" d="M4.931.481c1.627-1.671 5.692 1.254 0 5.015-5.692-3.76-1.626-6.686 0-5.015Zm6.84 1.794c1.084-1.114 3.795.836 0 3.343-3.795-2.507-1.084-4.457 0-3.343ZM7.84 7.642c2.71-2.786 9.486 2.09 0 8.358-9.487-6.268-2.71-11.144 0-8.358Z" />

                    </svg></h2>

                <p class="para1 mb-5">GotoNikah.com Meet your perfect partner from sites to "tie up together",<br>

                    All Muslim community can find their suitable brides and grooms with thousands of profiles.<a style="color: #5ABA47;cursor: pointer;" onclick="myFunctionread()" id="myBtn">Read more</a><span id="dots"></span><br><span id="more" style="text-align: justify;">Goto Nikah is an emerging Muslim matrimony site in Kerala for Malayalee Muslims across the world. This muslim matrimony site will help every Muslim bachelor who seeks life partners in a truly Islamic way. Registration on this <b>best</b> 
                    <a href="https://happynikah.com/user/about_gotonikah"> Muslim marriage bureau </a> is free; once completed, the team behind this Muslim community matrimony will screen the profile to validate and confirm its authenticity. After the completion of registration on this marriage bureau, the members can contact each other.

                        The user interface of this Nikah matrimonial Goto Nikah, is very easy to use and simple. This <a href="https://happynikah.com/user/about_gotonikah"> matchmaking website </a> provides a free search facility to every Malayalee Muslim bachelor out there. Unlike all other matrimony websites, this Muslim marriage bureau in Kerala will promise you that they are highly committed to the culture and creed of the Islamic religion.

                        Goto Nikah, muslim matrimony site gives special consideration to orphans and differently-abled Muslims. Apart from the safety, security, and credibility of this marriage agency, Goto Nikkah is more focused on charity activities too. Search for your partner through Goto Nikah, an ideal Muslim community matrimony website, and make your marital life even more awesome.</span></p>

            </div>

        </div>

    </div>

    <div class="lPull">



        <div class="owl-partner owl-carousel owl-theme">

           <?php



            foreach ($homeprofiles as $vals) { 

                                          

  $file_pointer = 'assets/photo_storage/'.$vals->photo;

    if(file_exists($file_pointer)){?>

                <div class="item">

                    <div class="profCard">

                        <div class="d-flex justify-content-between mb-3">

                            <div class="pe-3">

                                <div class="name d-flex align-items-center">

                                    <img src="<?php echo base_url() ?>assets/images/name_goto.png" alt="name" width="auto" height="auto" class="profileico">

                                    <span><?php echo $vals->name; ?></span>

                                </div>

                                <div class="detls d-flex align-items-center">

                                    <img src="<?php echo base_url() ?>assets/images/physic_goto.png" alt="name" width="auto" height="auto" class="profileico">

                                    <span><?php $age= date_diff(date_create($vals->dob), date_create('today'))->y; if($age!=0){ echo $age."Yrs,"; }?>  <?php echo $vals->height; ?></span>

                                </div>

                                <div class="detls d-flex align-items-center">

                                    <img src="<?php echo base_url() ?>assets/images/suitcase_goto.png" alt="name" width="auto" height="auto" class="profileico">

                                    <span><?php echo $vals->profession_name; ?></span>

                                </div>

                                <div class="detls d-flex align-items-center">

                                    <img src="<?php echo base_url() ?>assets/images/star_goto.png" alt="name" width="auto" height="auto" class="profileico">

                                    <span><?php echo $vals->user_religion; ?>, <?php echo $vals->user_caste; ?></span>

                                </div>

                              <!--  <div class="detls d-flex align-items-center">

                                    <img src="<?php echo base_url() ?>assets/images/loctn.png" alt="name" width="auto" height="auto" class="profileico">

                                    <span>Lake Halieville</span>

                                </div>-->

                            </div>

                            <div class="imgBox">

                                <?php 

  $file_pointer = 'assets/photo_storage_thumb/'.$vals->photo;

    if(file_exists($file_pointer)){?>



                                <img src="<?php echo base_url('/assets/photo_storage_thumb/' . $vals->photo); ?>" alt="profile image" class="proImg" style="height:100%;">



<?php } else {?>

                                <img src="<?php echo base_url('/assets/photo_storage/' . $vals->photo); ?>" alt="profile image" class="proImg" style="height:100%;">

<?php }?>



                            </div>

                        </div>

                        <button class="btn connectBtn"  data-bs-toggle="modal" data-bs-target="#loginModal" style="background:transparent linear-gradient(90deg, #1B3F1C   0%, #5ABA47 100%) 0% 0%
    no-repeat padding-box">

                            <img src="<?php echo base_url() ?>assets/images/payment.png" alt="tick" width="auto" height="auto">

                            <span>Connect Now</span>

                        </button>

                    </div>

                </div>

            <?php } }?>

        </div>

    </div>

</section>

<!-- <br><br><br><br><br> -->





<section id="homeDownload">

    <div class="container">

        <div class="row">

            <div class="col-12 col-xxl-10  col-md-12 mx-auto ">

               

                    <div class="search">

                        <h2 class="subHead1 mb-4">Search Profiles<br><span style="color:#5ABA47;">Anytime! Anywhere!!</span></h2>

                        <p class="pOne">Finding your perfect match has never been easier without the GotoNikah application</p>

                        <p class="pTwo">Download now and communicate with muslim matches on-the-go!</p>

                        <div class="downico">

                            <a href="javascript:void(0)">

                                <img style="height:30px;" src="<?php echo base_url() ?>assets/images/appleStore.png" draggable="false" alt="appleStore" width="auto" height="auto" class="storeIcon me-3">

                            </a>

                            <a target="_blank" href="https://play.google.com/store/apps/details?id=com.sysol.goto_nikah">

                                <img style="height:30px;" src="<?php echo base_url() ?>assets/images/playStore.png" alt="playStore" draggable="false" width="auto" height="auto" class="storeIcon">

                            </a>



                        </div>



                    </div>

                    <div class="col-12 col-lg-4 col-md-12 col-xl-6 text-center position-relative">

                <img src="<?php echo base_url() ?>assets/images/Mobile_single.png" alt="playStore" draggable="false" width="auto" height="auto" class="appIcon"
                style="width: 70%;position: absolute;left: -105px;top: -267px;z-index: 1;" id="play">
                     </div>
                      <div class="col-12 col-lg-4 col-md-12 col-xl-6 text-center position-relative">
                        <img class="pdown" src="<?php echo base_url() ?>assets/images/downloadg.png" draggable="false" alt="download" width="auto" height="auto">

                    </div>

                </div>

            </div>

        </div>

    </div>

</section>

<!-- <section id="homeVid" style="background-color: white;margin-top: -120px;">
      
        <div class="container">
            <div class="row mb-4">
                <div class="col-12 col-md-8 mx-auto text-center">
                    <h2 class="subHead">Our Youtube <span style="color:#5ABA47;">Exclusives</span></h2>
                    <p class="para1 mb-5"> -- Watch our Youtube Videos . Get to know about us faster --</p>
                </div>
            </div>
            <div class="owl-carousel owl-theme">
               
                <div class="item-video" style="margin-left:20px;"><iframe width="560" height="315" src="https://www.youtube.com/embed/9Sg-st6_C_I" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe></div>
                
                <div class="item-video" style="margin-left:20px;"><iframe width="560" height="315" src="https://www.youtube.com/embed/WIu328N60ss" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe></div>
              
                <div class="item-video" style="margin-left:20px;"><iframe width="560" height="315" src="https://www.youtube.com/embed/k-ef5JqofcA" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe></div>
       
                <div class="item-video" style="margin-left:20px;"><iframe width="560" height="315" src="https://www.youtube.com/embed/YbFY6_c4IE4" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe></div>
        
                <div class="item-video" style="margin-left:20px;"><iframe width="560" height="315" src="https://www.youtube.com/embed/kwwM-ZOUs4w" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe></div>
       
                <div class="item-video" style="margin-left:20px;"><iframe width="560" height="315" src="https://www.youtube.com/embed/HTYDeRKw8es" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe></div>
             
                <div class="item-video" style="margin-left:20px;"><iframe width="560" height="315" src="https://www.youtube.com/embed/9q4WP8X121Y" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe></div>
           

            </div>
        </div>
        </div>
        <br><br>
    </section>-->
    
    
    
    
    
    
    
    

        
        

<section id="homeContact" style="background: #f9f9ff;">

    <div class="container">

        <div class="row">

            <div class="col-12 col-md-12 d-flex align-items-center mb-5 mb-md-0">

                <div class="w-100">

                    <h2 class="subHead" style="margin-top:0px;">Begin your <span style="color:#5ABA47;">journey with us</span></h2>

                    <p class="addText mb-4">We are ready to help your nikah dream come true..!</p>

                    <div class="d-flex align-items-center mb-4">

                        <div class="flex-shrink-0">

                            <img src="<?php echo base_url() ?>assets/images/address_new.jpg" alt="address" class="icon">

                        </div>

                        <div class="flex-grow-1 ms-3">

                            <p class="addText mb-0" id="txt">IV th Floor, Neospace,
                            Kinfra Techno Industrial Park ,<br/>
                            Calicut University(PO),Malappuram, India.</p>

                        </div>

                    </div>

                    <div class="d-flex align-items-center mb-4">

                        <div class="flex-shrink-0">
                               <a href="tel:+918943777666">
                            <img src="<?php echo base_url() ?>assets/images/telephone_new.jpg" alt="telephone" class="icon">
                            </a>
                        </div>

                        <div class="flex-grow-1 ms-3">
                               <a href="tel:+918943777666" style="color:#000;text-decoration:none;">
                            <p class="mobText mb-0" id="mob">+91-8943 777 666</p>
                          </a>
                        </div>

                    </div>

                    <div class="d-flex align-items-center">

                        <div class="flex-shrink-0">
                                <a href="mailto:info@gotonikah.com">
                            <img src="<?php echo base_url() ?>assets/images/mail_new.jpg" alt="mail" class="icon">
                                </a>
                        </div>

                        <div class="flex-grow-1 ms-3">
                        <a href="mailto:info@gotonikah.com" style="color:#000;text-decoration:none;">
                            <p class="addText mb-0" id="mail_happy">info@gotonikah.com</p>
                            </a>
                        </div>

                    </div>

                </div>

            </div>

        </div>

    </div>

</section>

<!--mobile verify otp Modal-->



<div class="modal fade" id="otpModal" data-backdrop="static" tabindex="-1" aria-labelledby="otpModalLabel" aria-hidden="true">

    <div class="modal-dialog modal-dialog-centered modal-lg">

        <div class="modal-content">

            <div class="modal-body p-0">

                <div class="row">

                    <div class="col-12 col-lg-6 d-none d-lg-flex align-items-stretch">

                        <div class="leftBox w-100">

                            <h2 class="modalHead mb-4" id="otpModalLabel">Search Profilest<br><span>Anytime! Anywhere!!</span></h2>

                            <p class="lpone">Finding your perfect match has never been easier without the GotoNikah application</p>

                            <p class="lptwo">Download now and communicate with muslim matches on-the-go!</p>

                            <div class="d-flex justify-content-center">

                                <a href="javascript:void(0)">

                        <img src="<?php echo base_url() ?>assets/images/appleStore.png" alt="appleStore" class="storeIcon me-3" width="auto" height="auto">

                                </a>

                                <a href="https://play.google.com/store/apps/details?id=com.sysol.goto_nikah">

                 <img src="<?php echo base_url() ?>assets/images/playStore.png" alt="playStore" class="storeIcon" width="auto" height="auto">

                                </a>

                            </div>

                        </div>

                    </div>

                    <div class="col-12 col-lg-6 d-flex align-items-stretch">

                        <div class="rbox w-100">

                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>

                            <div class="d-flex justify-content-between mb-5">

                                <h3 class="welcomeHead">Mobile Number<br> Verification</h3>

                                <img src="<?php echo base_url() ?>happyadmin/assets/images/goto nikah logo.png" alt="go to Nikah" class="llogo" width="100px" height="auto">
                                
                                 <!--<img src="https://happynikah.com/happyadmin/assets/images/goto nikah logo.png" alt="Go to Nikah" class="gotoNikahlogo" style="width:150px !important;" height="auto">-->

                            </div>

                            <div class="otpverifyBox">

                                <!--<form class="customForm">-->

                                <div class="mb-3">

                                    <label class="form-label">Enter Your OTP</label>

                                    <div class="otpInputs">

                                        <input id="verify1" type="text" class="form-control" maxlength="1" onkeyup="tabChange(this,'verify2')" />

                                        <input id="verify2" type="text" class="form-control" maxlength="1" onkeyup="tabChange(this,'verify3')" />

                                        <input id="verify3" type="text" class="form-control" maxlength="1" onkeyup="tabChange(this,'verify4')" />

                                        <input id="verify4" type="text" class="form-control" maxlength="1" onkeyup="tabChange(this,'verify5')" />

                                        <input id="verify5" type="text" class="form-control" maxlength="1" onkeyup="tabChange(this,'verify6')" />

                                        <input id="verify6" type="text" class="form-control" maxlength="1" />

                                    </div>

                                </div>

                                <p class="errorotp"></p>

                                <button type="button" class="btn cstmBtnColr w-100" onclick="verify_mobile()">SUBMIT</button>

                                <p>NOTE: If you have not received OTP by sms, you can check your email for OTP.</p>

                                <!--</form>-->

                            </div>

                        </div>

                    </div>

                </div>

            </div>

        </div>

    </div>

</div>
<style>
.errorotp 
{
    /*text-align: center;*/
    /*color: #1cfe70;*/
     background: unset !important;
}

#otpModal .llogo 
{
    width: 100px;
    height: auto;
}

</style>
<!-- terms Modal -->

<div class="modal fade" id="termsModal" tabindex="-1" aria-labelledby="termsModalLabel" aria-hidden="true">

    <div class="modal-dialog modal-dialog-centered modal-lg">

        <div class="modal-content">

            <div class="modal-body p-0">

                <div class="row">


                    <div class="col-12" style="padding:50px;">

                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close" style="float:right"></button>

                        <div style='margin-top:0in;margin-right:0in;margin-bottom:10.0pt;margin-left:0in;line-height:115%;font-size:15px;font-family:"Calibri","sans-serif";border:none;border-bottom:dashed #666666 1.0pt;padding:0in 0in 0in 0in;'>

                            <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:normal;font-size:15px;font-family:"Calibri","sans-serif";text-align:center;'><strong><span style='font-size:16px;font-family:"Times New Roman","serif";color:#C00000;'>TERMS AND CONDITIONS</span></strong></p>

                            <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:normal;font-size:15px;font-family:"Calibri","sans-serif";'><strong><span style='font-size:16px;font-family:"Times New Roman","serif";'>&nbsp;</span></strong></p>

                            <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:normal;font-size:15px;font-family:"Calibri","sans-serif";'><strong><span style='font-size:16px;font-family:"Times New Roman","serif";'>Welcome to gotonikah.com</span></strong></p>

                            <p style='margin-top:0in;margin-right:0in;margin-bottom:10.0pt;margin-left:0in;line-height:normal;font-size:15px;font-family:"Calibri","sans-serif";'><span style='font-size:16px;font-family:"Times New Roman","serif";'>Please read the terms of use for this website carefully. In accordance with this terms and conditions, the users of gotonikah.com are provided with limited license to use the service and content of this website. By signing up the service, you give your acceptance to be bound by the Terms and conditions (herein referred to as &ldquo;Agreement&rdquo;). To become a member of this website and to be able to communicate with fellow members, you must register as a member and follow the instructions given during the Registration process. This Agreement outlines the terms that you are subjected to as a member of this website. The Agreement may be revised from time to time at the sole discretion of gotonikah.com and will be intimated to you. Pursuant to such changes, if you continue to use the site then it will be constituted as your acceptance for the changes.</span></p>

                            <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:normal;font-size:15px;font-family:"Calibri","sans-serif";'><strong><span style='font-size:16px;font-family:"Times New Roman","serif";'>Criteria of Use</span></strong></p>

                            <p style='margin-top:0in;margin-right:0in;margin-bottom:10.0pt;margin-left:0in;line-height:normal;font-size:15px;font-family:"Calibri","sans-serif";'><span style='font-size:16px;font-family:"Times New Roman","serif";'>You are at least 18 or 18+ years of age. The membership of those users will be declined whose eligibility does not match the criteria. Using this site will determine that you possess the right, authority and competence to sign this Agreement and to be bound by the terms of use of this Agreement.&nbsp;</span></p>

                            <p style='margin-top:0in;margin-right:0in;margin-bottom:10.0pt;margin-left:0in;line-height:normal;font-size:15px;font-family:"Calibri","sans-serif";'><span style='font-size:16px;font-family:"Times New Roman","serif";'>This site does not encourage and/or promote illegitimate sexual relations or affairs outside marriage. If any member is found to be using this site as a means of promoting or indulging or engaging in any illegitimate sexual relations or affairs outside marriage or if gotonikah.com becomes aware of such activities then the membership of the particular user will be terminated without any refund. gotonikah.comis not bound by any liability towards such individual. The binding and final termination will be the sole discretion of gotonikah.com.com.</span></p>

                            <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:normal;font-size:15px;font-family:"Calibri","sans-serif";'><strong><span style='font-size:16px;font-family:"Times New Roman","serif";'>Terms of Use</span></strong></p>

                            <p style='margin-top:0in;margin-right:0in;margin-bottom:10.0pt;margin-left:0in;line-height:normal;font-size:15px;font-family:"Calibri","sans-serif";'><span style='font-size:16px;font-family:"Times New Roman","serif";'>This Agreement will come into effect once you have registered as a member and will remain in full force as and when you continue to use the Site. If you wish to terminate your membership for any reason and at any time, you may do so by informing gotonikah.com in writing. In the event of gotonikah.com terminating your membership or you terminate your membership, you will not be entitled any refund irrespective of whether you have any unutilized subscription fees. gotonikah.comreserves the sole right to terminate your access to the Site and/or your membership for any reason. You will be intimated of the same via email at the email address (or any other email address that you may later provide) you provided in your application for membership to gotonikah.com.com. In the event of gotonikah.com terminating your membership for breaching the Agreement, you will not be entitled to any refund. Even after the termination of the Agreement, provisions including sections 4,5,7,9 -12 of this Agreement will remain in effect.</span></p>

                            <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:normal;font-size:15px;font-family:"Calibri","sans-serif";'><strong><span style='font-size:16px;font-family:"Times New Roman","serif";'>Non-Commercial Use by Members</span></strong></p>

                            <p style='margin-top:0in;margin-right:0in;margin-bottom:10.0pt;margin-left:0in;line-height:normal;font-size:15px;font-family:"Calibri","sans-serif";'><span style='font-size:16px;font-family:"Times New Roman","serif";'>The service of this website is for the personal use of individual members only. Members of gotonikah.com will not use the services of the website for any commercial purpose including link building of any kind irrespective of whether it may be deemed competitive to gotonikah.com or otherwise. The membership of this website is restricted to individuals only therefore, non-individual entity may not become members of gotonikah.com.com. Appropriate legal action will be taken against illegitimate and/or unauthorized use of the Site, which may include unauthorized framing of or linking to the Site.</span></p>

                            <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:normal;font-size:15px;font-family:"Calibri","sans-serif";'><strong><span style='font-size:16px;font-family:"Times New Roman","serif";'>Other Terms of Use</span></strong></p>

                            <p style='margin-top:0in;margin-right:0in;margin-bottom:10.0pt;margin-left:0in;line-height:normal;font-size:15px;font-family:"Calibri","sans-serif";'><span style='font-size:16px;font-family:"Times New Roman","serif";'>1. Members of the website will not engage in any advertising or solicitation of selling or buying any services or products through this website.&nbsp;</span></p>

                            <p style='margin-top:0in;margin-right:0in;margin-bottom:10.0pt;margin-left:0in;line-height:normal;font-size:15px;font-family:"Calibri","sans-serif";'><span style='font-size:16px;font-family:"Times New Roman","serif";'>2. You will not send any chain letters or spam the email of gotonikah.com members.</span></p>

                            <p style='margin-top:0in;margin-right:0in;margin-bottom:10.0pt;margin-left:0in;line-height:normal;font-size:15px;font-family:"Calibri","sans-serif";'><span style='font-size:16px;font-family:"Times New Roman","serif";'>3. Using any information obtained from this service for the purpose of harassing, abusing or harming a fellow member will be considered as the violation of this agreement.</span></p>

                            <p style='margin-top:0in;margin-right:0in;margin-bottom:10.0pt;margin-left:0in;line-height:normal;font-size:15px;font-family:"Calibri","sans-serif";'><span style='font-size:16px;font-family:"Times New Roman","serif";'>4. Gotonikah.com has the sole right to restrict the number of communications, emails, of all the members in order to protect its members from any sort of abuse or misuse.</span></p>

                            <p style='margin-top:0in;margin-right:0in;margin-bottom:10.0pt;margin-left:0in;line-height:normal;font-size:15px;font-family:"Calibri","sans-serif";'><span style='font-size:16px;font-family:"Times New Roman","serif";'>5. Sending obscene, lewd, licentious, defamatory messages that promote hatred and/or are racial or abusive in any manner will be deemed as a breach of this agreement and shall be entitled to termination of your membership.&nbsp;</span></p>

                            <p style='margin-top:0in;margin-right:0in;margin-bottom:10.0pt;margin-left:0in;line-height:normal;font-size:15px;font-family:"Calibri","sans-serif";'><span style='font-size:16px;font-family:"Times New Roman","serif";'>6. Gotonikah.com at its own discretion reserves the right to screen messages that are sent to other Member(s). We also regulate the number of your chat sessions.</span></p>

                            <p style='margin-top:0in;margin-right:0in;margin-bottom:10.0pt;margin-left:0in;line-height:normal;font-size:15px;font-family:"Calibri","sans-serif";'><span style='font-size:16px;font-family:"Times New Roman","serif";'>7. Use of Bots, EXE&apos;s, CGI or any other programs/scripts to view content on or communicate/contact/respond/interact with gotonikah.com and/or its Members is restricted.</span></p>

                            <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:normal;font-size:15px;font-family:"Calibri","sans-serif";'><strong><span style='font-size:16px;font-family:"Times New Roman","serif";'>Propriety Rights</span></strong></p>

                            <p style='margin-top:0in;margin-right:0in;margin-bottom:10.0pt;margin-left:0in;line-height:normal;font-size:15px;font-family:"Calibri","sans-serif";'><span style='font-size:16px;font-family:"Times New Roman","serif";'>The propriety rights of this website are owned by gotonikah.com and retain all intellectual property without any limitation. The proprietary information shall not be copied, modified, published, transmitted, distributes, displayed, sold or performs in any form. Gotonikah.com website possesses copyrighted material, trademarks, and other proprietary information Ownership of content posted on the Site</span></p>

                            <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:normal;font-size:15px;font-family:"Calibri","sans-serif";'><strong><span style='font-size:16px;font-family:"Times New Roman","serif";'>You agree that</span></strong></p>

                            <p style='margin-top:0in;margin-right:0in;margin-bottom:10.0pt;margin-left:0in;line-height:normal;font-size:15px;font-family:"Calibri","sans-serif";'><span style='font-size:16px;font-family:"Times New Roman","serif";'>1) Gotonikah.com owns all the lawful, legal and non-objectionable messages, content and/or other information, content or material that are posted on the forum boards.</span></p>

                            <p style='margin-top:0in;margin-right:0in;margin-bottom:10.0pt;margin-left:0in;line-height:normal;font-size:15px;font-family:"Calibri","sans-serif";'><span style='font-size:16px;font-family:"Times New Roman","serif";'>2) All such information, content and/or material posted on the forum boards may be scrutinized by gotonikah.com and have the sole right at its own discretion to remove, edit and/or display such information, material and/or content, messages, photos or profiles which might be deemed as offensive, illegitimate, derogatory, obscene, libellous, or that might violate the rights, harm, or intimidate the safety of other members. It will be considered as a breach of this agreement and may be liable to termination.</span></p>

                            <p style='margin-top:0in;margin-right:0in;margin-bottom:10.0pt;margin-left:0in;line-height:normal;font-size:15px;font-family:"Calibri","sans-serif";'><span style='font-size:16px;font-family:"Times New Roman","serif";'>3) The Content that are published or displayed on the Site by you will be at your sole discretion.</span></p>

                            <p style='margin-top:0in;margin-right:0in;margin-bottom:10.0pt;margin-left:0in;line-height:normal;font-size:15px;font-family:"Calibri","sans-serif";'><span style='font-size:16px;font-family:"Times New Roman","serif";'>4) Gotonikah.com reserves the right to verify the authenticity of Content posted on the Site and may ask you to provide any documentary or other form of evidence supporting the Content you post on the Site.&nbsp;</span></p>

                            <p style='margin-top:0in;margin-right:0in;margin-bottom:10.0pt;margin-left:0in;line-height:normal;font-size:15px;font-family:"Calibri","sans-serif";'><span style='font-size:16px;font-family:"Times New Roman","serif";'>5) In the event of your failure to produce such evidence, or if the evidence is not sufficient to support and justify your claim then gotonikah.com may, in its sole discretion, terminate your Membership without any refund.&nbsp;</span></p>

                            <p style='margin-top:0in;margin-right:0in;margin-bottom:10.0pt;margin-left:0in;line-height:normal;font-size:15px;font-family:"Calibri","sans-serif";'><span style='font-size:16px;font-family:"Times New Roman","serif";'>6) You understand that by posting content to any public forum, you automatically grant gotonikah.com and other members the license to utilize, reproduce, exhibit, distribute and perform the information and content in any manner.</span></p>

                            <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:normal;font-size:15px;font-family:"Calibri","sans-serif";'><strong><span style='font-size:16px;font-family:"Times New Roman","serif";'>Content prohibited on the Site&nbsp;</span></strong></p>

                            <p style='margin-top:0in;margin-right:0in;margin-bottom:10.0pt;margin-left:0in;line-height:normal;font-size:15px;font-family:"Calibri","sans-serif";'><span style='font-size:16px;font-family:"Times New Roman","serif";'>Any member violating the following provision will be subjected to appropriate legal action in the sole discretion of gotonikah.com.com. The violator will be removed and membership will be terminated from the website without refund. It includes (but is not limited to) Content that:</span></p>

                            <p style='margin-top:0in;margin-right:0in;margin-bottom:10.0pt;margin-left:0in;line-height:normal;font-size:15px;font-family:"Calibri","sans-serif";'><span style='font-size:16px;font-family:"Times New Roman","serif";'>1) New profiles will be verified for its authenticity by way of gotonikah.com and will be immediately activated after receiving quality declaration.</span></p>

                            <p style='margin-top:0in;margin-right:0in;margin-bottom:10.0pt;margin-left:0in;line-height:normal;font-size:15px;font-family:"Calibri","sans-serif";'><span style='font-size:16px;font-family:"Times New Roman","serif";'>2) In the event of unacceptable profile contents or if the profile contains violent language or unsolicited material then gotonikah.com reserves the sole right to discontinue, deactivate, or terminate the concerned profile.</span></p>

                            <p style='margin-top:0in;margin-right:0in;margin-bottom:10.0pt;margin-left:0in;line-height:normal;font-size:15px;font-family:"Calibri","sans-serif";'><span style='font-size:16px;font-family:"Times New Roman","serif";'>3) Only paid customer will have access to contact information of other members.</span></p>

                            <p style='margin-top:0in;margin-right:0in;margin-bottom:10.0pt;margin-left:0in;line-height:normal;font-size:15px;font-family:"Calibri","sans-serif";'><span style='font-size:16px;font-family:"Times New Roman","serif";'>4) The liability of your connections with other members through this Service solely lies with you. Gotonikah.com does not have any obligation to supervise the disputes between its members.</span></p>

                            <p style='margin-top:0in;margin-right:0in;margin-bottom:10.0pt;margin-left:0in;line-height:normal;font-size:15px;font-family:"Calibri","sans-serif";'><span style='font-size:16px;font-family:"Times New Roman","serif";'>5) Free membership may be discontinued by gotonikah.com as and when it is deemed to be of no more relevance.&nbsp;</span></p>

                            <p style='margin-top:0in;margin-right:0in;margin-bottom:10.0pt;margin-left:0in;line-height:normal;font-size:15px;font-family:"Calibri","sans-serif";'><span style='font-size:16px;font-family:"Times New Roman","serif";'>6) Gotonikah.com does not claim any responsibility for the misuse of this service.&nbsp;</span></p>

                            <p style='margin-top:0in;margin-right:0in;margin-bottom:10.0pt;margin-left:0in;line-height:normal;font-size:15px;font-family:"Calibri","sans-serif";'><span style='font-size:16px;font-family:"Times New Roman","serif";'>7) All the members are required to submit their profile with the necessary facts required for establishing a matrimonial alliance. Gotonikah.com will not be responsible for any loss or damage caused for concealing facts relevant to marriage.</span></p>

                            <p style='margin-top:0in;margin-right:0in;margin-bottom:10.0pt;margin-left:0in;line-height:normal;font-size:15px;font-family:"Calibri","sans-serif";'><span style='font-size:16px;font-family:"Times New Roman","serif";'>8) Gotonikah.com does not guarantee the legitimacy and validity of the information provided by the members. This may include information related religion, caste or creed or any other personal information.</span></p>

                            <p style='margin-top:0in;margin-right:0in;margin-bottom:10.0pt;margin-left:0in;line-height:normal;font-size:15px;font-family:"Calibri","sans-serif";'><span style='font-size:16px;font-family:"Times New Roman","serif";'>9) Gotonikah.com will not be responsible for any delays caused in posting information due to technical faults.</span></p>

                            <p style='margin-top:0in;margin-right:0in;margin-bottom:10.0pt;margin-left:0in;line-height:normal;font-size:15px;font-family:"Calibri","sans-serif";'><span style='font-size:16px;font-family:"Times New Roman","serif";'>10) For loss or damage due to the discontinuation of the service or for any damage caused due to accessing other member&rsquo;s profile, Gotonikah.com is not responsible.</span></p>

                            <p style='margin-top:0in;margin-right:0in;margin-bottom:10.0pt;margin-left:0in;line-height:normal;font-size:15px;font-family:"Calibri","sans-serif";'><span style='font-size:16px;font-family:"Times New Roman","serif";'>11) Gotonikah.com does not provide any guarantee that you as an applicant will receive responses and is not liable to any refunds or credits.</span></p>

                            <p style='margin-top:0in;margin-right:0in;margin-bottom:10.0pt;margin-left:0in;line-height:normal;font-size:15px;font-family:"Calibri","sans-serif";'><span style='font-size:16px;font-family:"Times New Roman","serif";'>12) The users will not promote any an illegal or unauthorized copy of another person&apos;s copyrighted work which may include pirated computer programs, providing information to circumvent manufacture-installed copy-protect devices, or pirated music.</span></p>

                            <p style='margin-top:0in;margin-right:0in;margin-bottom:10.0pt;margin-left:0in;line-height:normal;font-size:15px;font-family:"Calibri","sans-serif";'><span style='font-size:16px;font-family:"Times New Roman","serif";'>13) The users will not send any information with restricted contents or password only access pages, or hidden pages or images.</span></p>

                            <p style='margin-top:0in;margin-right:0in;margin-bottom:10.0pt;margin-left:0in;line-height:normal;font-size:15px;font-family:"Calibri","sans-serif";'><span style='font-size:16px;font-family:"Times New Roman","serif";'>14) The users will not encourage extra marital affairs, exploitation of people under 18 years of age in a sexual or violent manner, other illegal activities such as making or buying illegal weapons, violating someone&apos;s privacy, or providing or creating computer viruses.</span></p>

                            <p style='margin-top:0in;margin-right:0in;margin-bottom:10.0pt;margin-left:0in;line-height:normal;font-size:15px;font-family:"Calibri","sans-serif";'><span style='font-size:16px;font-family:"Times New Roman","serif";'>The service of Gotonikah.com must be used in accordance to all local, state, and federal laws and regulations. Creation of more than one profile is not permitted in any case. Doing so may subject your membership to terminate without any refunds.</span></p>

                            <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:normal;font-size:15px;font-family:"Calibri","sans-serif";'><strong><span style='font-size:16px;font-family:"Times New Roman","serif";'>Copyright Policy</span></strong></p>

                            <p style='margin-top:0in;margin-right:0in;margin-bottom:10.0pt;margin-left:0in;line-height:normal;font-size:15px;font-family:"Calibri","sans-serif";'><span style='font-size:16px;font-family:"Times New Roman","serif";'>The copyrighted material, trademarks, or other proprietary information may not be copied, reproduced or distributed in any form without the prior written consent of the owner. In the event of your copyright materials being copied and posted, you may get in touch with our copyright Agents for copyright infringement with an electronic or physical signature authorizing the person to act on behalf of the owner and a description of the copyrighted material that you believe has been infringed. You must also include the source of the material, your address, telephone number, and email address along with a written statement. If applicable then you may also produce a certificate of the registration or any other intellectual property right. You can contact GotoNikah.com&apos;s Copyright Agent for Notice of claims of copyright infringement by writing to the Mumbai address located under the Help/Contact section.</span></p>

                            <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:normal;font-size:15px;font-family:"Calibri","sans-serif";'><strong><span style='font-size:16px;font-family:"Times New Roman","serif";'>Privacy</span></strong></p>

                            <p style='margin-top:0in;margin-right:0in;margin-bottom:10.0pt;margin-left:0in;line-height:normal;font-size:15px;font-family:"Calibri","sans-serif";'><span style='font-size:16px;font-family:"Times New Roman","serif";'>The use of this service is governed by the Gotonikah.com Privacy Policy.</span></p>

                            <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:normal;font-size:15px;font-family:"Calibri","sans-serif";'><strong><span style='font-size:16px;font-family:"Times New Roman","serif";'>Disclaimers</span></strong></p>

                            <p style='margin-top:0in;margin-right:0in;margin-bottom:10.0pt;margin-left:0in;line-height:normal;font-size:15px;font-family:"Calibri","sans-serif";'><span style='font-size:16px;font-family:"Times New Roman","serif";'>Gotonikah.com does not claim any responsibility for the authenticity of the Content posted on the Site, whether caused by users visiting the Site, Members or by any equipment or programming associated with or utilized in the Service. Furthermore, Gotonikah.com does not claim any responsibility for the conduct of any user and/or Member whether online or offline. Gotonikah.com assumes no responsibility for any error, omission, interruption, deletion, defect, delay in operation or transmission, communications line failure, theft or destruction or unauthorized access to, or alteration of, user and/or Member communications. The exchange of profile(s) through or by Gotonikah.com should not in any way be construed as any offer and/or recommendation from/by gotonikah.com. The Site and the Service are provided &quot;AS-IS AVALAIBLE BASIS&quot; and gotonikah.com expressly disclaims any warranty of fitness for a particular purpose or non-infringement. Gotonikah.com cannot guarantee and does not promise any specific results from use of the Site and/or the gotonikah.com Service.</span></p>

                            <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:normal;font-size:15px;font-family:"Calibri","sans-serif";'><strong><span style='font-size:16px;font-family:"Times New Roman","serif";'>Limitation on Liability</span></strong></p>

                            <p style='margin-top:0in;margin-right:0in;margin-bottom:10.0pt;margin-left:0in;line-height:normal;font-size:15px;font-family:"Calibri","sans-serif";'><span style='font-size:16px;font-family:"Times New Roman","serif";'>Except in jurisdictions where such provisions are limited, in any event, gotonikah.com will not be liable to you or any third person for any indirect, consequential, exemplary, incidental, special or punitive damages, including also lost profits arising from your use of the Site. Notwithstanding anything to the contrary contained herein, gotonikah.com, liability to you for any cause whatsoever, and regardless of the form of the action, will at all times be limited to the amount paid, if any, by you to gotonikah.com, for the Service during the term of membership.</span></p>

                            <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:normal;font-size:15px;font-family:"Calibri","sans-serif";'><strong><span style='font-size:16px;font-family:"Times New Roman","serif";'>Disputes</span></strong></p>

                            <p style='margin-top:0in;margin-right:0in;margin-bottom:10.0pt;margin-left:0in;line-height:normal;font-size:15px;font-family:"Calibri","sans-serif";'><span style='font-size:16px;font-family:"Times New Roman","serif";'>If any dispute involving the Site and/or the Service arises, you agree that the dispute will be governed by the laws of India under the exclusive jurisdiction to the courts of Mumbai, India.</span></p>

                            <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:normal;font-size:15px;font-family:"Calibri","sans-serif";'><strong><span style='font-size:16px;font-family:"Times New Roman","serif";'>Indemnity</span></strong></p>

                            <p style='margin-top:0in;margin-right:0in;margin-bottom:10.0pt;margin-left:0in;line-height:normal;font-size:15px;font-family:"Calibri","sans-serif";'><span style='font-size:16px;font-family:"Times New Roman","serif";'>You agree to indemnify and hold gotonikah.com, its subsidiaries, directors, affiliates, officers, agents, and other partners and employees, harmless from any loss, liability, claim, or demand, including reasonable attorney&apos;s fees, made by any third party due to or arising out of your use of the Service in violation of this Agreement and/or arising from a breach of these Terms of Use and/or any breach of your representations and warranties set forth above.</span></p>

                            <p style='margin-top:0in;margin-right:0in;margin-bottom:.0001pt;margin-left:0in;line-height:normal;font-size:15px;font-family:"Calibri","sans-serif";'><strong><span style='font-size:16px;font-family:"Times New Roman","serif";'>Other</span></strong></p>

                            <p style='margin-top:0in;margin-right:0in;margin-bottom:10.0pt;margin-left:0in;line-height:normal;font-size:15px;font-family:"Calibri","sans-serif";'><span style='font-size:16px;font-family:"Times New Roman","serif";'>By becoming a Member of gotonikah.com Service, you agree to receive specific emails from gotonikah.com. This Agreement, accepted upon use of the Site and further affirmed by becoming a Member of the gotonikah.com Service, contains the entire agreement between you and gotonikah.com regarding the use of the Site and/or the Service. If any provision of this Agreement is held invalid, the remainder of this Agreement shall continue in full force and effect. You are under an obligation to report any misuse or abuse of the Site to gotonikah.com by writing to Customer Care. On receiving such complaint, gotonikah.com may, if necessary, terminate the membership of the Member responsible for such violation abuse or misuse. If the complainant is at fault then they will be liable for termination of his / her membership without any refund of the subscription fee.</span></p>

                            <p style='margin-top:0in;margin-right:0in;margin-bottom:10.0pt;margin-left:0in;line-height:normal;font-size:15px;font-family:"Calibri","sans-serif";'><span style='font-size:16px;font-family:"Times New Roman","serif";'>For queries related to this agreement, please contact us</span></p>

                            <p style='margin-top:0in;margin-right:0in;margin-bottom:10.0pt;margin-left:0in;line-height:115%;font-size:15px;font-family:"Calibri","sans-serif";'>&nbsp;</p>

                            <p style='margin-top:0in;margin-right:0in;margin-bottom:10.0pt;margin-left:0in;line-height:115%;font-size:15px;font-family:"Calibri","sans-serif";'>&nbsp;</p>



                        </div>

                    </div>



                </div>

            </div>

        </div>

    </div>

</div>

<a href="javascript:" id="return-to-top" style="background:#5ABA47;"><i class="icon-chevron-up"></i></a>

<?php include('include/footer_gotonikah.php'); ?>



<!---the core firebasejs sdk is always required and must be listed first -->

<script src="https://www.gstatic.com/firebasejs/8.8.0/firebase-app.js"></script>
<script src="https://www.gstatic.com/firebasejs/7.20.0/firebase-messaging.js"></script>




<script src="https://code.jquery.com/jquery.min.js"></script>
<script src="https://netdna.bootstrapcdn.com/twitter-bootstrap/2.3.2/js/bootstrap.min.js"></script>



  <!--<script src=">assets/js/intlTelInput.min.js"></script>

  <script src="assets/js/utils.js"></script>

 <script>

   $("#phone").intlTelInput();

  </script>-->

<!--- Your web app's Firebase configuration



   For Firebase JS SDK v7.20.0 and later, measurementId is optional-->

<script>

    var firebaseConfig = {



        apiKey: "AIzaSyBYEHcvLRpAvLSfDpFwmwc1PDHVILlbN1Y",



        authDomain: "happy-nikah-18138.firebaseapp.com",



        projectId: "happy-nikah-18138",



        storageBucket: "happy-nikah-18138.appspot.com",



        messagingSenderId: "599897650989",



        appId: "1:599897650989:web:810928920232e8185605a4",



        measurementId: "G-VDDTM8J4QH"



    };

</script>

 <script type="text/javascript" src="<?php echo base_url() ?>assets/js/jquery-3.6.0.min.js"></script>
    <script type="text/javascript" src="<?php echo base_url() ?>assets/js/bootstrap.bundle.min.js"></script>

    <script src="<?php echo base_url() ?>assets/js/owl.carousel.js"></script>
    
    
    
    <script type="text/javascript">
          $(document).ready(function() {
            // partner slider
            $(".owl-partner").owlCarousel({
                margin: 25,
                responsiveClass: true,
                nav: false,
                dots: false,
                autoplay: true,
                autoplayHoverPause: false,
                loop: true,
                responsive: {
                    0: {
                        items: 1.2,
                    },
                    576: {
                        items: 1.5,
                    },
                    768: {
                        items: 2.2,
                    },
                    992: {
                        items: 2.5,
                    },
                    1200: {
                        items: 3.2,
                    },
                    1400: {
                        items: 3.5,
                    }
                },
            });
            // partner slider end
            // ===== Scroll to Top ==== 
            
       
            
            // $(window).scroll(function() {
            // if ($(this).scrollTop() >= 50) { // If page is scrolled more than 50px
            // $('#return-to-top').fadeIn(200); // Fade in the arrow
            // } else {
            // $('#return-to-top').fadeOut(200); // Else fade out the arrow
            // }
            // });
            // $('#return-to-top').click(function() { // When arrow is clicked
            // $('body,html').animate({
            // scrollTop: 0 // Scroll to top of body
            // }, 500);
            // });
            
            
            $(document).ready(function() {
            $(window).on('scroll', function() {
            if ($(this).scrollTop() >= 50) {
            $('#return-to-top').fadeIn(200);
            } else {
            $('#return-to-top').fadeOut(200);
            }
            });
            
            $('#return-to-top').on('click touchstart', function() {
            $('html, body').animate({
            scrollTop: 0
            }, 500);
            });
            });
            
            
            
            // $(window).on('scroll touchmove', function() 
            // {
            // if ($(this).scrollTop() >= 50) 
            // {
            // $('#return-to-top').fadeIn(200);
            // } else {
            // $('#return-to-top').fadeOut(200);
            // }
            // });
            
            // $('#return-to-top').on('click touchstart', function()
            // {
            // $('body,html').animate({
            // scrollTop: 0
            // }, 500);
            // });
            
            
            
            // $(document).on('scrollstart', function()
            // {
            // if ($(this).scrollTop() >= 50) 
            // {
            // $('#return-to-top').fadeIn(200);
            // } else {
            // $('#return-to-top').fadeOut(200);
            // }
            // });
            
            // $('#return-to-top').on('tap', function() 
            // {
            // $('body,html').animate({
            // scrollTop: 0
            // }, 500);
            // });


            
            
            
            
            //yt slider//
            $('.owl-carousel').owlCarousel({
                items: 1,
                merge: true,
                loop: true,
                margin: 10,
                video: true,
                autoplay: true,
                autoplayHoverPause: true,
                lazyLoad: true,
                center: true,
                videoWidth: false, // Default false; Type: Boolean/Number
                videoHeight: false, // Default false; Type: Boolean/Number
                responsive: {
                    900: {
                        items: 1.20,
                    },
                    1000: {
                        items: 2,
                    }
                }
            })
            

            // burger menu
            $(".hamburger").click(function() {
                $(this).toggleClass("is-active");
                $('body').toggleClass("is-scroll-disabled");
            });
            // burger menu end

            // login with otp and email switch
            $(".loginOtpBtn").click(function() {
                $(".emailLogBox").hide();
                $(".otpLogBox").show();
            });
            $(".loginEmailBtn").click(function() {
                $(".otpLogBox").hide();
                $(".emailLogBox").show();
                $('.resetpwdLogBox').hide();
                $('.otpsendBox').hide();
            });
            $(".sendOtp").click(function() {
                $(".otpLogBox").hide();
                // $(".otpsendBox").show();
            });
        });

        function lettersOnly() {
            var inputValue = event.keyCode;
            if (!(inputValue >= 65 && inputValue <= 122) && (inputValue != 32 && inputValue != 0)) {
                event.preventDefault();
            }
        }

        function tabChange(first, last) {
            if (first.value.length) {
                document.getElementById(last).focus();
            }
        }

        function myFunctionread() {
            var dots = document.getElementById("dots");
            var moreText = document.getElementById("more");
            var btnText = document.getElementById("myBtn");

            if (dots.style.display === "none") {
                dots.style.display = "inline";
                btnText.innerHTML = "Read more";
                moreText.style.display = "none";
            } else {
                dots.style.display = "none";
                btnText.innerHTML = "Read less";
                moreText.style.display = "inline";
            }
        }
    </script>
    
<script type="text/javascript">

    $(document).ready(function()
    {

    $('#otpModal').modal({
    
    backdrop: 'static',
    
    })
    
    })


   function checkvalidation() 
   {

        var created_by = $('#created_by').val();

        var name = $('#name').val();

        var phone = $('#phone').val();

        var countryCode = $('#countryCode option:selected').val();
        var country = $('#country option:selected').val();
        var state= $('#state option:selected').val();
        var home_district= $('#home_district option:selected').val();
        console.log(state);
        console.log(home_district);
        
        var flexCheckDefault = $('#flexCheckDefault:checked').val();

        if (created_by == '') {



            $("#created_by").addClass("error-warning");

            $('#created_by_val').html('Field Required');

        } else {

            $("#created_by").removeClass("error-warning");

            $('#created_by_val').html('');

        }



        if (name == '') {

            $("#name").addClass("error-warning");

            $('#name_val').html('Field Required');

        } else {

            $("#name").removeClass("error-warning");

            $('#name_val').html('');

        }



        if (phone == '') {

            $("#phone").addClass("error-warning");

            $('#phone_val').html('Field Required');

        } else {

            $("#phone").removeClass("error-warning");

            $('#phone_val').html('');

        }



        if (countryCode == '0') {

            $("#countryCode").addClass("error-warning");

            $('#countrycode_val').html('Field Required');

        } 
        else {

            $("#countryCode").removeClass("error-warning");

            $('#countrycode_val').html('');

        }

        if(phone!='' && countryCode!=0)
        
        {
        
        var codevalue=countryCode.split("-");
        
        var countryCode=codevalue[0];
        
        var maxlimit=codevalue[1];
        
        if(phone.length!=maxlimit)
        
        {
        
        $('#phone_val').html('Invalid Number');
        
        return false;
        
        }
        
        else
        
        {
        
        $('#phone_val').html('');
        
        }
        
        }

       
        if (flexCheckDefault == undefined)
        {

            $('#flexCheckDefault').addClass("error-warning");

            $('#terms_val').html('Please agree to our terms and conditions');

        }
        else
        {

            $('#flexCheckDefault').removeClass("error-warning");

            $('#terms_val').html('');

        }



        var checked_gender = document.querySelector('input[name = "gender"]:checked');



        var gender = $(checked_gender).val();

        var age = $("#user_age").val();

        if (age == "") {

            $('#agereq').html('Field Required');

        } else {

            $('#agereq').html('');

        }

        if (checked_gender == null) {

            $('#malereq').html('Field Required');

        }
        
        else 
        {

            $('#malereq').html('');

        }



        if (created_by != '' && name != '' && phone != '' && checked_gender != null && flexCheckDefault != undefined && countryCode != '0' && age != '' && country!='' && state!='' && home_district!='') {



            $.ajax({

                url: "<?php echo site_url('user/register_user_gotonikah'); ?>",

                type: "post",

                dataType: 'json',

                data: {

                    created_by: created_by,

                    name: name,

                    phone: phone,

                    countryCode: countryCode,

                    gender: gender,

                    age: age,
                    
                    country: country,
                    
                    state: state,
                    
                    home_district: home_district,

                },

                success: function(response) {


                    if (response != 1) {

                        //   $('#reg_error').css('display','block');

                        $('#error-mob').html("Already Registered..");



                    } else {

                        $('#reg_error').css('display', 'none');

                        //$('.registernow').html('Registering...');

                        $('#otpModal').modal('show');

                        $('#verify1').focus();

                    }

                },

            });

        }



    }



    function verify_mobile() {



        var otpdigit1 = $('#verify1').val();

        var otpdigit2 = $('#verify2').val();

        var otpdigit3 = $('#verify3').val();

        var otpdigit4 = $('#verify4').val();

        var otpdigit5 = $('#verify5').val();

        var otpdigit6 = $('#verify6').val();



        $.ajax({

            url: "<?php echo site_url('user/verify_mobile'); ?>",

            type: "post",

            data: {

                otpdigit1: otpdigit1,

                otpdigit2: otpdigit2,

                otpdigit3: otpdigit3,

                otpdigit4: otpdigit4,

                otpdigit5: otpdigit5,

                otpdigit6: otpdigit6

            },

            success: function(response) {

                console.log(response)

                if (response == 1) {

                    // Initialize Firebase



                    if (!firebase.apps.length) {

                        firebase.initializeApp(firebaseConfig);

                    }

                    //we have to call the get token function of firebase. 

                    //before this we have to get the instance of fiebase messaging which is coming from this library.

                    const fcm = firebase.messaging();

                    //now we can call get token function

                    //this requires a key pair

                    fcm.getToken({

                        vapidkey: 'BO6Tz1E3kqQhIjg-_37RtC2GdPDjMcOqRwN9SiDDHZ1fj9l35oLKW4kL5WP1jDI9YV94HLVrSbnwYqZ5_3mzDHk'

                    }).then((token) => {

                        //alert(token);

                        $.ajax({

                            url: "<?php echo site_url('user/update_usertoken'); ?>",

                            type: "post",

                            data: {

                                user_token: token,

                            },

                            success: function(response) {

                                //   alert(response);

                                console.log(response);



                            },

                        });

                    });

                    $('.errorotp').html('OTP Verified')

                    $('.errorotp').css('color', 'green')

                    // window.location.href = "<?php echo base_url(); ?>index.php/user/registration_steptwo?currentpage=1";

                    setTimeout(function() {

                        window.location.href = "<?php echo base_url(); ?>index.php/user/congratulations_gotonikah";

                    }, 1500);

                } else {

                    $('.errorotp').html('Invalid OTP')

                }



            },

        });



    }



    function lettersOnly() {

        var inputValue = event.keyCode;

        if (!(inputValue >= 65 && inputValue <= 122) && (inputValue != 32 && inputValue != 0)) {

            event.preventDefault();

        }

    }



    function tabChange(first, last) 
    {

        if (first.value.length) {

            document.getElementById(last).focus();

        }

    }

    $('input[name="gender"]').change(function() 
    {

        var radioVal = $('input[name="gender"]:checked').val();

        if (radioVal == '1') 
        {

            $('#user_age').children().remove();

            $('#user_age').append('<option value="">Age</option>');

            for (var index = 21; index <= 59; index++) 
            {

            $('#user_age').append('<option value="' + index + '">' + index + '</option>');

            }



        } 
        else
        {

            $('#user_age').children().remove();

            $('#user_age').append('<option value="">Age</option>');

            for (var index = 18; index <= 55; index++) 
            {
            $('#user_age').append('<option value="' + index + '">' + index + '</option>');

            }

        }

    });



    function myFunctionread() 
    {

        var dots = document.getElementById("dots");

        var moreText = document.getElementById("more");

        var btnText = document.getElementById("myBtn");



        if (dots.style.display === "none") {

            dots.style.display = "inline";

            btnText.innerHTML = "Read more";

            moreText.style.display = "none";

        } else {

            dots.style.display = "none";

            btnText.innerHTML = "Read less";

            moreText.style.display = "inline";

        }



    }

    $(window).scroll(function() {

        if ($(this).scrollTop() >= 50) { // If page is scrolled more than 50px

            $('#return-to-top').fadeIn(200); // Fade in the arrow

        } else {

            $('#return-to-top').fadeOut(200); // Else fade out the arrow

        }

    });

    $('#return-to-top').click(function() { // When arrow is clicked

        $('body').animate({

            scrollTop: 0

        }, 500);

    });


// $(window).load(function(){
//   setTimeout(function(){
//       $('#loginModal').modal('show');
//   }, 1000);
// });


    $(document).ready(function() {

        $('.owl-carousel').owlCarousel({

            items: 1,

            merge: true,

            loop: true,

            margin: 10,

            video: true,

            autoplay: true,

            autoplayHoverPause: true,

            lazyLoad: true,

            center: true,

            videoWidth: false, // Default false; Type: Boolean/Number

            videoHeight: false, // Default false; Type: Boolean/Number

            responsive: {

                900: {

                    items: 1.20,

                },

                1000: {

                    items: 2,

                }

            }

        })

    });





    // partner slider

    $(".owl-partner").owlCarousel({

        margin: 25,

        responsiveClass: true,

        nav: false,

        dots: false,

        autoplay: true,

        autoplayHoverPause: false,

        loop: true,

        responsive: {

            0: {

                items: 1.2,

            },

            576: {

                items: 1.5,

            },

            768: {

                items: 2.2,

            },

            992: {

                items: 2.5,

            },

            1200: {

                items: 3.2,

            },

            1400: {

                items: 3.5,

            }

        },

    });



    function myFunctionread() {

        var dots = document.getElementById("dots");

        var moreText = document.getElementById("more");

        var btnText = document.getElementById("myBtn");



        if (dots.style.display === "none") {

            dots.style.display = "inline";

            btnText.innerHTML = "Read more";

            moreText.style.display = "none";

        } else {

            dots.style.display = "none";

            btnText.innerHTML = "Read less";

            moreText.style.display = "inline";

        }

    }

</script>




        <style type="text/css">
        
        @media screen and (max-width: 991px) 
        {
        input#flexCheckDefault
        {
        margin-left:-22px !important;     
        }
        button.btn.cstmBtnColrs.registernow
        {
        margin-left:0px !important;
        margin-top:0px !important;   
        }
        }
        
        
        .fa-li.fa-lg {
        left: -1.85714286em;
        }
        .fa-border {
        padding: .2em .25em .15em;
        border: solid .08em #eee;
        border-radius: .1em;
        }
        .fa-pull-left {
        float: left;
        }
        .fa-pull-right {
        float: right;
        }
        .fa.fa-pull-left {
        margin-right: .3em;
        }
        .fa.fa-pull-right {
        margin-left: .3em;
        }
        .pull-right {
        float: right;
        }
        .pull-left {
        float: left;
        }
        .fa.pull-left {
        margin-right: .3em;
        }
        .fa.pull-right {
        margin-left: .3em;
        }
        .fa-spin {
        -webkit-animation: fa-spin 2s infinite linear;
        animation: fa-spin 2s infinite linear;
        }
        .fa-pulse {
        -webkit-animation: fa-spin 1s infinite steps(8);
        animation: fa-spin 1s infinite steps(8);
        }
        @-webkit-keyframes fa-spin {
        0% {
        -webkit-transform: rotate(0deg);
        transform: rotate(0deg);
        }
        100% {
        -webkit-transform: rotate(359deg);
        transform: rotate(359deg);
        }
        }@keyframes fa-spin {
        0% {
        -webkit-transform: rotate(0deg);
        transform: rotate(0deg);
        }
        100% {
        -webkit-transform: rotate(359deg);
        transform: rotate(359deg);
        }
        }.fa-rotate-90 {
        -ms-filter: "progid:DXImageTransform.Microsoft.BasicImage(rotation=1)";
        -webkit-transform: rotate(90deg);
        -ms-transform: rotate(90deg);
        transform: rotate(90deg);
        }
        .fa-rotate-180 {
        -ms-filter: "progid:DXImageTransform.Microsoft.BasicImage(rotation=2)";
        -webkit-transform: rotate(180deg);
        -ms-transform: rotate(180deg);
        transform: rotate(180deg);
        }
        .fa-rotate-270 {
        -ms-filter: "progid:DXImageTransform.Microsoft.BasicImage(rotation=3)";
        -webkit-transform: rotate(270deg);
        -ms-transform: rotate(270deg);
        transform: rotate(270deg);
        }
        .fa-flip-horizontal {
        -ms-filter: "progid:DXImageTransform.Microsoft.BasicImage(rotation=0,  mirror=1)";
        -webkit-transform: scale(-1, 1);
        -ms-transform: scale(-1, 1);
        transform: scale(-1, 1);
        }
        .fa-flip-vertical {
        -ms-filter: "progid:DXImageTransform.Microsoft.BasicImage(rotation=2,  mirror=1)";
        -webkit-transform: scale(1, -1);
        -ms-transform: scale(1, -1);
        transform: scale(1, -1);
        }
        :root .fa-rotate-90, :root .fa-rotate-180, :root .fa-rotate-270, :root .fa-flip-horizontal, :root .fa-flip-vertical {
        filter: none;
        }
        .fa-stack {
        position: relative;
        display: inline-block;
        width: 2em;
        height: 2em;
        line-height: 2em;
        vertical-align: middle;
        }
        .fa-stack-1x, .fa-stack-2x {
        position: absolute;
        left: 0;
        width: 100%;
        text-align: center;
        }
        .fa-stack-1x {
        line-height: inherit;
        }
        .fa-stack-2x {
        font-size: 2em;
        }
        .fa-inverse {
        color: #fff;
        }
        
        .sr-only {
        position: absolute;
        width: 1px;
        height: 1px;
        padding: 0;
        margin: -1px;
        overflow: hidden;
        clip: rect(0, 0, 0, 0);
        border: 0;
        }
        .sr-only-focusable:active, .sr-only-focusable:focus {
        position: static;
        width: auto;
        height: auto;
        margin: 0;
        overflow: visible;
        clip: auto;
        }
        @font-face {
        font-family: icomoon;
        src: url(../fonts/icomoon.eot?u38989);
        src: url(../fonts/icomoon.eot?u38989#iefix) format("embedded-opentype"), url(../fonts/icomoon.ttf?u38989) format("truetype"), url(../fonts/icomoon.woff?u38989) format("woff"), url(../fonts/icomoon.svg?u38989#icomoon) format("svg");
        font-weight: 400;
        font-style: normal;
        font-display: block;
        }
        [class^=icon--i], [class*=" icon-i-"] {
        font-family: icomoon!important;
        speak: never;
        font-style: normal;
        font-weight: 400;
        font-variant: normal;
        text-transform: none;
        line-height: 1;
        -webkit-font-smoothing: antialiased;
        -moz-osx-font-smoothing: grayscale;
        }
        .icon-i-close:before {
        content: "\e907"}
        .icon-i-message:before {
        content: "\e908"}
        .icon-i-religion:before {
        content: "\e900"}
        .icon-i-gender:before {
        content: "\e901"}
        .icon-i-age:before {
        content: "\e902"}
        .icon-i-education:before {
        content: "\e903"}
        .icon-i-height:before {
        content: "\e904"}
        .icon-i-location:before {
        content: "\e905"}
        .icon-i-occupation:before {
        content: "\e906"}
        :root {
        --blue:  #1a75e8;
        --indigo:  #6610f2;
        --purple:  #6f42c1;
        --pink:  #e83e8c;
        --red:  #e9241d;
        --orange:  #fd7e14;
        --yellow:  #ffc107;
        --green:  #44eb5a;
        --teal:  #20c997;
        --cyan:  #17a2b8;
        --white:  #fff;
        --gray:  #6c757d;
        --gray-dark:  #343a40;
        --primary:  #1a75e8;
        --secondary:  #6c757d;
        --success:  #44eb5a;
        --info:  #17a2b8;
        --warning:  #ffc107;
        --danger:  #e9241d;
        --light:  #f8f9fa;
        --dark:  #343a40;
        --breakpoint-xs:  0;
        --breakpoint-sm:  576px;
        --breakpoint-md:  768px;
        --breakpoint-lg:  992px;
        --breakpoint-xl:  1200px;
        --font-family-sans-serif:  -apple-system,  BlinkMacSystemFont,  "Segoe UI",  Roboto,  "Helvetica Neue",  Arial,  "Noto Sans",  sans-serif,  "Apple Color Emoji",  "Segoe UI Emoji",  "Segoe UI Symbol",  "Noto Color Emoji";
        --font-family-monospace:  SFMono-Regular,  Menlo,  Monaco,  Consolas,  "Liberation Mono",  "Courier New",  monospace;
        }
        *, *::before, *::after {
        box-sizing: border-box;
        }
        html {
        font-family: sans-serif;
        line-height: 1.15;
        -webkit-text-size-adjust: 100%;
        -webkit-tap-highlight-color: transparent;
        }
        article, aside, figcaption, figure, footer, header, hgroup, main, nav, section {
        display: block;
        }
        body {
        margin: 0;
        font-family: -apple-system, BlinkMacSystemFont, segoe ui, Roboto, helvetica neue, Arial, noto sans, sans-serif, apple color emoji, segoe ui emoji, segoe ui symbol, noto color emoji;
        font-size: 1rem;
        font-weight: 400;
        line-height: 1.5;
        color: #212529;
        text-align: left;
        background-color: #fff;
        }
        [tabindex="-1"]:focus {
        outline: 0!important;
        }
        hr {
        box-sizing: content-box;
        height: 0;
        overflow: visible;
        }
        
        p {
        margin-top: 0;
        margin-bottom: 1rem;
        }
        abbr[title], abbr[data-original-title] {
        text-decoration: underline;
        text-decoration: underline dotted;
        cursor: help;
        border-bottom: 0;
        text-decoration-skip-ink: none;
        }
        address {
        margin-bottom: 1rem;
        font-style: normal;
        line-height: inherit;
        }
        ol, ul, dl {
        margin-top: 0;
        margin-bottom: 1rem;
        }
        ol ol, ul ul, ol ul, ul ol {
        margin-bottom: 0;
        }
        dt {
        font-weight: 700;
        }
        dd {
        margin-bottom: .5rem;
        margin-left: 0;
        }
        blockquote {
        margin: 0 0 1rem;
        }
        b, strong {
        font-weight: bolder;
        }
        small {
        font-size: 80%}
        sub, sup {
        position: relative;
        font-size: 75%;
        line-height: 0;
        vertical-align: baseline;
        }
        sub {
        bottom: -.25em;
        }
        sup {
        top: -.5em;
        }
        a {
        color: #1a75e8;
        text-decoration: none;
        background-color: transparent;
        }
        a:hover {
        text-decoration: underline;
        }
        a:not([href]):not([tabindex]) {
        text-decoration: none;
        }
        a:not([href]):not([tabindex]):hover, a:not([href]):not([tabindex]):focus {
        text-decoration: none;
        }
        a:not([href]):not([tabindex]):focus {
        outline: 0;
        }
        pre, code, kbd, samp {
        font-family: SFMono-Regular, Menlo, Monaco, Consolas, liberation mono, courier new, monospace;
        font-size: 1em;
        }
        pre {
        margin-top: 0;
        margin-bottom: 1rem;
        overflow: auto;
        }
        figure {
        margin: 0 0 1rem;
        }
        img {
        vertical-align: middle;
        border-style: none;
        }
        svg {
        overflow: hidden;
        vertical-align: middle;
        }
        table {
        border-collapse: collapse;
        }
        caption {
        padding-top: .75rem;
        padding-bottom: .75rem;
        color: #6c757d;
        text-align: left;
        caption-side: bottom;
        }
        th {
        text-align: inherit;
        }
        label {
        display: inline-block;
        margin-bottom: .5rem;
        }
        button {
        border-radius: 0;
        }
        button:focus {
        outline: 1px dotted;
        outline: 5px auto -webkit-focus-ring-color;
        }
        input, button, select, optgroup, textarea {
        margin: 0;
        font-family: inherit;
        font-size: inherit;
        line-height: inherit;
        }
        button, input {
        overflow: visible;
        }
        button, select {
        text-transform: none;
        }
        button, [type=button], [type=reset], [type=submit] {
        -webkit-appearance: button;
        }
        button::-moz-focus-inner, [type=button]::-moz-focus-inner, [type=reset]::-moz-focus-inner, [type=submit]::-moz-focus-inner {
        padding: 0;
        border-style: none;
        }
        input[type=radio], input[type=checkbox] {
        box-sizing: border-box;
        padding: 0;
        }
        input[type=date], input[type=time], input[type=datetime-local], input[type=month] {
        -webkit-appearance: listbox;
        }
        textarea {
        overflow: auto;
        resize: vertical;
        }
        fieldset {
        min-width: 0;
        padding: 0;
        margin: 0;
        border: 0;
        }
        legend {
        display: block;
        width: 100%;
        max-width: 100%;
        padding: 0;
        margin-bottom: .5rem;
        font-size: 1.5rem;
        line-height: inherit;
        color: inherit;
        white-space: normal;
        }
        progress {
        vertical-align: baseline;
        }
        [type=number]::-webkit-inner-spin-button, [type=number]::-webkit-outer-spin-button {
        height: auto;
        }
        [type=search] {
        outline-offset: -2px;
        -webkit-appearance: none;
        }
        [type=search]::-webkit-search-decoration {
        -webkit-appearance: none;
        }
        ::-webkit-file-upload-button {
        font: inherit;
        -webkit-appearance: button;
        }
        output {
        display: inline-block;
        }
        summary {
        display: list-item;
        cursor: pointer;
        }
        template {
        display: none;
        }
        [hidden] {
        display: none!important;
        }
        
        .lead {
        font-size: 1.25rem;
        font-weight: 300;
        }
        .display-1 {
        font-size: 6rem;
        font-weight: 300;
        line-height: 1.2;
        }
        .display-2 {
        font-size: 5.5rem;
        font-weight: 300;
        line-height: 1.2;
        }
        .display-3 {
        font-size: 4.5rem;
        font-weight: 300;
        line-height: 1.2;
        }
        .display-4 {
        font-size: 3.5rem;
        font-weight: 300;
        line-height: 1.2;
        }
        hr {
        margin-top: 1rem;
        margin-bottom: 1rem;
        border: 0;
        border-top: 1px solid rgba(0, 0, 0, .1);
        }
        small, .small {
        font-size: 80%;
        font-weight: 400;
        }
        mark, .mark {
        padding: .2em;
        background-color: #fcf8e3;
        }
        .list-unstyled {
        padding-left: 0;
        list-style: none;
        }
        .list-inline {
        padding-left: 0;
        list-style: none;
        }
        .list-inline-item {
        display: inline-block;
        }
        .list-inline-item:not(:last-child) {
        margin-right: .5rem;
        }
        .initialism {
        font-size: 90%;
        text-transform: uppercase;
        }
        .blockquote {
        margin-bottom: 1rem;
        font-size: 1.25rem;
        }
        .blockquote-footer {
        display: block;
        font-size: 80%;
        color: #6c757d;
        }
        .blockquote-footer::before {
        content: "\2014\00A0"}
        .img-fluid {
        max-width: 100%;
        height: auto;
        }
        .img-thumbnail {
        padding: .25rem;
        background-color: #fff;
        border: 1px solid #dee2e6;
        border-radius: .25rem;
        max-width: 100%;
        height: auto;
        }
        .figure {
        display: inline-block;
        }
        .figure-img {
        margin-bottom: .5rem;
        line-height: 1;
        }
        .figure-caption {
        font-size: 90%;
        color: #6c757d;
        }
        .container {
        width: 100%;
        padding-right: 15px;
        padding-left: 15px;
        margin-right: auto;
        margin-left: auto;
        }
        @media(min-width:576px) {
        .container {
        max-width: 540px;
        }
        }@media(min-width:768px) {
        .container {
        max-width: 720px;
        }
        }@media(min-width:992px) {
        .container {
        max-width: 960px;
        }
        }@media(min-width:1200px) {
        .container {
        max-width: 1140px;
        }
        }.container-fluid {
        width: 100%;
        padding-right: 15px;
        padding-left: 15px;
        margin-right: auto;
        margin-left: auto;
        }
        .row {
        display: flex;
        flex-wrap: wrap;
        margin-right: -15px;
        margin-left: -15px;
        }
        .no-gutters {
        margin-right: 0;
        margin-left: 0;
        }
        .no-gutters>.col, .no-gutters>[class*=col-] {
        padding-right: 0;
        padding-left: 0;
        }
        
        
        
        /*.col-1, .col-2, .col-3, .col-4, .col-5, .col-6, .col-7, .col-8, .col-9, .col-10, .col-11, .col-12, .col, .col-auto, .col-sm-1, .col-sm-2, .col-sm-3, .col-sm-4, .col-sm-5, .col-sm-6, .col-sm-7, .col-sm-8, .col-sm-9, .col-sm-10, .col-sm-11, .col-sm-12, .col-sm, .col-sm-auto, .col-md-1, .col-md-2, .col-md-3, .col-md-4, .col-md-5, .col-md-6, .col-md-7, .col-md-8, .col-md-9, .col-md-10, .col-md-11, .col-md-12, .col-md, .col-md-auto, .col-lg-1, .col-lg-2, .col-lg-3, .col-lg-4, .col-lg-5, .col-lg-6, .col-lg-7, .col-lg-8, .col-lg-9, .col-lg-10, .col-lg-11, .col-lg-12, .col-lg, .col-lg-auto, .col-xl-1, .col-xl-2, .col-xl-3, .col-xl-4, .col-xl-5, .col-xl-6, .col-xl-7, .col-xl-8, .col-xl-9, .col-xl-10, .col-xl-11, .col-xl-12, .col-xl, .col-xl-auto {*/
        /*    position: relative;*/
        /*    width: 100%;*/
        /*    padding-right: 15px;*/
        /*    padding-left: 15px;*/
        /*}*/
        /*.col {*/
        /*    flex-basis: 0;*/
        /*    flex-grow: 1;*/
        /*    max-width: 100%}*/
        /*.col-auto {*/
        /*    flex: 0 0 auto;*/
        /*    width: auto;*/
        /*    max-width: 100%}*/
        /*.col-1 {*/
        /*    flex: 0 0 8.33333%;*/
        /*    max-width: 8.33333%}*/
        /*.col-2 {*/
        /*    flex: 0 0 16.66667%;*/
        /*    max-width: 16.66667%}*/
        /*.col-3 {*/
        /*    flex: 0 0 25%;*/
        /*    max-width: 25%}*/
        /*.col-4 {*/
        /*    flex: 0 0 33.33333%;*/
        /*    max-width: 33.33333%}*/
        /*.col-5 {*/
        /*    flex: 0 0 41.66667%;*/
        /*    max-width: 41.66667%}*/
        /*.col-6 {*/
        /*    flex: 0 0 50%;*/
        /*    max-width: 50%}*/
        /*.col-7 {*/
        /*    flex: 0 0 58.33333%;*/
        /*    max-width: 58.33333%}*/
        /*.col-8 {*/
        /*    flex: 0 0 66.66667%;*/
        /*    max-width: 66.66667%}*/
        /*.col-9 {*/
        /*    flex: 0 0 75%;*/
        /*    max-width: 75%}*/
        /*.col-10 {*/
        /*    flex: 0 0 83.33333%;*/
        /*    max-width: 83.33333%}*/
        /*.col-11 {*/
        /*    flex: 0 0 91.66667%;*/
        /*    max-width: 91.66667%}*/
        /*.col-12 {*/
        /*    flex: 0 0 100%;*/
        /*    max-width: 100%}*/
        
        
        
        .order-first {
        order: -1;
        }
        .order-last {
        order: 13;
        }
        .order-0 {
        order: 0;
        }
        .order-1 {
        order: 1;
        }
        .order-2 {
        order: 2;
        }
        .order-3 {
        order: 3;
        }
        .order-4 {
        order: 4;
        }
        .order-5 {
        order: 5;
        }
        .order-6 {
        order: 6;
        }
        .order-7 {
        order: 7;
        }
        .order-8 {
        order: 8;
        }
        .order-9 {
        order: 9;
        }
        .order-10 {
        order: 10;
        }
        .order-11 {
        order: 11;
        }
        .order-12 {
        order: 12;
        }
        .offset-1 {
        margin-left: 8.33333%}
        .offset-2 {
        margin-left: 16.66667%}
        .offset-3 {
        margin-left: 25%}
        .offset-4 {
        margin-left: 33.33333%}
        .offset-5 {
        margin-left: 41.66667%}
        .offset-6 {
        margin-left: 50%}
        .offset-7 {
        margin-left: 58.33333%}
        .offset-8 {
        margin-left: 66.66667%}
        .offset-9 {
        margin-left: 75%}
        .offset-10 {
        margin-left: 83.33333%}
        .offset-11 {
        margin-left: 91.66667%}
        @media(min-width:576px) {
        .col-sm {
        flex-basis: 0;
        flex-grow: 1;
        max-width: 100%}
        .col-sm-auto {
        flex: 0 0 auto;
        width: auto;
        max-width: 100%}
        .col-sm-1 {
        flex: 0 0 8.33333%;
        max-width: 8.33333%}
        .col-sm-2 {
        flex: 0 0 16.66667%;
        max-width: 16.66667%}
        .col-sm-3 {
        flex: 0 0 25%;
        max-width: 25%}
        .col-sm-4 {
        flex: 0 0 33.33333%;
        max-width: 33.33333%}
        .col-sm-5 {
        flex: 0 0 41.66667%;
        max-width: 41.66667%}
        .col-sm-6 {
        flex: 0 0 50%;
        max-width: 50%}
        .col-sm-7 {
        flex: 0 0 58.33333%;
        max-width: 58.33333%}
        .col-sm-8 {
        flex: 0 0 66.66667%;
        max-width: 66.66667%}
        .col-sm-9 {
        flex: 0 0 75%;
        max-width: 75%}
        .col-sm-10 {
        flex: 0 0 83.33333%;
        max-width: 83.33333%}
        .col-sm-11 {
        flex: 0 0 91.66667%;
        max-width: 91.66667%}
        .col-sm-12 {
        flex: 0 0 100%;
        max-width: 100%}
        .order-sm-first {
        order: -1;
        }
        .order-sm-last {
        order: 13;
        }
        .order-sm-0 {
        order: 0;
        }
        .order-sm-1 {
        order: 1;
        }
        .order-sm-2 {
        order: 2;
        }
        .order-sm-3 {
        order: 3;
        }
        .order-sm-4 {
        order: 4;
        }
        .order-sm-5 {
        order: 5;
        }
        .order-sm-6 {
        order: 6;
        }
        .order-sm-7 {
        order: 7;
        }
        .order-sm-8 {
        order: 8;
        }
        .order-sm-9 {
        order: 9;
        }
        .order-sm-10 {
        order: 10;
        }
        .order-sm-11 {
        order: 11;
        }
        .order-sm-12 {
        order: 12;
        }
        .offset-sm-0 {
        margin-left: 0;
        }
        .offset-sm-1 {
        margin-left: 8.33333%}
        .offset-sm-2 {
        margin-left: 16.66667%}
        .offset-sm-3 {
        margin-left: 25%}
        .offset-sm-4 {
        margin-left: 33.33333%}
        .offset-sm-5 {
        margin-left: 41.66667%}
        .offset-sm-6 {
        margin-left: 50%}
        .offset-sm-7 {
        margin-left: 58.33333%}
        .offset-sm-8 {
        margin-left: 66.66667%}
        .offset-sm-9 {
        margin-left: 75%}
        .offset-sm-10 {
        margin-left: 83.33333%}
        .offset-sm-11 {
        margin-left: 91.66667%}
        }@media(min-width:768px) {
        .col-md {
        flex-basis: 0;
        flex-grow: 1;
        max-width: 100%}
        .col-md-auto {
        flex: 0 0 auto;
        width: auto;
        max-width: 100%}
        .col-md-1 {
        flex: 0 0 8.33333%;
        max-width: 8.33333%}
        .col-md-2 {
        flex: 0 0 16.66667%;
        max-width: 16.66667%}
        .col-md-3 {
        flex: 0 0 25%;
        max-width: 25%}
        .col-md-4 {
        flex: 0 0 33.33333%;
        max-width: 33.33333%}
        .col-md-5 {
        flex: 0 0 41.66667%;
        max-width: 41.66667%}
        .col-md-6 {
        flex: 0 0 50%;
        max-width: 50%}
        .col-md-7 {
        flex: 0 0 58.33333%;
        max-width: 58.33333%}
        .col-md-8 {
        flex: 0 0 66.66667%;
        max-width: 66.66667%}
        .col-md-9 {
        flex: 0 0 75%;
        max-width: 75%}
        .col-md-10 {
        flex: 0 0 83.33333%;
        max-width: 83.33333%}
        .col-md-11 {
        flex: 0 0 91.66667%;
        max-width: 91.66667%}
        .col-md-12 {
        flex: 0 0 100%;
        max-width: 100%}
        .order-md-first {
        order: -1;
        }
        .order-md-last {
        order: 13;
        }
        .order-md-0 {
        order: 0;
        }
        .order-md-1 {
        order: 1;
        }
        .order-md-2 {
        order: 2;
        }
        .order-md-3 {
        order: 3;
        }
        .order-md-4 {
        order: 4;
        }
        .order-md-5 {
        order: 5;
        }
        .order-md-6 {
        order: 6;
        }
        .order-md-7 {
        order: 7;
        }
        .order-md-8 {
        order: 8;
        }
        .order-md-9 {
        order: 9;
        }
        .order-md-10 {
        order: 10;
        }
        .order-md-11 {
        order: 11;
        }
        .order-md-12 {
        order: 12;
        }
        .offset-md-0 {
        margin-left: 0;
        }
        .offset-md-1 {
        margin-left: 8.33333%}
        .offset-md-2 {
        margin-left: 16.66667%}
        .offset-md-3 {
        margin-left: 25%}
        .offset-md-4 {
        margin-left: 33.33333%}
        .offset-md-5 {
        margin-left: 41.66667%}
        .offset-md-6 {
        margin-left: 50%}
        .offset-md-7 {
        margin-left: 58.33333%}
        .offset-md-8 {
        margin-left: 66.66667%}
        .offset-md-9 {
        margin-left: 75%}
        .offset-md-10 {
        margin-left: 83.33333%}
        .offset-md-11 {
        margin-left: 91.66667%}
        }@media(min-width:992px) {
        .col-lg {
        flex-basis: 0;
        flex-grow: 1;
        max-width: 100%}
        .col-lg-auto {
        flex: 0 0 auto;
        width: auto;
        max-width: 100%}
        .col-lg-1 {
        flex: 0 0 8.33333%;
        max-width: 8.33333%}
        .col-lg-2 {
        flex: 0 0 16.66667%;
        max-width: 16.66667%}
        .col-lg-3 {
        flex: 0 0 25%;
        max-width: 25%}
        .col-lg-4 {
        flex: 0 0 33.33333%;
        max-width: 33.33333%}
        .col-lg-5 {
        flex: 0 0 41.66667%;
        max-width: 41.66667%}
        .col-lg-6 {
        flex: 0 0 50%;
        max-width: 50%}
        .col-lg-7 {
        flex: 0 0 58.33333%;
        max-width: 58.33333%}
        .col-lg-8 {
        flex: 0 0 66.66667%;
        max-width: 66.66667%}
        .col-lg-9 {
        flex: 0 0 75%;
        max-width: 75%}
        .col-lg-10 {
        flex: 0 0 83.33333%;
        max-width: 83.33333%}
        .col-lg-11 {
        flex: 0 0 91.66667%;
        max-width: 91.66667%}
        .col-lg-12 {
        flex: 0 0 100%;
        max-width: 100%}
        .order-lg-first {
        order: -1;
        }
        .order-lg-last {
        order: 13;
        }
        .order-lg-0 {
        order: 0;
        }
        .order-lg-1 {
        order: 1;
        }
        .order-lg-2 {
        order: 2;
        }
        .order-lg-3 {
        order: 3;
        }
        .order-lg-4 {
        order: 4;
        }
        .order-lg-5 {
        order: 5;
        }
        .order-lg-6 {
        order: 6;
        }
        .order-lg-7 {
        order: 7;
        }
        .order-lg-8 {
        order: 8;
        }
        .order-lg-9 {
        order: 9;
        }
        .order-lg-10 {
        order: 10;
        }
        .order-lg-11 {
        order: 11;
        }
        .order-lg-12 {
        order: 12;
        }
        .offset-lg-0 {
        margin-left: 0;
        }
        .offset-lg-1 {
        margin-left: 8.33333%}
        .offset-lg-2 {
        margin-left: 16.66667%}
        .offset-lg-3 {
        margin-left: 25%}
        .offset-lg-4 {
        margin-left: 33.33333%}
        .offset-lg-5 {
        margin-left: 41.66667%}
        .offset-lg-6 {
        margin-left: 50%}
        .offset-lg-7 {
        margin-left: 58.33333%}
        .offset-lg-8 {
        margin-left: 66.66667%}
        .offset-lg-9 {
        margin-left: 75%}
        .offset-lg-10 {
        margin-left: 83.33333%}
        .offset-lg-11 {
        margin-left: 91.66667%}
        }@media(min-width:1200px) {
        .col-xl {
        flex-basis: 0;
        flex-grow: 1;
        max-width: 100%}
        .col-xl-auto {
        flex: 0 0 auto;
        width: auto;
        max-width: 100%}
        .col-xl-1 {
        flex: 0 0 8.33333%;
        max-width: 8.33333%}
        .col-xl-2 {
        flex: 0 0 16.66667%;
        max-width: 16.66667%}
        .col-xl-3 {
        flex: 0 0 25%;
        max-width: 25%}
        .col-xl-4 {
        flex: 0 0 33.33333%;
        max-width: 33.33333%}
        .col-xl-5 {
        flex: 0 0 41.66667%;
        max-width: 41.66667%}
        .col-xl-6 {
        flex: 0 0 50%;
        max-width: 50%}
        .col-xl-7 {
        flex: 0 0 58.33333%;
        max-width: 58.33333%}
        .col-xl-8 {
        flex: 0 0 66.66667%;
        max-width: 66.66667%}
        .col-xl-9 {
        flex: 0 0 75%;
        max-width: 75%}
        .col-xl-10 {
        flex: 0 0 83.33333%;
        max-width: 83.33333%}
        .col-xl-11 {
        flex: 0 0 91.66667%;
        max-width: 91.66667%}
        .col-xl-12 {
        flex: 0 0 100%;
        max-width: 100%}
        .order-xl-first {
        order: -1;
        }
        .order-xl-last {
        order: 13;
        }
        .order-xl-0 {
        order: 0;
        }
        .order-xl-1 {
        order: 1;
        }
        .order-xl-2 {
        order: 2;
        }
        .order-xl-3 {
        order: 3;
        }
        .order-xl-4 {
        order: 4;
        }
        .order-xl-5 {
        order: 5;
        }
        .order-xl-6 {
        order: 6;
        }
        .order-xl-7 {
        order: 7;
        }
        .order-xl-8 {
        order: 8;
        }
        .order-xl-9 {
        order: 9;
        }
        .order-xl-10 {
        order: 10;
        }
        .order-xl-11 {
        order: 11;
        }
        .order-xl-12 {
        order: 12;
        }
        .offset-xl-0 {
        margin-left: 0;
        }
        .offset-xl-1 {
        margin-left: 8.33333%}
        .offset-xl-2 {
        margin-left: 16.66667%}
        .offset-xl-3 {
        margin-left: 25%}
        .offset-xl-4 {
        margin-left: 33.33333%}
        .offset-xl-5 {
        margin-left: 41.66667%}
        .offset-xl-6 {
        margin-left: 50%}
        .offset-xl-7 {
        margin-left: 58.33333%}
        .offset-xl-8 {
        margin-left: 66.66667%}
        .offset-xl-9 {
        margin-left: 75%}
        .offset-xl-10 {
        margin-left: 83.33333%}
        .offset-xl-11 {
        margin-left: 91.66667%}
        }.table {
        width: 100%;
        margin-bottom: 1rem;
        background-color: transparent;
        }
        .table th, .table td {
        padding: .75rem;
        vertical-align: top;
        border-top: 1px solid #dee2e6;
        }
        .table thead th {
        vertical-align: bottom;
        border-bottom: 2px solid #dee2e6;
        }
        .table tbody+tbody {
        border-top: 2px solid #dee2e6;
        }
        .table .table {
        background-color: #fff;
        }
        .table-sm th, .table-sm td {
        padding: .3rem;
        }
        .table-bordered {
        border: 1px solid #dee2e6;
        }
        .table-bordered th, .table-bordered td {
        border: 1px solid #dee2e6;
        }
        .table-bordered thead th, .table-bordered thead td {
        border-bottom-width: 2px;
        }
        .table-borderless th, .table-borderless td, .table-borderless thead th, .table-borderless tbody+tbody {
        border: 0;
        }
        .table-striped tbody tr:nth-of-type(odd) {
        background-color: rgba(0, 0, 0, .05);
        }
        .table-hover tbody tr:hover {
        background-color: rgba(0, 0, 0, .075);
        }
        .table-primary, .table-primary>th, .table-primary>td {
        background-color: #bfd8f9;
        }
        .table-primary th, .table-primary td, .table-primary thead th, .table-primary tbody+tbody {
        border-color: #88b7f3;
        }
        .table-hover .table-primary:hover {
        background-color: #a8caf7;
        }
        .table-hover .table-primary:hover>td, .table-hover .table-primary:hover>th {
        background-color: #a8caf7;
        }
        .table-secondary, .table-secondary>th, .table-secondary>td {
        background-color: #d6d8db;
        }
        .table-secondary th, .table-secondary td, .table-secondary thead th, .table-secondary tbody+tbody {
        border-color: #b3b7bb;
        }
        .table-hover .table-secondary:hover {
        background-color: #c8cbcf;
        }
        .table-hover .table-secondary:hover>td, .table-hover .table-secondary:hover>th {
        background-color: #c8cbcf;
        }
        .table-success, .table-success>th, .table-success>td {
        background-color: #cbf9d1;
        }
        .table-success th, .table-success td, .table-success thead th, .table-success tbody+tbody {
        border-color: #9ef5a9;
        }
        .table-hover .table-success:hover {
        background-color: #b4f6bd;
        }
        .table-hover .table-success:hover>td, .table-hover .table-success:hover>th {
        background-color: #b4f6bd;
        }
        .table-info, .table-info>th, .table-info>td {
        background-color: #bee5eb;
        }
        .table-info th, .table-info td, .table-info thead th, .table-info tbody+tbody {
        border-color: #86cfda;
        }
        .table-hover .table-info:hover {
        background-color: #abdde5;
        }
        .table-hover .table-info:hover>td, .table-hover .table-info:hover>th {
        background-color: #abdde5;
        }
        .table-warning, .table-warning>th, .table-warning>td {
        background-color: #ffeeba;
        }
        .table-warning th, .table-warning td, .table-warning thead th, .table-warning tbody+tbody {
        border-color: #ffdf7e;
        }
        .table-hover .table-warning:hover {
        background-color: #ffe8a1;
        }
        .table-hover .table-warning:hover>td, .table-hover .table-warning:hover>th {
        background-color: #ffe8a1;
        }
        .table-danger, .table-danger>th, .table-danger>td {
        background-color: #f9c2c0;
        }
        .table-danger th, .table-danger td, .table-danger thead th, .table-danger tbody+tbody {
        border-color: #f48d89;
        }
        .table-hover .table-danger:hover {
        background-color: #f7aba9;
        }
        .table-hover .table-danger:hover>td, .table-hover .table-danger:hover>th {
        background-color: #f7aba9;
        }
        .table-light, .table-light>th, .table-light>td {
        background-color: #fdfdfe;
        }
        .table-light th, .table-light td, .table-light thead th, .table-light tbody+tbody {
        border-color: #fbfcfc;
        }
        .table-hover .table-light:hover {
        background-color: #ececf6;
        }
        .table-hover .table-light:hover>td, .table-hover .table-light:hover>th {
        background-color: #ececf6;
        }
        .table-dark, .table-dark>th, .table-dark>td {
        background-color: #c6c8ca;
        }
        .table-dark th, .table-dark td, .table-dark thead th, .table-dark tbody+tbody {
        border-color: #95999c;
        }
        .table-hover .table-dark:hover {
        background-color: #b9bbbe;
        }
        .table-hover .table-dark:hover>td, .table-hover .table-dark:hover>th {
        background-color: #b9bbbe;
        }
        .table-active, .table-active>th, .table-active>td {
        background-color: rgba(0, 0, 0, .075);
        }
        .table-hover .table-active:hover {
        background-color: rgba(0, 0, 0, .075);
        }
        .table-hover .table-active:hover>td, .table-hover .table-active:hover>th {
        background-color: rgba(0, 0, 0, .075);
        }
        .table .thead-dark th {
        color: #fff;
        background-color: #212529;
        border-color: #32383e;
        }
        .table .thead-light th {
        color: #495057;
        background-color: #e9ecef;
        border-color: #dee2e6;
        }
        .table-dark {
        color: #fff;
        background-color: #212529;
        }
        .table-dark th, .table-dark td, .table-dark thead th {
        border-color: #32383e;
        }
        .table-dark.table-bordered {
        border: 0;
        }
        .table-dark.table-striped tbody tr:nth-of-type(odd) {
        background-color: rgba(255, 255, 255, .05);
        }
        .table-dark.table-hover tbody tr:hover {
        background-color: rgba(255, 255, 255, .075);
        }
        @media(max-width:575.98px) {
        .table-responsive-sm {
        display: block;
        width: 100%;
        overflow-x: auto;
        -webkit-overflow-scrolling: touch;
        -ms-overflow-style: -ms-autohiding-scrollbar;
        }
        .table-responsive-sm>.table-bordered {
        border: 0;
        }
        }@media(max-width:767.98px) {
        .table-responsive-md {
        display: block;
        width: 100%;
        overflow-x: auto;
        -webkit-overflow-scrolling: touch;
        -ms-overflow-style: -ms-autohiding-scrollbar;
        }
        .table-responsive-md>.table-bordered {
        border: 0;
        }
        }@media(max-width:991.98px) {
        .table-responsive-lg {
        display: block;
        width: 100%;
        overflow-x: auto;
        -webkit-overflow-scrolling: touch;
        -ms-overflow-style: -ms-autohiding-scrollbar;
        }
        .table-responsive-lg>.table-bordered {
        border: 0;
        }
        }@media(max-width:1199.98px) {
        .table-responsive-xl {
        display: block;
        width: 100%;
        overflow-x: auto;
        -webkit-overflow-scrolling: touch;
        -ms-overflow-style: -ms-autohiding-scrollbar;
        }
        .table-responsive-xl>.table-bordered {
        border: 0;
        }
        }.table-responsive {
        display: block;
        width: 100%;
        overflow-x: auto;
        -webkit-overflow-scrolling: touch;
        -ms-overflow-style: -ms-autohiding-scrollbar;
        }
        .table-responsive>.table-bordered {
        border: 0;
        }
        .form-control {
        display: block;
        width: 100%;
        height: calc(2.25rem + 2px);
        padding: .375rem .75rem;
        font-size: 1rem;
        font-weight: 400;
        line-height: 1.5;
        color: #495057;
        background-color: #fff;
        background-clip: padding-box;
        border: 1px solid #ced4da;
        border-radius: .25rem;
        transition: border-color .15s ease-in-out, box-shadow .15s ease-in-out;
        }
        @media screen and (prefers-reduced-motion:reduce) {
        .form-control {
        transition: none;
        }
        }.form-control::-ms-expand {
        background-color: transparent;
        border: 0;
        }
        .form-control:focus {
        color: #495057;
        background-color: #fff;
        border-color: #8ebbf4;
        outline: 0;
        box-shadow: 0 0 0 .2rem rgba(26, 117, 232, .25);
        }
        .form-control::placeholder {
        color: #6c757d;
        opacity: 1;
        }
        .form-control:disabled, .form-control[readonly] {
        background-color: #e9ecef;
        opacity: 1;
        }
        select.form-control:focus::-ms-value {
        color: #495057;
        background-color: #fff;
        }
        .form-control-file, .form-control-range {
        display: block;
        width: 100%}
        .col-form-label {
        padding-top: calc(0.375rem + 1px);
        padding-bottom: calc(0.375rem + 1px);
        margin-bottom: 0;
        font-size: inherit;
        line-height: 1.5;
        }
        .col-form-label-lg {
        padding-top: calc(0.5rem + 1px);
        padding-bottom: calc(0.5rem + 1px);
        font-size: 1.25rem;
        line-height: 1.5;
        }
        .col-form-label-sm {
        padding-top: calc(0.25rem + 1px);
        padding-bottom: calc(0.25rem + 1px);
        font-size: .875rem;
        line-height: 1.5;
        }
        .form-control-plaintext {
        display: block;
        width: 100%;
        padding-top: .375rem;
        padding-bottom: .375rem;
        margin-bottom: 0;
        line-height: 1.5;
        color: #212529;
        background-color: transparent;
        border: solid transparent;
        border-width: 1px 0;
        }
        .form-control-plaintext.form-control-sm, .form-control-plaintext.form-control-lg {
        padding-right: 0;
        padding-left: 0;
        }
        .form-control-sm {
        height: calc(1.8125rem + 2px);
        padding: .25rem .5rem;
        font-size: .875rem;
        line-height: 1.5;
        border-radius: .2rem;
        }
        .form-control-lg {
        height: calc(2.875rem + 2px);
        padding: .5rem 1rem;
        font-size: 1.25rem;
        line-height: 1.5;
        border-radius: .3rem;
        }
        select.form-control[size], select.form-control[multiple] {
        height: auto;
        }
        textarea.form-control {
        height: auto;
        }
        .form-group {
        margin-bottom: 1rem;
        }
        .form-text {
        display: block;
        margin-top: .25rem;
        }
        .form-row {
        display: flex;
        flex-wrap: wrap;
        margin-right: -5px;
        margin-left: -5px;
        }
        .form-row>.col, .form-row>[class*=col-] {
        padding-right: 5px;
        padding-left: 5px;
        }
        .form-check {
        position: relative;
        display: block;
        padding-left: 1.25rem;
        }
        .form-check-input {
        position: absolute;
        margin-top: .3rem;
        margin-left: -1.25rem;
        }
        .form-check-input:disabled~.form-check-label {
        color: #6c757d;
        }
        .form-check-label {
        margin-bottom: 0;
        }
        .form-check-inline {
        display: inline-flex;
        align-items: center;
        padding-left: 0;
        margin-right: .75rem;
        }
        .form-check-inline .form-check-input {
        position: static;
        margin-top: 0;
        margin-right: .3125rem;
        margin-left: 0;
        }
        .valid-feedback {
        display: none;
        width: 100%;
        margin-top: .25rem;
        font-size: 80%;
        color: #44eb5a;
        }
        .valid-tooltip {
        position: absolute;
        top: 100%;
        z-index: 5;
        display: none;
        max-width: 100%;
        padding: .25rem .5rem;
        margin-top: .1rem;
        font-size: .875rem;
        line-height: 1.5;
        color: #212529;
        background-color: rgba(68, 235, 90, .9);
        border-radius: .25rem;
        }
        .was-validated .form-control:valid, .form-control.is-valid {
        border-color: #44eb5a;
        padding-right: 2.25rem;
        background-repeat: no-repeat;
        background-position: center right calc(2.25rem/4);
        background-size: calc(2.25rem/2) calc(2.25rem/2);
        background-image: url(data:image/svg+xml;
        base64, PHN2ZyB4bWxucz0naHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmcnIHZpZXdCb3g9JzAgMCA4IDgnPjxwYXRoIGZpbGw9JyM0NEVCNUEnIGQ9J00yLjMgNi43M0wuNiA0LjUzYy0uNC0xLjA0LjQ2LTEuNCAxLjEtLjhsMS4xIDEuNCAzLjQtMy44Yy42LS42MyAxLjYtLjI3IDEuMi43bC00IDQuNmMtLjQzLjUtLjguNC0xLjEuMXonLz48L3N2Zz4=);
        }
        .was-validated .form-control: valid:focus, .form-control.is-valid:focus {
        border-color: #44eb5a;
        box-shadow: 0 0 0 .2rem rgba(68, 235, 90, .25);
        }
        .was-validated .form-control:valid~.valid-feedback, .was-validated .form-control:valid~.valid-tooltip, .form-control.is-valid~.valid-feedback, .form-control.is-valid~.valid-tooltip {
        display: block;
        }
        .was-validated textarea.form-control:valid, textarea.form-control.is-valid {
        padding-right: 2.25rem;
        background-position: top calc(2.25rem/4) right calc(2.25rem/4);
        }
        .was-validated .custom-select:valid, .custom-select.is-valid {
        border-color: #44eb5a;
        padding-right: 3.4375rem;
        background: url("data:image/svg+xml, %3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 4 5'%3e%3cpath fill='%23343a40' d='M2 0L0 2h4zm0 5L0 3h4z'/%3e%3c/svg%3e") no-repeat right 0.75rem center/8px 10px, url("data:image/svg+xml, %3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 8 8'%3e%3cpath fill='%2344EB5A' d='M2.3 6.73L.6 4.53c-.4-1.04.46-1.4 1.1-.8l1.1 1.4 3.4-3.8c.6-.63 1.6-.27 1.2.7l-4 4.6c-.43.5-.8.4-1.1.1z'/%3e%3c/svg%3e") no-repeat center right 1.75rem/1.125rem 1.125rem;
        }
        .was-validated .custom-select:valid:focus, .custom-select.is-valid:focus {
        border-color: #44eb5a;
        box-shadow: 0 0 0 .2rem rgba(68, 235, 90, .25);
        }
        .was-validated .custom-select:valid~.valid-feedback, .was-validated .custom-select:valid~.valid-tooltip, .custom-select.is-valid~.valid-feedback, .custom-select.is-valid~.valid-tooltip {
        display: block;
        }
        .was-validated .form-control-file:valid~.valid-feedback, .was-validated .form-control-file:valid~.valid-tooltip, .form-control-file.is-valid~.valid-feedback, .form-control-file.is-valid~.valid-tooltip {
        display: block;
        }
        .was-validated .form-check-input:valid~.form-check-label, .form-check-input.is-valid~.form-check-label {
        color: #44eb5a;
        }
        .was-validated .form-check-input:valid~.valid-feedback, .was-validated .form-check-input:valid~.valid-tooltip, .form-check-input.is-valid~.valid-feedback, .form-check-input.is-valid~.valid-tooltip {
        display: block;
        }
        .was-validated .custom-control-input:valid~.custom-control-label, .custom-control-input.is-valid~.custom-control-label {
        color: #44eb5a;
        }
        .was-validated .custom-control-input:valid~.custom-control-label::before, .custom-control-input.is-valid~.custom-control-label::before {
        border-color: #44eb5a;
        }
        .was-validated .custom-control-input:valid~.valid-feedback, .was-validated .custom-control-input:valid~.valid-tooltip, .custom-control-input.is-valid~.valid-feedback, .custom-control-input.is-valid~.valid-tooltip {
        display: block;
        }
        .was-validated .custom-control-input:valid:checked~.custom-control-label::before, .custom-control-input.is-valid:checked~.custom-control-label::before {
        border-color: #72f083;
        background-color: #72f083;
        }
        .was-validated .custom-control-input:valid:focus~.custom-control-label::before, .custom-control-input.is-valid:focus~.custom-control-label::before {
        box-shadow: 0 0 0 .2rem rgba(68, 235, 90, .25);
        }
        .was-validated .custom-control-input:valid:focus:not(:checked)~.custom-control-label::before, .custom-control-input.is-valid:focus:not(:checked)~.custom-control-label::before {
        border-color: #44eb5a;
        }
        .was-validated .custom-file-input:valid~.custom-file-label, .custom-file-input.is-valid~.custom-file-label {
        border-color: #44eb5a;
        }
        .was-validated .custom-file-input:valid~.valid-feedback, .was-validated .custom-file-input:valid~.valid-tooltip, .custom-file-input.is-valid~.valid-feedback, .custom-file-input.is-valid~.valid-tooltip {
        display: block;
        }
        .was-validated .custom-file-input:valid:focus~.custom-file-label, .custom-file-input.is-valid:focus~.custom-file-label {
        border-color: #44eb5a;
        box-shadow: 0 0 0 .2rem rgba(68, 235, 90, .25);
        }
        .invalid-feedback {
        display: none;
        width: 100%;
        margin-top: .25rem;
        font-size: 80%;
        color: #e9241d;
        }
        .invalid-tooltip {
        position: absolute;
        top: 100%;
        z-index: 5;
        display: none;
        max-width: 100%;
        padding: .25rem .5rem;
        margin-top: .1rem;
        font-size: .875rem;
        line-height: 1.5;
        color: #fff;
        background-color: rgba(233, 36, 29, .9);
        border-radius: .25rem;
        }
        .was-validated .form-control:invalid, .form-control.is-invalid {
        border-color: #e9241d;
        padding-right: 2.25rem;
        background-repeat: no-repeat;
        background-position: center right calc(2.25rem/4);
        background-size: calc(2.25rem/2) calc(2.25rem/2);
        background-image: url(data:image/svg+xml;
        base64, PHN2ZyB4bWxucz0naHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmcnIGZpbGw9JyNFOTI0MUQnIHZpZXdCb3g9Jy0yIC0yIDcgNyc+PHBhdGggc3Ryb2tlPScjZDk1MzRmJyBkPSdNMCAwbDMgM20wLTNMMCAzJy8+PGNpcmNsZSByPScuNScvPjxjaXJjbGUgY3g9JzMnIHI9Jy41Jy8+PGNpcmNsZSBjeT0nMycgcj0nLjUnLz48Y2lyY2xlIGN4PSczJyBjeT0nMycgcj0nLjUnLz48L3N2Zz4=);
        }
        .was-validated .form-control: invalid:focus, .form-control.is-invalid:focus {
        border-color: #e9241d;
        box-shadow: 0 0 0 .2rem rgba(233, 36, 29, .25);
        }
        .was-validated .form-control:invalid~.invalid-feedback, .was-validated .form-control:invalid~.invalid-tooltip, .form-control.is-invalid~.invalid-feedback, .form-control.is-invalid~.invalid-tooltip {
        display: block;
        }
        .was-validated textarea.form-control:invalid, textarea.form-control.is-invalid {
        padding-right: 2.25rem;
        background-position: top calc(2.25rem/4) right calc(2.25rem/4);
        }
        .was-validated .custom-select:invalid, .custom-select.is-invalid {
        border-color: #e9241d;
        padding-right: 3.4375rem;
        background: url("data:image/svg+xml, %3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 4 5'%3e%3cpath fill='%23343a40' d='M2 0L0 2h4zm0 5L0 3h4z'/%3e%3c/svg%3e") no-repeat right 0.75rem center/8px 10px, url("data:image/svg+xml, %3csvg xmlns='http://www.w3.org/2000/svg' fill='%23E9241D' viewBox='-2 -2 7 7'%3e%3cpath stroke='%23d9534f' d='M0 0l3 3m0-3L0 3'/%3e%3ccircle r='.5'/%3e%3ccircle cx='3' r='.5'/%3e%3ccircle cy='3' r='.5'/%3e%3ccircle cx='3' cy='3' r='.5'/%3e%3c/svg%3E") no-repeat center right 1.75rem/1.125rem 1.125rem;
        }
        .was-validated .custom-select:invalid:focus, .custom-select.is-invalid:focus {
        border-color: #e9241d;
        box-shadow: 0 0 0 .2rem rgba(233, 36, 29, .25);
        }
        .was-validated .custom-select:invalid~.invalid-feedback, .was-validated .custom-select:invalid~.invalid-tooltip, .custom-select.is-invalid~.invalid-feedback, .custom-select.is-invalid~.invalid-tooltip {
        display: block;
        }
        .was-validated .form-control-file:invalid~.invalid-feedback, .was-validated .form-control-file:invalid~.invalid-tooltip, .form-control-file.is-invalid~.invalid-feedback, .form-control-file.is-invalid~.invalid-tooltip {
        display: block;
        }
        .was-validated .form-check-input:invalid~.form-check-label, .form-check-input.is-invalid~.form-check-label {
        color: #e9241d;
        }
        .was-validated .form-check-input:invalid~.invalid-feedback, .was-validated .form-check-input:invalid~.invalid-tooltip, .form-check-input.is-invalid~.invalid-feedback, .form-check-input.is-invalid~.invalid-tooltip {
        display: block;
        }
        .was-validated .custom-control-input:invalid~.custom-control-label, .custom-control-input.is-invalid~.custom-control-label {
        color: #e9241d;
        }
        .was-validated .custom-control-input:invalid~.custom-control-label::before, .custom-control-input.is-invalid~.custom-control-label::before {
        border-color: #e9241d;
        }
        .was-validated .custom-control-input:invalid~.invalid-feedback, .was-validated .custom-control-input:invalid~.invalid-tooltip, .custom-control-input.is-invalid~.invalid-feedback, .custom-control-input.is-invalid~.invalid-tooltip {
        display: block;
        }
        .was-validated .custom-control-input:invalid:checked~.custom-control-label::before, .custom-control-input.is-invalid:checked~.custom-control-label::before {
        border-color: #ee514b;
        background-color: #ee514b;
        }
        .was-validated .custom-control-input:invalid:focus~.custom-control-label::before, .custom-control-input.is-invalid:focus~.custom-control-label::before {
        box-shadow: 0 0 0 .2rem rgba(233, 36, 29, .25);
        }
        .was-validated .custom-control-input:invalid:focus:not(:checked)~.custom-control-label::before, .custom-control-input.is-invalid:focus:not(:checked)~.custom-control-label::before {
        border-color: #e9241d;
        }
        .was-validated .custom-file-input:invalid~.custom-file-label, .custom-file-input.is-invalid~.custom-file-label {
        border-color: #e9241d;
        }
        .was-validated .custom-file-input:invalid~.invalid-feedback, .was-validated .custom-file-input:invalid~.invalid-tooltip, .custom-file-input.is-invalid~.invalid-feedback, .custom-file-input.is-invalid~.invalid-tooltip {
        display: block;
        }
        .was-validated .custom-file-input:invalid:focus~.custom-file-label, .custom-file-input.is-invalid:focus~.custom-file-label {
        border-color: #e9241d;
        box-shadow: 0 0 0 .2rem rgba(233, 36, 29, .25);
        }
        .form-inline {
        display: flex;
        flex-flow: row wrap;
        align-items: center;
        }
        .form-inline .form-check {
        width: 100%}
        @media(min-width:576px) {
        .form-inline label {
        display: flex;
        align-items: center;
        justify-content: center;
        margin-bottom: 0;
        }
        .form-inline .form-group {
        display: flex;
        flex: 0 0 auto;
        flex-flow: row wrap;
        align-items: center;
        margin-bottom: 0;
        }
        .form-inline .form-control {
        display: inline-block;
        width: auto;
        vertical-align: middle;
        }
        .form-inline .form-control-plaintext {
        display: inline-block;
        }
        .form-inline .input-group, .form-inline .custom-select {
        width: auto;
        }
        .form-inline .form-check {
        display: flex;
        align-items: center;
        justify-content: center;
        width: auto;
        padding-left: 0;
        }
        .form-inline .form-check-input {
        position: relative;
        margin-top: 0;
        margin-right: .25rem;
        margin-left: 0;
        }
        .form-inline .custom-control {
        align-items: center;
        justify-content: center;
        }
        .form-inline .custom-control-label {
        margin-bottom: 0;
        }
        }.fade {
        transition: opacity .15s linear;
        }
        @media screen and (prefers-reduced-motion:reduce) {
        .fade {
        transition: none;
        }
        }.fade:not(.show) {
        opacity: 0;
        }
        .collapse:not(.show) {
        display: none;
        }
        .collapsing {
        position: relative;
        height: 0;
        overflow: hidden;
        transition: height .35s ease;
        }
        @media screen and (prefers-reduced-motion:reduce) {
        .collapsing {
        transition: none;
        }
        }.dropup, .dropright, .dropdown, .dropleft {
        position: relative;
        }
        .dropdown-toggle::after {
        display: inline-block;
        margin-left: .255em;
        vertical-align: .255em;
        content: "";
        border-top: .3em solid;
        border-right: .3em solid transparent;
        border-bottom: 0;
        border-left: .3em solid transparent;
        }
        .dropdown-toggle:empty::after {
        margin-left: 0;
        }
        .dropdown-menu {
        position: absolute;
        top: 100%;
        left: 0;
        z-index: 1000;
        display: none;
        float: left;
        min-width: 10rem;
        padding: .5rem 0;
        margin: .125rem 0 0;
        font-size: 1rem;
        color: #212529;
        text-align: left;
        list-style: none;
        background-color: #fff;
        background-clip: padding-box;
        border: 1px solid rgba(0, 0, 0, .15);
        border-radius: .25rem;
        }
        .dropdown-menu-right {
        right: 0;
        left: auto;
        }
        @media(min-width:576px) {
        .dropdown-menu-sm-right {
        right: 0;
        left: auto;
        }
        }@media(min-width:768px) {
        .dropdown-menu-md-right {
        right: 0;
        left: auto;
        }
        }@media(min-width:992px) {
        .dropdown-menu-lg-right {
        right: 0;
        left: auto;
        }
        }@media(min-width:1200px) {
        .dropdown-menu-xl-right {
        right: 0;
        left: auto;
        }
        }.dropdown-menu-left {
        right: auto;
        left: 0;
        }
        @media(min-width:576px) {
        .dropdown-menu-sm-left {
        right: auto;
        left: 0;
        }
        }@media(min-width:768px) {
        .dropdown-menu-md-left {
        right: auto;
        left: 0;
        }
        }@media(min-width:992px) {
        .dropdown-menu-lg-left {
        right: auto;
        left: 0;
        }
        }@media(min-width:1200px) {
        .dropdown-menu-xl-left {
        right: auto;
        left: 0;
        }
        }.dropup .dropdown-menu {
        top: auto;
        bottom: 100%;
        margin-top: 0;
        margin-bottom: .125rem;
        }
        .dropup .dropdown-toggle::after {
        display: inline-block;
        margin-left: .255em;
        vertical-align: .255em;
        content: "";
        border-top: 0;
        border-right: .3em solid transparent;
        border-bottom: .3em solid;
        border-left: .3em solid transparent;
        }
        .dropup .dropdown-toggle:empty::after {
        margin-left: 0;
        }
        .dropright .dropdown-menu {
        top: 0;
        right: auto;
        left: 100%;
        margin-top: 0;
        margin-left: .125rem;
        }
        .dropright .dropdown-toggle::after {
        display: inline-block;
        margin-left: .255em;
        vertical-align: .255em;
        content: "";
        border-top: .3em solid transparent;
        border-right: 0;
        border-bottom: .3em solid transparent;
        border-left: .3em solid;
        }
        .dropright .dropdown-toggle:empty::after {
        margin-left: 0;
        }
        .dropright .dropdown-toggle::after {
        vertical-align: 0;
        }
        .dropleft .dropdown-menu {
        top: 0;
        right: 100%;
        left: auto;
        margin-top: 0;
        margin-right: .125rem;
        }
        .dropleft .dropdown-toggle::after {
        display: inline-block;
        margin-left: .255em;
        vertical-align: .255em;
        content: ""}
        .dropleft .dropdown-toggle::after {
        display: none;
        }
        .dropleft .dropdown-toggle::before {
        display: inline-block;
        margin-right: .255em;
        vertical-align: .255em;
        content: "";
        border-top: .3em solid transparent;
        border-right: .3em solid;
        border-bottom: .3em solid transparent;
        }
        .dropleft .dropdown-toggle:empty::after {
        margin-left: 0;
        }
        .dropleft .dropdown-toggle::before {
        vertical-align: 0;
        }
        .dropdown-menu[x-placement^=top], .dropdown-menu[x-placement^=right], .dropdown-menu[x-placement^=bottom], .dropdown-menu[x-placement^=left] {
        right: auto;
        bottom: auto;
        }
        .dropdown-divider {
        height: 0;
        margin: .5rem 0;
        overflow: hidden;
        border-top: 1px solid #e9ecef;
        }
        .dropdown-item {
        display: block;
        width: 100%;
        padding: .25rem 1.5rem;
        clear: both;
        font-weight: 400;
        color: #212529;
        text-align: inherit;
        white-space: nowrap;
        background-color: transparent;
        border: 0;
        }
        .dropdown-item:first-child {
        border-top-left-radius: calc(0.25rem - 1px);
        border-top-right-radius: calc(0.25rem - 1px);
        }
        .dropdown-item:last-child {
        border-bottom-right-radius: calc(0.25rem - 1px);
        border-bottom-left-radius: calc(0.25rem - 1px);
        }
        .dropdown-item:hover, .dropdown-item:focus {
        color: #16181b;
        text-decoration: none;
        background-color: #f8f9fa;
        }
        .dropdown-item.active, .dropdown-item:active {
        color: #fff;
        text-decoration: none;
        background-color: #1a75e8;
        }
        .dropdown-item.disabled, .dropdown-item:disabled {
        color: #6c757d;
        pointer-events: none;
        background-color: transparent;
        }
        .dropdown-menu.show {
        display: block;
        }
        .dropdown-header {
        display: block;
        padding: .5rem 1.5rem;
        margin-bottom: 0;
        font-size: .875rem;
        color: #6c757d;
        white-space: nowrap;
        }
        .dropdown-item-text {
        display: block;
        padding: .25rem 1.5rem;
        color: #212529;
        }
        .input-group {
        position: relative;
        display: flex;
        flex-wrap: wrap;
        align-items: stretch;
        width: 100%}
        .input-group>.form-control, .input-group>.form-control-plaintext, .input-group>.custom-select, .input-group>.custom-file {
        position: relative;
        flex: 1 1 auto;
        width: 1%;
        margin-bottom: 0;
        }
        .input-group>.form-control+.form-control, .input-group>.form-control+.custom-select, .input-group>.form-control+.custom-file, .input-group>.form-control-plaintext+.form-control, .input-group>.form-control-plaintext+.custom-select, .input-group>.form-control-plaintext+.custom-file, .input-group>.custom-select+.form-control, .input-group>.custom-select+.custom-select, .input-group>.custom-select+.custom-file, .input-group>.custom-file+.form-control, .input-group>.custom-file+.custom-select, .input-group>.custom-file+.custom-file {
        margin-left: -1px;
        }
        .input-group>.form-control:focus, .input-group>.custom-select:focus, .input-group>.custom-file .custom-file-input:focus~.custom-file-label {
        z-index: 3;
        }
        .input-group>.custom-file .custom-file-input:focus {
        z-index: 4;
        }
        .input-group>.form-control:not(:last-child), .input-group>.custom-select:not(:last-child) {
        border-top-right-radius: 0;
        border-bottom-right-radius: 0;
        }
        .input-group>.form-control:not(:first-child), .input-group>.custom-select:not(:first-child) {
        border-top-left-radius: 0;
        border-bottom-left-radius: 0;
        }
        .input-group>.custom-file {
        display: flex;
        align-items: center;
        }
        .input-group>.custom-file:not(:last-child) .custom-file-label, .input-group>.custom-file:not(:last-child) .custom-file-label::after {
        border-top-right-radius: 0;
        border-bottom-right-radius: 0;
        }
        .input-group>.custom-file:not(:first-child) .custom-file-label {
        border-top-left-radius: 0;
        border-bottom-left-radius: 0;
        }
        .input-group-prepend, .input-group-append {
        display: flex;
        }
        .input-group-prepend .btn, .input-group-append .btn {
        position: relative;
        z-index: 2;
        }
        .input-group-prepend .btn:focus, .input-group-append .btn:focus {
        z-index: 3;
        }
        .input-group-prepend .btn+.btn, .input-group-prepend .btn+.input-group-text, .input-group-prepend .input-group-text+.input-group-text, .input-group-prepend .input-group-text+.btn, .input-group-append .btn+.btn, .input-group-append .btn+.input-group-text, .input-group-append .input-group-text+.input-group-text, .input-group-append .input-group-text+.btn {
        margin-left: -1px;
        }
        .input-group-prepend {
        margin-right: -1px;
        }
        .input-group-append {
        margin-left: -1px;
        }
        .input-group-text {
        display: flex;
        align-items: center;
        padding: .375rem .75rem;
        margin-bottom: 0;
        font-size: 1rem;
        font-weight: 400;
        line-height: 1.5;
        color: #495057;
        text-align: center;
        white-space: nowrap;
        background-color: #e9ecef;
        border: 1px solid #ced4da;
        border-radius: .25rem;
        }
        .input-group-text input[type=radio], .input-group-text input[type=checkbox] {
        margin-top: 0;
        }
        .input-group-lg>.form-control:not(textarea), .input-group-lg>.custom-select {
        height: calc(2.875rem + 2px);
        }
        .input-group-lg>.form-control, .input-group-lg>.custom-select, .input-group-lg>.input-group-prepend>.input-group-text, .input-group-lg>.input-group-append>.input-group-text, .input-group-lg>.input-group-prepend>.btn, .input-group-lg>.input-group-append>.btn {
        padding: .5rem 1rem;
        font-size: 1.25rem;
        line-height: 1.5;
        border-radius: .3rem;
        }
        .input-group-sm>.form-control:not(textarea), .input-group-sm>.custom-select {
        height: calc(1.8125rem + 2px);
        }
        .input-group-sm>.form-control, .input-group-sm>.custom-select, .input-group-sm>.input-group-prepend>.input-group-text, .input-group-sm>.input-group-append>.input-group-text, .input-group-sm>.input-group-prepend>.btn, .input-group-sm>.input-group-append>.btn {
        padding: .25rem .5rem;
        font-size: .875rem;
        line-height: 1.5;
        border-radius: .2rem;
        }
        .input-group-lg>.custom-select, .input-group-sm>.custom-select {
        padding-right: 1.75rem;
        }
        .input-group>.input-group-prepend>.btn, .input-group>.input-group-prepend>.input-group-text, .input-group>.input-group-append:not(:last-child)>.btn, .input-group>.input-group-append:not(:last-child)>.input-group-text, .input-group>.input-group-append:last-child>.btn:not(:last-child):not(.dropdown-toggle), .input-group>.input-group-append:last-child>.input-group-text:not(:last-child) {
        border-top-right-radius: 0;
        border-bottom-right-radius: 0;
        }
        .input-group>.input-group-append>.btn, .input-group>.input-group-append>.input-group-text, .input-group>.input-group-prepend:not(:first-child)>.btn, .input-group>.input-group-prepend:not(:first-child)>.input-group-text, .input-group>.input-group-prepend:first-child>.btn:not(:first-child), .input-group>.input-group-prepend:first-child>.input-group-text:not(:first-child) {
        border-top-left-radius: 0;
        border-bottom-left-radius: 0;
        }
        .custom-control {
        position: relative;
        display: block;
        min-height: 1.5rem;
        padding-left: 1.5rem;
        }
        .custom-control-inline {
        display: inline-flex;
        margin-right: 1rem;
        }
        .custom-control-input {
        position: absolute;
        z-index: -1;
        opacity: 0;
        }
        .custom-control-input:checked~.custom-control-label::before {
        color: #fff;
        border-color: #1a75e8;
        background-color: #1a75e8;
        }
        .custom-control-input:focus~.custom-control-label::before {
        box-shadow: 0 0 0 .2rem rgba(26, 117, 232, .25);
        }
        .custom-control-input:focus:not(:checked)~.custom-control-label::before {
        border-color: #8ebbf4;
        }
        .custom-control-input:not(:disabled):active~.custom-control-label::before {
        color: #fff;
        background-color: #bcd7f8;
        border-color: #bcd7f8;
        }
        .custom-control-input:disabled~.custom-control-label {
        color: #6c757d;
        }
        .custom-control-input:disabled~.custom-control-label::before {
        background-color: #e9ecef;
        }
        .custom-control-label {
        position: relative;
        margin-bottom: 0;
        vertical-align: top;
        }
        .custom-control-label::before {
        position: absolute;
        top: .25rem;
        left: -1.5rem;
        display: block;
        width: 1rem;
        height: 1rem;
        pointer-events: none;
        content: "";
        background-color: #fff;
        border: #adb5bd solid 1px;
        }
        .custom-control-label::after {
        position: absolute;
        top: .25rem;
        left: -1.5rem;
        display: block;
        width: 1rem;
        height: 1rem;
        content: "";
        background-repeat: no-repeat;
        background-position: center center;
        background-size: 50% 50%}
        .custom-checkbox .custom-control-label::before {
        border-radius: .25rem;
        }
        .custom-checkbox .custom-control-input:checked~.custom-control-label::after {
        background-image: url(data:image/svg+xml;
        base64, PHN2ZyB4bWxucz0naHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmcnIHZpZXdCb3g9JzAgMCA4IDgnPjxwYXRoIGZpbGw9JyNmZmYnIGQ9J002LjU2NC43NWwtMy41OSAzLjYxMi0xLjUzOC0xLjU1TDAgNC4yNiAyLjk3NCA3LjI1IDggMi4xOTN6Jy8+PC9zdmc+);
        }
        .custom-checkbox .custom-control-input: indeterminate~.custom-control-label::before {
        border-color: #1a75e8;
        background-color: #1a75e8;
        }
        .custom-checkbox .custom-control-input:indeterminate~.custom-control-label::after {
        background-image: url(data:image/svg+xml;
        base64, PHN2ZyB4bWxucz0naHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmcnIHZpZXdCb3g9JzAgMCA0IDQnPjxwYXRoIHN0cm9rZT0nI2ZmZicgZD0nTTAgMmg0Jy8+PC9zdmc+);
        }
        .custom-checkbox .custom-control-input: disabled:checked~.custom-control-label::before {
        background-color: rgba(26, 117, 232, .5);
        }
        .custom-checkbox .custom-control-input:disabled:indeterminate~.custom-control-label::before {
        background-color: rgba(26, 117, 232, .5);
        }
        .custom-radio .custom-control-label::before {
        border-radius: 50%}
        .custom-radio .custom-control-input:checked~.custom-control-label::after {
        background-image: url(data:image/svg+xml;
        base64, PHN2ZyB4bWxucz0naHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmcnIHZpZXdCb3g9Jy00IC00IDggOCc+PGNpcmNsZSByPSczJyBmaWxsPScjZmZmJy8+PC9zdmc+);
        }
        .custom-radio .custom-control-input: disabled:checked~.custom-control-label::before {
        background-color: rgba(26, 117, 232, .5);
        }
        .custom-switch {
        padding-left: 2.25rem;
        }
        .custom-switch .custom-control-label::before {
        left: -2.25rem;
        width: 1.75rem;
        pointer-events: all;
        border-radius: .5rem;
        }
        .custom-switch .custom-control-label::after {
        top: calc(0.25rem + 2px);
        left: calc(-2.25rem + 2px);
        width: calc(1rem - 4px);
        height: calc(1rem - 4px);
        background-color: #adb5bd;
        border-radius: .5rem;
        transition: transform .15s ease-in-out, background-color .15s ease-in-out, border-color .15s ease-in-out, box-shadow .15s ease-in-out;
        }
        @media screen and (prefers-reduced-motion:reduce) {
        .custom-switch .custom-control-label: :after {
        transition: none;
        }
        }.custom-switch .custom-control-input:checked~.custom-control-label::after {
        background-color: #fff;
        transform: translateX(0.75rem);
        }
        .custom-switch .custom-control-input:disabled:checked~.custom-control-label::before {
        background-color: rgba(26, 117, 232, .5);
        }
        .custom-select {
        display: inline-block;
        width: 100%;
        height: calc(2.25rem + 2px);
        padding: .375rem 1.75rem .375rem .75rem;
        font-weight: 400;
        line-height: 1.5;
        color: #495057;
        vertical-align: middle;
        background: url("data:image/svg+xml, %3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 4 5'%3e%3cpath fill='%23343a40' d='M2 0L0 2h4zm0 5L0 3h4z'/%3e%3c/svg%3e") no-repeat right 0.75rem center/8px 10px;
        background-color: #fff;
        border: 1px solid #ced4da;
        border-radius: .25rem;
        appearance: none;
        }
        .custom-select:focus {
        border-color: #8ebbf4;
        outline: 0;
        box-shadow: 0 0 0 .2rem rgba(142, 187, 244, .5);
        }
        .custom-select:focus::-ms-value {
        color: #495057;
        background-color: #fff;
        }
        .custom-select[multiple], .custom-select[size]:not([size="1"]) {
        height: auto;
        padding-right: .75rem;
        background-image: none;
        }
        .custom-select:disabled {
        color: #6c757d;
        background-color: #e9ecef;
        }
        .custom-select::-ms-expand {
        opacity: 0;
        }
        .custom-select-sm {
        height: calc(1.8125rem + 2px);
        padding-top: .25rem;
        padding-bottom: .25rem;
        padding-left: .5rem;
        font-size: .875rem;
        }
        .custom-select-lg {
        height: calc(2.875rem + 2px);
        padding-top: .5rem;
        padding-bottom: .5rem;
        padding-left: 1rem;
        font-size: 1.25rem;
        }
        .custom-file {
        position: relative;
        display: inline-block;
        width: 100%;
        height: calc(2.25rem + 2px);
        margin-bottom: 0;
        }
        .custom-file-input {
        position: relative;
        z-index: 2;
        width: 100%;
        height: calc(2.25rem + 2px);
        margin: 0;
        opacity: 0;
        }
        .custom-file-input:focus~.custom-file-label {
        border-color: #8ebbf4;
        box-shadow: 0 0 0 .2rem rgba(26, 117, 232, .25);
        }
        .custom-file-input:disabled~.custom-file-label {
        background-color: #e9ecef;
        }
        .custom-file-input:lang(en)~.custom-file-label::after {
        content: "Browse"}
        .custom-file-input~.custom-file-label[data-browse]::after {
        content: attr(data-browse);
        }
        .custom-file-label {
        position: absolute;
        top: 0;
        right: 0;
        left: 0;
        z-index: 1;
        height: calc(2.25rem + 2px);
        padding: .375rem .75rem;
        font-weight: 400;
        line-height: 1.5;
        color: #495057;
        background-color: #fff;
        border: 1px solid #ced4da;
        border-radius: .25rem;
        }
        .custom-file-label::after {
        position: absolute;
        top: 0;
        right: 0;
        bottom: 0;
        z-index: 3;
        display: block;
        height: 2.25rem;
        padding: .375rem .75rem;
        line-height: 1.5;
        color: #495057;
        content: "Browse";
        background-color: #e9ecef;
        border-left: inherit;
        border-radius: 0 .25rem .25rem 0;
        }
        .custom-range {
        width: 100%;
        height: calc(1rem + 0.4rem);
        padding: 0;
        background-color: transparent;
        appearance: none;
        }
        .custom-range:focus {
        outline: none;
        }
        .custom-range:focus::-webkit-slider-thumb {
        box-shadow: 0 0 0 1px #fff, 0 0 0 .2rem rgba(26, 117, 232, .25);
        }
        .custom-range:focus::-moz-range-thumb {
        box-shadow: 0 0 0 1px #fff, 0 0 0 .2rem rgba(26, 117, 232, .25);
        }
        .custom-range:focus::-ms-thumb {
        box-shadow: 0 0 0 1px #fff, 0 0 0 .2rem rgba(26, 117, 232, .25);
        }
        .custom-range::-moz-focus-outer {
        border: 0;
        }
        .custom-range::-webkit-slider-thumb {
        width: 1rem;
        height: 1rem;
        margin-top: -.25rem;
        background-color: #1a75e8;
        border: 0;
        border-radius: 1rem;
        transition: background-color .15s ease-in-out, border-color .15s ease-in-out, box-shadow .15s ease-in-out;
        appearance: none;
        }
        @media screen and (prefers-reduced-motion:reduce) {
        .custom-range: :-webkit-slider-thumb {
        transition: none;
        }
        }.custom-range::-webkit-slider-thumb:active {
        background-color: #bcd7f8;
        }
        .custom-range::-webkit-slider-runnable-track {
        width: 100%;
        height: .5rem;
        color: transparent;
        cursor: pointer;
        background-color: #dee2e6;
        border-color: transparent;
        border-radius: 1rem;
        }
        .custom-range::-moz-range-thumb {
        width: 1rem;
        height: 1rem;
        background-color: #1a75e8;
        border: 0;
        border-radius: 1rem;
        transition: background-color .15s ease-in-out, border-color .15s ease-in-out, box-shadow .15s ease-in-out;
        appearance: none;
        }
        @media screen and (prefers-reduced-motion:reduce) {
        .custom-range: :-moz-range-thumb {
        transition: none;
        }
        }.custom-range::-moz-range-thumb:active {
        background-color: #bcd7f8;
        }
        .custom-range::-moz-range-track {
        width: 100%;
        height: .5rem;
        color: transparent;
        cursor: pointer;
        background-color: #dee2e6;
        border-color: transparent;
        border-radius: 1rem;
        }
        .custom-range::-ms-thumb {
        width: 1rem;
        height: 1rem;
        margin-top: 0;
        margin-right: .2rem;
        margin-left: .2rem;
        background-color: #1a75e8;
        border: 0;
        border-radius: 1rem;
        transition: background-color .15s ease-in-out, border-color .15s ease-in-out, box-shadow .15s ease-in-out;
        appearance: none;
        }
        @media screen and (prefers-reduced-motion:reduce) {
        .custom-range: :-ms-thumb {
        transition: none;
        }
        }.custom-range::-ms-thumb:active {
        background-color: #bcd7f8;
        }
        .custom-range::-ms-track {
        width: 100%;
        height: .5rem;
        color: transparent;
        cursor: pointer;
        background-color: transparent;
        border-color: transparent;
        border-width: .5rem;
        }
        .custom-range::-ms-fill-lower {
        background-color: #dee2e6;
        border-radius: 1rem;
        }
        .custom-range::-ms-fill-upper {
        margin-right: 15px;
        background-color: #dee2e6;
        border-radius: 1rem;
        }
        .custom-range:disabled::-webkit-slider-thumb {
        background-color: #adb5bd;
        }
        .custom-range:disabled::-webkit-slider-runnable-track {
        cursor: default;
        }
        .custom-range:disabled::-moz-range-thumb {
        background-color: #adb5bd;
        }
        .custom-range:disabled::-moz-range-track {
        cursor: default;
        }
        .custom-range:disabled::-ms-thumb {
        background-color: #adb5bd;
        }
        .custom-control-label::before, .custom-file-label, .custom-select {
        transition: background-color .15s ease-in-out, border-color .15s ease-in-out, box-shadow .15s ease-in-out;
        }
        @media screen and (prefers-reduced-motion:reduce) {
        .custom-control-label: :before, .custom-file-label, .custom-select {
        transition: none;
        }
        }.nav {
        display: flex;
        flex-wrap: wrap;
        padding-left: 0;
        margin-bottom: 0;
        list-style: none;
        }
        .nav-link {
        display: block;
        padding: .5rem 1rem;
        }
        .nav-link:hover, .nav-link:focus {
        text-decoration: none;
        }
        .nav-link.disabled {
        color: #6c757d;
        pointer-events: none;
        cursor: default;
        }
        .nav-tabs {
        border-bottom: 1px solid #dee2e6;
        }
        .nav-tabs .nav-item {
        margin-bottom: -1px;
        }
        .nav-tabs .nav-link {
        border: 1px solid transparent;
        border-top-left-radius: .25rem;
        border-top-right-radius: .25rem;
        }
        .nav-tabs .nav-link:hover, .nav-tabs .nav-link:focus {
        border-color: #e9ecef #e9ecef #dee2e6;
        }
        .nav-tabs .nav-link.disabled {
        color: #6c757d;
        background-color: transparent;
        border-color: transparent;
        }
        .nav-tabs .nav-link.active, .nav-tabs .nav-item.show .nav-link {
        color: #495057;
        background-color: #fff;
        border-color: #dee2e6 #dee2e6 #fff;
        }
        .nav-tabs .dropdown-menu {
        margin-top: -1px;
        border-top-left-radius: 0;
        border-top-right-radius: 0;
        }
        .nav-pills .nav-link {
        border-radius: .25rem;
        }
        .nav-pills .nav-link.active, .nav-pills .show>.nav-link {
        color: #fff;
        background-color: #1a75e8;
        }
        .nav-fill .nav-item {
        flex: 1 1 auto;
        text-align: center;
        }
        .nav-justified .nav-item {
        flex-basis: 0;
        flex-grow: 1;
        text-align: center;
        }
        .tab-content>.tab-pane {
        display: none;
        }
        .tab-content>.active {
        display: block;
        }
        .alert {
        position: relative;
        padding: .75rem 1.25rem;
        margin-bottom: 1rem;
        border: 1px solid transparent;
        border-radius: .25rem;
        }
        .alert-heading {
        color: inherit;
        }
        .alert-link {
        font-weight: 700;
        }
        .alert-dismissible {
        padding-right: 4rem;
        }
        .alert-dismissible .close {
        position: absolute;
        top: 0;
        right: 0;
        padding: .75rem 1.25rem;
        color: inherit;
        }
        .alert-primary {
        color: #0e3d79;
        background-color: #d1e3fa;
        border-color: #bfd8f9;
        }
        .alert-primary hr {
        border-top-color: #a8caf7;
        }
        .alert-primary .alert-link {
        color: #09264b;
        }
        .alert-secondary {
        color: #383d41;
        background-color: #e2e3e5;
        border-color: #d6d8db;
        }
        .alert-secondary hr {
        border-top-color: #c8cbcf;
        }
        .alert-secondary .alert-link {
        color: #202326;
        }
        .alert-success {
        color: #237a2f;
        background-color: #dafbde;
        border-color: #cbf9d1;
        }
        .alert-success hr {
        border-top-color: #b4f6bd;
        }
        .alert-success .alert-link {
        color: #185220;
        }
        .alert-info {
        color: #0c5460;
        background-color: #d1ecf1;
        border-color: #bee5eb;
        }
        .alert-info hr {
        border-top-color: #abdde5;
        }
        .alert-info .alert-link {
        color: #062c33;
        }
        .alert-warning {
        color: #856404;
        background-color: #fff3cd;
        border-color: #ffeeba;
        }
        .alert-warning hr {
        border-top-color: #ffe8a1;
        }
        .alert-warning .alert-link {
        color: #533f03;
        }
        .alert-danger {
        color: #79130f;
        background-color: #fbd3d2;
        border-color: #f9c2c0;
        }
        .alert-danger hr {
        border-top-color: #f7aba9;
        }
        .alert-danger .alert-link {
        color: #4c0c09;
        }
        .alert-light {
        color: #818182;
        background-color: #fefefe;
        border-color: #fdfdfe;
        }
        .alert-light hr {
        border-top-color: #ececf6;
        }
        .alert-light .alert-link {
        color: #686868;
        }
        .alert-dark {
        color: #1b1e21;
        background-color: #d6d8d9;
        border-color: #c6c8ca;
        }
        .alert-dark hr {
        border-top-color: #b9bbbe;
        }
        .alert-dark .alert-link {
        color: #040505;
        }
        .close {
        float: right;
        font-size: 1.5rem;
        font-weight: 700;
        line-height: 1;
        color: #000;
        text-shadow: 0 1px 0 #fff;
        opacity: .5;
        }
        .close:hover {
        color: #000;
        text-decoration: none;
        }
        .close:not(:disabled):not(.disabled) {
        cursor: pointer;
        }
        .close:not(:disabled):not(.disabled):hover, .close:not(:disabled):not(.disabled):focus {
        opacity: .75;
        }
        button.close {
        padding: 0;
        background-color: transparent;
        border: 0;
        appearance: none;
        }
        a.close.disabled {
        pointer-events: none;
        }
        
        
        @keyframes spinner-border {
        to {
        transform: rotate(360deg);
        }
        }.spinner-border {
        display: inline-block;
        width: 2rem;
        height: 2rem;
        vertical-align: text-bottom;
        border: .25em solid currentColor;
        border-right-color: transparent;
        border-radius: 50%;
        animation: spinner-border .75s linear infinite;
        }
        .spinner-border-sm {
        width: 1rem;
        height: 1rem;
        border-width: .2em;
        }
        @keyframes spinner-grow {
        0% {
        transform: scale(0);
        }
        50% {
        opacity: 1;
        }
        }.spinner-grow {
        display: inline-block;
        width: 2rem;
        height: 2rem;
        vertical-align: text-bottom;
        background-color: currentColor;
        border-radius: 50%;
        opacity: 0;
        animation: spinner-grow .75s linear infinite;
        }
        .spinner-grow-sm {
        width: 1rem;
        height: 1rem;
        }
        .align-baseline {
        vertical-align: baseline!important;
        }
        .align-top {
        vertical-align: top!important;
        }
        .align-middle {
        vertical-align: middle!important;
        }
        .align-bottom {
        vertical-align: bottom!important;
        }
        .align-text-bottom {
        vertical-align: text-bottom!important;
        }
        .align-text-top {
        vertical-align: text-top!important;
        }
        .bg-primary {
        background-color: #1a75e8!important;
        }
        a.bg-primary:hover, a.bg-primary:focus, button.bg-primary:hover, button.bg-primary:focus {
        background-color: #135ebc!important;
        }
        .bg-secondary {
        background-color: #6c757d!important;
        }
        a.bg-secondary:hover, a.bg-secondary:focus, button.bg-secondary:hover, button.bg-secondary:focus {
        background-color: #545b62!important;
        }
        .bg-success {
        background-color: #44eb5a!important;
        }
        a.bg-success:hover, a.bg-success:focus, button.bg-success:hover, button.bg-success:focus {
        background-color: #18e433!important;
        }
        .bg-info {
        background-color: #17a2b8!important;
        }
        a.bg-info:hover, a.bg-info:focus, button.bg-info:hover, button.bg-info:focus {
        background-color: #117a8b!important;
        }
        .bg-warning {
        background-color: #ffc107!important;
        }
        a.bg-warning:hover, a.bg-warning:focus, button.bg-warning:hover, button.bg-warning:focus {
        background-color: #d39e00!important;
        }
        .bg-danger {
        background-color: #e9241d!important;
        }
        a.bg-danger:hover, a.bg-danger:focus, button.bg-danger:hover, button.bg-danger:focus {
        background-color: #c01913!important;
        }
        .bg-light {
        background-color: #f8f9fa!important;
        }
        a.bg-light:hover, a.bg-light:focus, button.bg-light:hover, button.bg-light:focus {
        background-color: #dae0e5!important;
        }
        .bg-dark {
        background-color: #343a40!important;
        }
        a.bg-dark:hover, a.bg-dark:focus, button.bg-dark:hover, button.bg-dark:focus {
        background-color: #1d2124!important;
        }
        .bg-white {
        background-color: #fff!important;
        }
        .bg-transparent {
        background-color: transparent!important;
        }
        .border {
        border: 1px solid #dee2e6!important;
        }
        .border-top {
        border-top: 1px solid #dee2e6!important;
        }
        .border-right {
        border-right: 1px solid #dee2e6!important;
        }
        .border-bottom {
        border-bottom: 1px solid #dee2e6!important;
        }
        .border-left {
        border-left: 1px solid #dee2e6!important;
        }
        .border-0 {
        border: 0!important;
        }
        .border-top-0 {
        border-top: 0!important;
        }
        .border-right-0 {
        border-right: 0!important;
        }
        .border-bottom-0 {
        border-bottom: 0!important;
        }
        .border-left-0 {
        border-left: 0!important;
        }
        .border-primary {
        border-color: #1a75e8!important;
        }
        .border-secondary {
        border-color: #6c757d!important;
        }
        .border-success {
        border-color: #44eb5a!important;
        }
        .border-info {
        border-color: #17a2b8!important;
        }
        .border-warning {
        border-color: #ffc107!important;
        }
        .border-danger {
        border-color: #e9241d!important;
        }
        .border-light {
        border-color: #f8f9fa!important;
        }
        .border-dark {
        border-color: #343a40!important;
        }
        .border-white {
        border-color: #fff!important;
        }
        .rounded {
        border-radius: .25rem!important;
        }
        .rounded-top {
        border-top-left-radius: .25rem!important;
        border-top-right-radius: .25rem!important;
        }
        .rounded-right {
        border-top-right-radius: .25rem!important;
        border-bottom-right-radius: .25rem!important;
        }
        .rounded-bottom {
        border-bottom-right-radius: .25rem!important;
        border-bottom-left-radius: .25rem!important;
        }
        .rounded-left {
        border-top-left-radius: .25rem!important;
        border-bottom-left-radius: .25rem!important;
        }
        .rounded-circle {
        border-radius: 50%!important;
        }
        .rounded-pill {
        border-radius: 50rem!important;
        }
        .rounded-0 {
        border-radius: 0!important;
        }
        .clearfix::after {
        display: block;
        clear: both;
        content: ""}
        .d-none {
        display: none!important;
        }
        .d-inline {
        display: inline!important;
        }
        .d-inline-block {
        display: inline-block!important;
        }
        .d-block {
        display: block!important;
        }
        .d-table {
        display: table!important;
        }
        .d-table-row {
        display: table-row!important;
        }
        .d-table-cell {
        display: table-cell!important;
        }
        .d-flex {
        display: flex!important;
        }
        .d-inline-flex {
        display: inline-flex!important;
        }
        @media(min-width:576px) {
        .d-sm-none {
        display: none!important;
        }
        .d-sm-inline {
        display: inline!important;
        }
        .d-sm-inline-block {
        display: inline-block!important;
        }
        .d-sm-block {
        display: block!important;
        }
        .d-sm-table {
        display: table!important;
        }
        .d-sm-table-row {
        display: table-row!important;
        }
        .d-sm-table-cell {
        display: table-cell!important;
        }
        .d-sm-flex {
        display: flex!important;
        }
        .d-sm-inline-flex {
        display: inline-flex!important;
        }
        }@media(min-width:768px) {
        .d-md-none {
        display: none!important;
        }
        .d-md-inline {
        display: inline!important;
        }
        .d-md-inline-block {
        display: inline-block!important;
        }
        .d-md-block {
        display: block!important;
        }
        .d-md-table {
        display: table!important;
        }
        .d-md-table-row {
        display: table-row!important;
        }
        .d-md-table-cell {
        display: table-cell!important;
        }
        .d-md-flex {
        display: flex!important;
        }
        .d-md-inline-flex {
        display: inline-flex!important;
        }
        }@media(min-width:992px) {
        .d-lg-none {
        display: none!important;
        }
        .d-lg-inline {
        display: inline!important;
        }
        .d-lg-inline-block {
        display: inline-block!important;
        }
        .d-lg-block {
        display: block!important;
        }
        .d-lg-table {
        display: table!important;
        }
        .d-lg-table-row {
        display: table-row!important;
        }
        .d-lg-table-cell {
        display: table-cell!important;
        }
        .d-lg-flex {
        display: flex!important;
        }
        .d-lg-inline-flex {
        display: inline-flex!important;
        }
        }@media(min-width:1200px) {
        .d-xl-none {
        display: none!important;
        }
        .d-xl-inline {
        display: inline!important;
        }
        .d-xl-inline-block {
        display: inline-block!important;
        }
        .d-xl-block {
        display: block!important;
        }
        .d-xl-table {
        display: table!important;
        }
        .d-xl-table-row {
        display: table-row!important;
        }
        .d-xl-table-cell {
        display: table-cell!important;
        }
        .d-xl-flex {
        display: flex!important;
        }
        .d-xl-inline-flex {
        display: inline-flex!important;
        }
        }@media print {
        .d-print-none {
        display: none!important;
        }
        .d-print-inline {
        display: inline!important;
        }
        .d-print-inline-block {
        display: inline-block!important;
        }
        .d-print-block {
        display: block!important;
        }
        .d-print-table {
        display: table!important;
        }
        .d-print-table-row {
        display: table-row!important;
        }
        .d-print-table-cell {
        display: table-cell!important;
        }
        .d-print-flex {
        display: flex!important;
        }
        .d-print-inline-flex {
        display: inline-flex!important;
        }
        }.embed-responsive {
        position: relative;
        display: block;
        width: 100%;
        padding: 0;
        overflow: hidden;
        }
        .embed-responsive::before {
        display: block;
        content: ""}
        .embed-responsive .embed-responsive-item, .embed-responsive iframe, .embed-responsive embed, .embed-responsive object, .embed-responsive video {
        position: absolute;
        top: 0;
        bottom: 0;
        left: 0;
        width: 100%;
        height: 100%;
        border: 0;
        }
        .embed-responsive-21by9::before {
        padding-top: 42.85714%}
        .embed-responsive-16by9::before {
        padding-top: 56.25%}
        .embed-responsive-3by4::before {
        padding-top: 133.33333%}
        .embed-responsive-1by1::before {
        padding-top: 100%}
        .flex-row {
        flex-direction: row!important;
        }
        .flex-column {
        flex-direction: column!important;
        }
        .flex-row-reverse {
        flex-direction: row-reverse!important;
        }
        .flex-column-reverse {
        flex-direction: column-reverse!important;
        }
        .flex-wrap {
        flex-wrap: wrap!important;
        }
        .flex-nowrap {
        flex-wrap: nowrap!important;
        }
        .flex-wrap-reverse {
        flex-wrap: wrap-reverse!important;
        }
        .flex-fill {
        flex: 1 1 auto!important;
        }
        .flex-grow-0 {
        flex-grow: 0!important;
        }
        .flex-grow-1 {
        flex-grow: 1!important;
        }
        .flex-shrink-0 {
        flex-shrink: 0!important;
        }
        .flex-shrink-1 {
        flex-shrink: 1!important;
        }
        .justify-content-start {
        justify-content: flex-start!important;
        }
        .justify-content-end {
        justify-content: flex-end!important;
        }
        .justify-content-center {
        justify-content: center!important;
        }
        .justify-content-between {
        justify-content: space-between!important;
        }
        .justify-content-around {
        justify-content: space-around!important;
        }
        .align-items-start {
        align-items: flex-start!important;
        }
        .align-items-end {
        align-items: flex-end!important;
        }
        .align-items-center {
        align-items: center!important;
        }
        .align-items-baseline {
        align-items: baseline!important;
        }
        .align-items-stretch {
        align-items: stretch!important;
        }
        .align-content-start {
        align-content: flex-start!important;
        }
        .align-content-end {
        align-content: flex-end!important;
        }
        .align-content-center {
        align-content: center!important;
        }
        .align-content-between {
        align-content: space-between!important;
        }
        .align-content-around {
        align-content: space-around!important;
        }
        .align-content-stretch {
        align-content: stretch!important;
        }
        .align-self-auto {
        align-self: auto!important;
        }
        .align-self-start {
        align-self: flex-start!important;
        }
        .align-self-end {
        align-self: flex-end!important;
        }
        .align-self-center {
        align-self: center!important;
        }
        .align-self-baseline {
        align-self: baseline!important;
        }
        .align-self-stretch {
        align-self: stretch!important;
        }
        @media(min-width:576px) {
        .flex-sm-row {
        flex-direction: row!important;
        }
        .flex-sm-column {
        flex-direction: column!important;
        }
        .flex-sm-row-reverse {
        flex-direction: row-reverse!important;
        }
        .flex-sm-column-reverse {
        flex-direction: column-reverse!important;
        }
        .flex-sm-wrap {
        flex-wrap: wrap!important;
        }
        .flex-sm-nowrap {
        flex-wrap: nowrap!important;
        }
        .flex-sm-wrap-reverse {
        flex-wrap: wrap-reverse!important;
        }
        .flex-sm-fill {
        flex: 1 1 auto!important;
        }
        .flex-sm-grow-0 {
        flex-grow: 0!important;
        }
        .flex-sm-grow-1 {
        flex-grow: 1!important;
        }
        .flex-sm-shrink-0 {
        flex-shrink: 0!important;
        }
        .flex-sm-shrink-1 {
        flex-shrink: 1!important;
        }
        .justify-content-sm-start {
        justify-content: flex-start!important;
        }
        .justify-content-sm-end {
        justify-content: flex-end!important;
        }
        .justify-content-sm-center {
        justify-content: center!important;
        }
        .justify-content-sm-between {
        justify-content: space-between!important;
        }
        .justify-content-sm-around {
        justify-content: space-around!important;
        }
        .align-items-sm-start {
        align-items: flex-start!important;
        }
        .align-items-sm-end {
        align-items: flex-end!important;
        }
        .align-items-sm-center {
        align-items: center!important;
        }
        .align-items-sm-baseline {
        align-items: baseline!important;
        }
        .align-items-sm-stretch {
        align-items: stretch!important;
        }
        .align-content-sm-start {
        align-content: flex-start!important;
        }
        .align-content-sm-end {
        align-content: flex-end!important;
        }
        .align-content-sm-center {
        align-content: center!important;
        }
        .align-content-sm-between {
        align-content: space-between!important;
        }
        .align-content-sm-around {
        align-content: space-around!important;
        }
        .align-content-sm-stretch {
        align-content: stretch!important;
        }
        .align-self-sm-auto {
        align-self: auto!important;
        }
        .align-self-sm-start {
        align-self: flex-start!important;
        }
        .align-self-sm-end {
        align-self: flex-end!important;
        }
        .align-self-sm-center {
        align-self: center!important;
        }
        .align-self-sm-baseline {
        align-self: baseline!important;
        }
        .align-self-sm-stretch {
        align-self: stretch!important;
        }
        }@media(min-width:768px) {
        .flex-md-row {
        flex-direction: row!important;
        }
        .flex-md-column {
        flex-direction: column!important;
        }
        .flex-md-row-reverse {
        flex-direction: row-reverse!important;
        }
        .flex-md-column-reverse {
        flex-direction: column-reverse!important;
        }
        .flex-md-wrap {
        flex-wrap: wrap!important;
        }
        .flex-md-nowrap {
        flex-wrap: nowrap!important;
        }
        .flex-md-wrap-reverse {
        flex-wrap: wrap-reverse!important;
        }
        .flex-md-fill {
        flex: 1 1 auto!important;
        }
        .flex-md-grow-0 {
        flex-grow: 0!important;
        }
        .flex-md-grow-1 {
        flex-grow: 1!important;
        }
        .flex-md-shrink-0 {
        flex-shrink: 0!important;
        }
        .flex-md-shrink-1 {
        flex-shrink: 1!important;
        }
        .justify-content-md-start {
        justify-content: flex-start!important;
        }
        .justify-content-md-end {
        justify-content: flex-end!important;
        }
        .justify-content-md-center {
        justify-content: center!important;
        }
        .justify-content-md-between {
        justify-content: space-between!important;
        }
        .justify-content-md-around {
        justify-content: space-around!important;
        }
        .align-items-md-start {
        align-items: flex-start!important;
        }
        .align-items-md-end {
        align-items: flex-end!important;
        }
        .align-items-md-center {
        align-items: center!important;
        }
        .align-items-md-baseline {
        align-items: baseline!important;
        }
        .align-items-md-stretch {
        align-items: stretch!important;
        }
        .align-content-md-start {
        align-content: flex-start!important;
        }
        .align-content-md-end {
        align-content: flex-end!important;
        }
        .align-content-md-center {
        align-content: center!important;
        }
        .align-content-md-between {
        align-content: space-between!important;
        }
        .align-content-md-around {
        align-content: space-around!important;
        }
        .align-content-md-stretch {
        align-content: stretch!important;
        }
        .align-self-md-auto {
        align-self: auto!important;
        }
        .align-self-md-start {
        align-self: flex-start!important;
        }
        .align-self-md-end {
        align-self: flex-end!important;
        }
        .align-self-md-center {
        align-self: center!important;
        }
        .align-self-md-baseline {
        align-self: baseline!important;
        }
        .align-self-md-stretch {
        align-self: stretch!important;
        }
        }@media(min-width:992px) {
        .flex-lg-row {
        flex-direction: row!important;
        }
        .flex-lg-column {
        flex-direction: column!important;
        }
        .flex-lg-row-reverse {
        flex-direction: row-reverse!important;
        }
        .flex-lg-column-reverse {
        flex-direction: column-reverse!important;
        }
        .flex-lg-wrap {
        flex-wrap: wrap!important;
        }
        .flex-lg-nowrap {
        flex-wrap: nowrap!important;
        }
        .flex-lg-wrap-reverse {
        flex-wrap: wrap-reverse!important;
        }
        .flex-lg-fill {
        flex: 1 1 auto!important;
        }
        .flex-lg-grow-0 {
        flex-grow: 0!important;
        }
        .flex-lg-grow-1 {
        flex-grow: 1!important;
        }
        .flex-lg-shrink-0 {
        flex-shrink: 0!important;
        }
        .flex-lg-shrink-1 {
        flex-shrink: 1!important;
        }
        .justify-content-lg-start {
        justify-content: flex-start!important;
        }
        .justify-content-lg-end {
        justify-content: flex-end!important;
        }
        .justify-content-lg-center {
        justify-content: center!important;
        }
        .justify-content-lg-between {
        justify-content: space-between!important;
        }
        .justify-content-lg-around {
        justify-content: space-around!important;
        }
        .align-items-lg-start {
        align-items: flex-start!important;
        }
        .align-items-lg-end {
        align-items: flex-end!important;
        }
        .align-items-lg-center {
        align-items: center!important;
        }
        .align-items-lg-baseline {
        align-items: baseline!important;
        }
        .align-items-lg-stretch {
        align-items: stretch!important;
        }
        .align-content-lg-start {
        align-content: flex-start!important;
        }
        .align-content-lg-end {
        align-content: flex-end!important;
        }
        .align-content-lg-center {
        align-content: center!important;
        }
        .align-content-lg-between {
        align-content: space-between!important;
        }
        .align-content-lg-around {
        align-content: space-around!important;
        }
        .align-content-lg-stretch {
        align-content: stretch!important;
        }
        .align-self-lg-auto {
        align-self: auto!important;
        }
        .align-self-lg-start {
        align-self: flex-start!important;
        }
        .align-self-lg-end {
        align-self: flex-end!important;
        }
        .align-self-lg-center {
        align-self: center!important;
        }
        .align-self-lg-baseline {
        align-self: baseline!important;
        }
        .align-self-lg-stretch {
        align-self: stretch!important;
        }
        }@media(min-width:1200px) {
        .flex-xl-row {
        flex-direction: row!important;
        }
        .flex-xl-column {
        flex-direction: column!important;
        }
        .flex-xl-row-reverse {
        flex-direction: row-reverse!important;
        }
        .flex-xl-column-reverse {
        flex-direction: column-reverse!important;
        }
        .flex-xl-wrap {
        flex-wrap: wrap!important;
        }
        .flex-xl-nowrap {
        flex-wrap: nowrap!important;
        }
        .flex-xl-wrap-reverse {
        flex-wrap: wrap-reverse!important;
        }
        .flex-xl-fill {
        flex: 1 1 auto!important;
        }
        .flex-xl-grow-0 {
        flex-grow: 0!important;
        }
        .flex-xl-grow-1 {
        flex-grow: 1!important;
        }
        .flex-xl-shrink-0 {
        flex-shrink: 0!important;
        }
        .flex-xl-shrink-1 {
        flex-shrink: 1!important;
        }
        .justify-content-xl-start {
        justify-content: flex-start!important;
        }
        .justify-content-xl-end {
        justify-content: flex-end!important;
        }
        .justify-content-xl-center {
        justify-content: center!important;
        }
        .justify-content-xl-between {
        justify-content: space-between!important;
        }
        .justify-content-xl-around {
        justify-content: space-around!important;
        }
        .align-items-xl-start {
        align-items: flex-start!important;
        }
        .align-items-xl-end {
        align-items: flex-end!important;
        }
        .align-items-xl-center {
        align-items: center!important;
        }
        .align-items-xl-baseline {
        align-items: baseline!important;
        }
        .align-items-xl-stretch {
        align-items: stretch!important;
        }
        .align-content-xl-start {
        align-content: flex-start!important;
        }
        .align-content-xl-end {
        align-content: flex-end!important;
        }
        .align-content-xl-center {
        align-content: center!important;
        }
        .align-content-xl-between {
        align-content: space-between!important;
        }
        .align-content-xl-around {
        align-content: space-around!important;
        }
        .align-content-xl-stretch {
        align-content: stretch!important;
        }
        .align-self-xl-auto {
        align-self: auto!important;
        }
        .align-self-xl-start {
        align-self: flex-start!important;
        }
        .align-self-xl-end {
        align-self: flex-end!important;
        }
        .align-self-xl-center {
        align-self: center!important;
        }
        .align-self-xl-baseline {
        align-self: baseline!important;
        }
        .align-self-xl-stretch {
        align-self: stretch!important;
        }
        }.float-left {
        float: left!important;
        }
        .float-right {
        float: right!important;
        }
        .float-none {
        float: none!important;
        }
        @media(min-width:576px) {
        .float-sm-left {
        float: left!important;
        }
        .float-sm-right {
        float: right!important;
        }
        .float-sm-none {
        float: none!important;
        }
        }@media(min-width:768px) {
        .float-md-left {
        float: left!important;
        }
        .float-md-right {
        float: right!important;
        }
        .float-md-none {
        float: none!important;
        }
        }@media(min-width:992px) {
        .float-lg-left {
        float: left!important;
        }
        .float-lg-right {
        float: right!important;
        }
        .float-lg-none {
        float: none!important;
        }
        }@media(min-width:1200px) {
        .float-xl-left {
        float: left!important;
        }
        .float-xl-right {
        float: right!important;
        }
        .float-xl-none {
        float: none!important;
        }
        }.overflow-auto {
        overflow: auto!important;
        }
        .overflow-hidden {
        overflow: hidden!important;
        }
        .position-static {
        position: static!important;
        }
        .position-relative {
        position: relative!important;
        }
        .position-absolute {
        position: absolute!important;
        }
        .position-fixed {
        position: fixed!important;
        }
        .position-sticky {
        position: sticky!important;
        }
        .fixed-top {
        position: fixed;
        top: 0;
        right: 0;
        left: 0;
        z-index: 1030;
        }
        .fixed-bottom {
        position: fixed;
        right: 0;
        bottom: 0;
        left: 0;
        z-index: 1030;
        }
        @supports(position:sticky) {
        .sticky-top {
        position: sticky;
        top: 0;
        z-index: 1020;
        }
        }.sr-only {
        position: absolute;
        width: 1px;
        height: 1px;
        padding: 0;
        overflow: hidden;
        clip: rect(0, 0, 0, 0);
        white-space: nowrap;
        border: 0;
        }
        .sr-only-focusable:active, .sr-only-focusable:focus {
        position: static;
        width: auto;
        height: auto;
        overflow: visible;
        clip: auto;
        white-space: normal;
        }
        .shadow-sm {
        box-shadow: 0 .125rem .25rem rgba(0, 0, 0, .075)!important;
        }
        .shadow {
        box-shadow: 0 .5rem 1rem rgba(0, 0, 0, .15)!important;
        }
        .shadow-lg {
        box-shadow: 0 1rem 3rem rgba(0, 0, 0, .175)!important;
        }
        .shadow-none {
        box-shadow: none!important;
        }
        .w-25 {
        width: 25%!important;
        }
        .w-50 {
        width: 50%!important;
        }
        .w-75 {
        width: 75%!important;
        }
        .w-100 {
        width: 100%!important;
        }
        .w-auto {
        width: auto!important;
        }
        .h-25 {
        height: 25%!important;
        }
        .h-50 {
        height: 50%!important;
        }
        .h-75 {
        height: 75%!important;
        }
        .h-100 {
        height: 100%!important;
        }
        .h-auto {
        height: auto!important;
        }
        .mw-100 {
        max-width: 100%!important;
        }
        .mh-100 {
        max-height: 100%!important;
        }
        .min-vw-100 {
        min-width: 100vw!important;
        }
        .min-vh-100 {
        min-height: 100vh!important;
        }
        .vw-100 {
        width: 100vw!important;
        }
        .vh-100 {
        height: 100vh!important;
        }
        .m-0 {
        margin: 0!important;
        }
        .mt-0, .my-0 {
        margin-top: 0!important;
        }
        .mr-0, .mx-0 {
        margin-right: 0!important;
        }
        .mb-0, .my-0 {
        margin-bottom: 0!important;
        }
        .ml-0, .mx-0 {
        margin-left: 0!important;
        }
        .m-1 {
        margin: .25rem!important;
        }
        .mt-1, .my-1 {
        margin-top: .25rem!important;
        }
        .mr-1, .mx-1 {
        margin-right: .25rem!important;
        }
        .mb-1, .my-1 {
        margin-bottom: .25rem!important;
        }
        .ml-1, .mx-1 {
        margin-left: .25rem!important;
        }
        .m-2 {
        margin: .5rem!important;
        }
        .mt-2, .my-2 {
        margin-top: .5rem!important;
        }
        .mr-2, .mx-2 {
        margin-right: .5rem!important;
        }
        .mb-2, .my-2 {
        margin-bottom: .5rem!important;
        }
        .ml-2, .mx-2 {
        margin-left: .5rem!important;
        }
        .m-3 {
        margin: 1rem!important;
        }
        .mt-3, .my-3 {
        margin-top: 1rem!important;
        }
        .mr-3, .mx-3 {
        margin-right: 1rem!important;
        }
        .mb-3, .my-3 {
        margin-bottom: 1rem!important;
        }
        .ml-3, .mx-3 {
        margin-left: 1rem!important;
        }
        .m-4 {
        margin: 1.5rem!important;
        }
        .mt-4, .my-4 {
        margin-top: 1.5rem!important;
        }
        .mr-4, .mx-4 {
        margin-right: 1.5rem!important;
        }
        .mb-4, .my-4 {
        margin-bottom: 1.5rem!important;
        }
        .ml-4, .mx-4 {
        margin-left: 1.5rem!important;
        }
        .m-5 {
        margin: 3rem!important;
        }
        .mt-5, .my-5 {
        margin-top: 3rem!important;
        }
        .mr-5, .mx-5 {
        margin-right: 3rem!important;
        }
        .mb-5, .my-5 {
        margin-bottom: 3rem!important;
        }
        .ml-5, .mx-5 {
        margin-left: 3rem!important;
        }
        .p-0 {
        padding: 0!important;
        }
        .pt-0, .py-0 {
        padding-top: 0!important;
        }
        .pr-0, .px-0 {
        padding-right: 0!important;
        }
        .pb-0, .py-0 {
        padding-bottom: 0!important;
        }
        .pl-0, .px-0 {
        padding-left: 0!important;
        }
        .p-1 {
        padding: .25rem!important;
        }
        .pt-1, .py-1 {
        padding-top: .25rem!important;
        }
        .pr-1, .px-1 {
        padding-right: .25rem!important;
        }
        .pb-1, .py-1 {
        padding-bottom: .25rem!important;
        }
        .pl-1, .px-1 {
        padding-left: .25rem!important;
        }
        .p-2 {
        padding: .5rem!important;
        }
        .pt-2, .py-2 {
        padding-top: .5rem!important;
        }
        .pr-2, .px-2 {
        padding-right: .5rem!important;
        }
        .pb-2, .py-2 {
        padding-bottom: .5rem!important;
        }
        .pl-2, .px-2 {
        padding-left: .5rem!important;
        }
        .p-3 {
        padding: 1rem!important;
        }
        .pt-3, .py-3 {
        padding-top: 1rem!important;
        }
        .pr-3, .px-3 {
        padding-right: 1rem!important;
        }
        .pb-3, .py-3 {
        padding-bottom: 1rem!important;
        }
        .pl-3, .px-3 {
        padding-left: 1rem!important;
        }
        .p-4 {
        padding: 1.5rem!important;
        }
        .pt-4, .py-4 {
        padding-top: 1.5rem!important;
        }
        .pr-4, .px-4 {
        padding-right: 1.5rem!important;
        }
        .pb-4, .py-4 {
        padding-bottom: 1.5rem!important;
        }
        .pl-4, .px-4 {
        padding-left: 1.5rem!important;
        }
        .p-5 {
        padding: 3rem!important;
        }
        .pt-5, .py-5 {
        padding-top: 3rem!important;
        }
        .pr-5, .px-5 {
        padding-right: 3rem!important;
        }
        .pb-5, .py-5 {
        padding-bottom: 3rem!important;
        }
        .pl-5, .px-5 {
        padding-left: 3rem!important;
        }
        .m-n1 {
        margin: -.25rem!important;
        }
        .mt-n1, .my-n1 {
        margin-top: -.25rem!important;
        }
        .mr-n1, .mx-n1 {
        margin-right: -.25rem!important;
        }
        .mb-n1, .my-n1 {
        margin-bottom: -.25rem!important;
        }
        .ml-n1, .mx-n1 {
        margin-left: -.25rem!important;
        }
        .m-n2 {
        margin: -.5rem!important;
        }
        .mt-n2, .my-n2 {
        margin-top: -.5rem!important;
        }
        .mr-n2, .mx-n2 {
        margin-right: -.5rem!important;
        }
        .mb-n2, .my-n2 {
        margin-bottom: -.5rem!important;
        }
        .ml-n2, .mx-n2 {
        margin-left: -.5rem!important;
        }
        .m-n3 {
        margin: -1rem!important;
        }
        .mt-n3, .my-n3 {
        margin-top: -1rem!important;
        }
        .mr-n3, .mx-n3 {
        margin-right: -1rem!important;
        }
        .mb-n3, .my-n3 {
        margin-bottom: -1rem!important;
        }
        .ml-n3, .mx-n3 {
        margin-left: -1rem!important;
        }
        .m-n4 {
        margin: -1.5rem!important;
        }
        .mt-n4, .my-n4 {
        margin-top: -1.5rem!important;
        }
        .mr-n4, .mx-n4 {
        margin-right: -1.5rem!important;
        }
        .mb-n4, .my-n4 {
        margin-bottom: -1.5rem!important;
        }
        .ml-n4, .mx-n4 {
        margin-left: -1.5rem!important;
        }
        .m-n5 {
        margin: -3rem!important;
        }
        .mt-n5, .my-n5 {
        margin-top: -3rem!important;
        }
        .mr-n5, .mx-n5 {
        margin-right: -3rem!important;
        }
        .mb-n5, .my-n5 {
        margin-bottom: -3rem!important;
        }
        .ml-n5, .mx-n5 {
        margin-left: -3rem!important;
        }
        .m-auto {
        margin: auto!important;
        }
        .mt-auto, .my-auto {
        margin-top: auto!important;
        }
        .mr-auto, .mx-auto {
        margin-right: auto!important;
        }
        .mb-auto, .my-auto {
        margin-bottom: auto!important;
        }
        .ml-auto, .mx-auto {
        margin-left: auto!important;
        }
        @media(min-width:576px) {
        .m-sm-0 {
        margin: 0!important;
        }
        .mt-sm-0, .my-sm-0 {
        margin-top: 0!important;
        }
        .mr-sm-0, .mx-sm-0 {
        margin-right: 0!important;
        }
        .mb-sm-0, .my-sm-0 {
        margin-bottom: 0!important;
        }
        .ml-sm-0, .mx-sm-0 {
        margin-left: 0!important;
        }
        .m-sm-1 {
        margin: .25rem!important;
        }
        .mt-sm-1, .my-sm-1 {
        margin-top: .25rem!important;
        }
        .mr-sm-1, .mx-sm-1 {
        margin-right: .25rem!important;
        }
        .mb-sm-1, .my-sm-1 {
        margin-bottom: .25rem!important;
        }
        .ml-sm-1, .mx-sm-1 {
        margin-left: .25rem!important;
        }
        .m-sm-2 {
        margin: .5rem!important;
        }
        .mt-sm-2, .my-sm-2 {
        margin-top: .5rem!important;
        }
        .mr-sm-2, .mx-sm-2 {
        margin-right: .5rem!important;
        }
        .mb-sm-2, .my-sm-2 {
        margin-bottom: .5rem!important;
        }
        .ml-sm-2, .mx-sm-2 {
        margin-left: .5rem!important;
        }
        .m-sm-3 {
        margin: 1rem!important;
        }
        .mt-sm-3, .my-sm-3 {
        margin-top: 1rem!important;
        }
        .mr-sm-3, .mx-sm-3 {
        margin-right: 1rem!important;
        }
        .mb-sm-3, .my-sm-3 {
        margin-bottom: 1rem!important;
        }
        .ml-sm-3, .mx-sm-3 {
        margin-left: 1rem!important;
        }
        .m-sm-4 {
        margin: 1.5rem!important;
        }
        .mt-sm-4, .my-sm-4 {
        margin-top: 1.5rem!important;
        }
        .mr-sm-4, .mx-sm-4 {
        margin-right: 1.5rem!important;
        }
        .mb-sm-4, .my-sm-4 {
        margin-bottom: 1.5rem!important;
        }
        .ml-sm-4, .mx-sm-4 {
        margin-left: 1.5rem!important;
        }
        .m-sm-5 {
        margin: 3rem!important;
        }
        .mt-sm-5, .my-sm-5 {
        margin-top: 3rem!important;
        }
        .mr-sm-5, .mx-sm-5 {
        margin-right: 3rem!important;
        }
        .mb-sm-5, .my-sm-5 {
        margin-bottom: 3rem!important;
        }
        .ml-sm-5, .mx-sm-5 {
        margin-left: 3rem!important;
        }
        .p-sm-0 {
        padding: 0!important;
        }
        .pt-sm-0, .py-sm-0 {
        padding-top: 0!important;
        }
        .pr-sm-0, .px-sm-0 {
        padding-right: 0!important;
        }
        .pb-sm-0, .py-sm-0 {
        padding-bottom: 0!important;
        }
        .pl-sm-0, .px-sm-0 {
        padding-left: 0!important;
        }
        .p-sm-1 {
        padding: .25rem!important;
        }
        .pt-sm-1, .py-sm-1 {
        padding-top: .25rem!important;
        }
        .pr-sm-1, .px-sm-1 {
        padding-right: .25rem!important;
        }
        .pb-sm-1, .py-sm-1 {
        padding-bottom: .25rem!important;
        }
        .pl-sm-1, .px-sm-1 {
        padding-left: .25rem!important;
        }
        .p-sm-2 {
        padding: .5rem!important;
        }
        .pt-sm-2, .py-sm-2 {
        padding-top: .5rem!important;
        }
        .pr-sm-2, .px-sm-2 {
        padding-right: .5rem!important;
        }
        .pb-sm-2, .py-sm-2 {
        padding-bottom: .5rem!important;
        }
        .pl-sm-2, .px-sm-2 {
        padding-left: .5rem!important;
        }
        .p-sm-3 {
        padding: 1rem!important;
        }
        .pt-sm-3, .py-sm-3 {
        padding-top: 1rem!important;
        }
        .pr-sm-3, .px-sm-3 {
        padding-right: 1rem!important;
        }
        .pb-sm-3, .py-sm-3 {
        padding-bottom: 1rem!important;
        }
        .pl-sm-3, .px-sm-3 {
        padding-left: 1rem!important;
        }
        .p-sm-4 {
        padding: 1.5rem!important;
        }
        .pt-sm-4, .py-sm-4 {
        padding-top: 1.5rem!important;
        }
        .pr-sm-4, .px-sm-4 {
        padding-right: 1.5rem!important;
        }
        .pb-sm-4, .py-sm-4 {
        padding-bottom: 1.5rem!important;
        }
        .pl-sm-4, .px-sm-4 {
        padding-left: 1.5rem!important;
        }
        .p-sm-5 {
        padding: 3rem!important;
        }
        .pt-sm-5, .py-sm-5 {
        padding-top: 3rem!important;
        }
        .pr-sm-5, .px-sm-5 {
        padding-right: 3rem!important;
        }
        .pb-sm-5, .py-sm-5 {
        padding-bottom: 3rem!important;
        }
        .pl-sm-5, .px-sm-5 {
        padding-left: 3rem!important;
        }
        .m-sm-n1 {
        margin: -.25rem!important;
        }
        .mt-sm-n1, .my-sm-n1 {
        margin-top: -.25rem!important;
        }
        .mr-sm-n1, .mx-sm-n1 {
        margin-right: -.25rem!important;
        }
        .mb-sm-n1, .my-sm-n1 {
        margin-bottom: -.25rem!important;
        }
        .ml-sm-n1, .mx-sm-n1 {
        margin-left: -.25rem!important;
        }
        .m-sm-n2 {
        margin: -.5rem!important;
        }
        .mt-sm-n2, .my-sm-n2 {
        margin-top: -.5rem!important;
        }
        .mr-sm-n2, .mx-sm-n2 {
        margin-right: -.5rem!important;
        }
        .mb-sm-n2, .my-sm-n2 {
        margin-bottom: -.5rem!important;
        }
        .ml-sm-n2, .mx-sm-n2 {
        margin-left: -.5rem!important;
        }
        .m-sm-n3 {
        margin: -1rem!important;
        }
        .mt-sm-n3, .my-sm-n3 {
        margin-top: -1rem!important;
        }
        .mr-sm-n3, .mx-sm-n3 {
        margin-right: -1rem!important;
        }
        .mb-sm-n3, .my-sm-n3 {
        margin-bottom: -1rem!important;
        }
        .ml-sm-n3, .mx-sm-n3 {
        margin-left: -1rem!important;
        }
        .m-sm-n4 {
        margin: -1.5rem!important;
        }
        .mt-sm-n4, .my-sm-n4 {
        margin-top: -1.5rem!important;
        }
        .mr-sm-n4, .mx-sm-n4 {
        margin-right: -1.5rem!important;
        }
        .mb-sm-n4, .my-sm-n4 {
        margin-bottom: -1.5rem!important;
        }
        .ml-sm-n4, .mx-sm-n4 {
        margin-left: -1.5rem!important;
        }
        .m-sm-n5 {
        margin: -3rem!important;
        }
        .mt-sm-n5, .my-sm-n5 {
        margin-top: -3rem!important;
        }
        .mr-sm-n5, .mx-sm-n5 {
        margin-right: -3rem!important;
        }
        .mb-sm-n5, .my-sm-n5 {
        margin-bottom: -3rem!important;
        }
        .ml-sm-n5, .mx-sm-n5 {
        margin-left: -3rem!important;
        }
        .m-sm-auto {
        margin: auto!important;
        }
        .mt-sm-auto, .my-sm-auto {
        margin-top: auto!important;
        }
        .mr-sm-auto, .mx-sm-auto {
        margin-right: auto!important;
        }
        .mb-sm-auto, .my-sm-auto {
        margin-bottom: auto!important;
        }
        .ml-sm-auto, .mx-sm-auto {
        margin-left: auto!important;
        }
        }@media(min-width:768px) {
        .m-md-0 {
        margin: 0!important;
        }
        .mt-md-0, .my-md-0 {
        margin-top: 0!important;
        }
        .mr-md-0, .mx-md-0 {
        margin-right: 0!important;
        }
        .mb-md-0, .my-md-0 {
        margin-bottom: 0!important;
        }
        .ml-md-0, .mx-md-0 {
        margin-left: 0!important;
        }
        .m-md-1 {
        margin: .25rem!important;
        }
        .mt-md-1, .my-md-1 {
        margin-top: .25rem!important;
        }
        .mr-md-1, .mx-md-1 {
        margin-right: .25rem!important;
        }
        .mb-md-1, .my-md-1 {
        margin-bottom: .25rem!important;
        }
        .ml-md-1, .mx-md-1 {
        margin-left: .25rem!important;
        }
        .m-md-2 {
        margin: .5rem!important;
        }
        .mt-md-2, .my-md-2 {
        margin-top: .5rem!important;
        }
        .mr-md-2, .mx-md-2 {
        margin-right: .5rem!important;
        }
        .mb-md-2, .my-md-2 {
        margin-bottom: .5rem!important;
        }
        .ml-md-2, .mx-md-2 {
        margin-left: .5rem!important;
        }
        .m-md-3 {
        margin: 1rem!important;
        }
        .mt-md-3, .my-md-3 {
        margin-top: 1rem!important;
        }
        .mr-md-3, .mx-md-3 {
        margin-right: 1rem!important;
        }
        .mb-md-3, .my-md-3 {
        margin-bottom: 1rem!important;
        }
        .ml-md-3, .mx-md-3 {
        margin-left: 1rem!important;
        }
        .m-md-4 {
        margin: 1.5rem!important;
        }
        .mt-md-4, .my-md-4 {
        margin-top: 1.5rem!important;
        }
        .mr-md-4, .mx-md-4 {
        margin-right: 1.5rem!important;
        }
        .mb-md-4, .my-md-4 {
        margin-bottom: 1.5rem!important;
        }
        .ml-md-4, .mx-md-4 {
        margin-left: 1.5rem!important;
        }
        .m-md-5 {
        margin: 3rem!important;
        }
        .mt-md-5, .my-md-5 {
        margin-top: 3rem!important;
        }
        .mr-md-5, .mx-md-5 {
        margin-right: 3rem!important;
        }
        .mb-md-5, .my-md-5 {
        margin-bottom: 3rem!important;
        }
        .ml-md-5, .mx-md-5 {
        margin-left: 3rem!important;
        }
        .p-md-0 {
        padding: 0!important;
        }
        .pt-md-0, .py-md-0 {
        padding-top: 0!important;
        }
        .pr-md-0, .px-md-0 {
        padding-right: 0!important;
        }
        .pb-md-0, .py-md-0 {
        padding-bottom: 0!important;
        }
        .pl-md-0, .px-md-0 {
        padding-left: 0!important;
        }
        .p-md-1 {
        padding: .25rem!important;
        }
        .pt-md-1, .py-md-1 {
        padding-top: .25rem!important;
        }
        .pr-md-1, .px-md-1 {
        padding-right: .25rem!important;
        }
        .pb-md-1, .py-md-1 {
        padding-bottom: .25rem!important;
        }
        .pl-md-1, .px-md-1 {
        padding-left: .25rem!important;
        }
        .p-md-2 {
        padding: .5rem!important;
        }
        .pt-md-2, .py-md-2 {
        padding-top: .5rem!important;
        }
        .pr-md-2, .px-md-2 {
        padding-right: .5rem!important;
        }
        .pb-md-2, .py-md-2 {
        padding-bottom: .5rem!important;
        }
        .pl-md-2, .px-md-2 {
        padding-left: .5rem!important;
        }
        .p-md-3 {
        padding: 1rem!important;
        }
        .pt-md-3, .py-md-3 {
        padding-top: 1rem!important;
        }
        .pr-md-3, .px-md-3 {
        padding-right: 1rem!important;
        }
        .pb-md-3, .py-md-3 {
        padding-bottom: 1rem!important;
        }
        .pl-md-3, .px-md-3 {
        padding-left: 1rem!important;
        }
        .p-md-4 {
        padding: 1.5rem!important;
        }
        .pt-md-4, .py-md-4 {
        padding-top: 1.5rem!important;
        }
        .pr-md-4, .px-md-4 {
        padding-right: 1.5rem!important;
        }
        .pb-md-4, .py-md-4 {
        padding-bottom: 1.5rem!important;
        }
        .pl-md-4, .px-md-4 {
        padding-left: 1.5rem!important;
        }
        .p-md-5 {
        padding: 3rem!important;
        }
        .pt-md-5, .py-md-5 {
        padding-top: 3rem!important;
        }
        .pr-md-5, .px-md-5 {
        padding-right: 3rem!important;
        }
        .pb-md-5, .py-md-5 {
        padding-bottom: 3rem!important;
        }
        .pl-md-5, .px-md-5 {
        padding-left: 3rem!important;
        }
        .m-md-n1 {
        margin: -.25rem!important;
        }
        .mt-md-n1, .my-md-n1 {
        margin-top: -.25rem!important;
        }
        .mr-md-n1, .mx-md-n1 {
        margin-right: -.25rem!important;
        }
        .mb-md-n1, .my-md-n1 {
        margin-bottom: -.25rem!important;
        }
        .ml-md-n1, .mx-md-n1 {
        margin-left: -.25rem!important;
        }
        .m-md-n2 {
        margin: -.5rem!important;
        }
        .mt-md-n2, .my-md-n2 {
        margin-top: -.5rem!important;
        }
        .mr-md-n2, .mx-md-n2 {
        margin-right: -.5rem!important;
        }
        .mb-md-n2, .my-md-n2 {
        margin-bottom: -.5rem!important;
        }
        .ml-md-n2, .mx-md-n2 {
        margin-left: -.5rem!important;
        }
        .m-md-n3 {
        margin: -1rem!important;
        }
        .mt-md-n3, .my-md-n3 {
        margin-top: -1rem!important;
        }
        .mr-md-n3, .mx-md-n3 {
        margin-right: -1rem!important;
        }
        .mb-md-n3, .my-md-n3 {
        margin-bottom: -1rem!important;
        }
        .ml-md-n3, .mx-md-n3 {
        margin-left: -1rem!important;
        }
        .m-md-n4 {
        margin: -1.5rem!important;
        }
        .mt-md-n4, .my-md-n4 {
        margin-top: -1.5rem!important;
        }
        .mr-md-n4, .mx-md-n4 {
        margin-right: -1.5rem!important;
        }
        .mb-md-n4, .my-md-n4 {
        margin-bottom: -1.5rem!important;
        }
        .ml-md-n4, .mx-md-n4 {
        margin-left: -1.5rem!important;
        }
        .m-md-n5 {
        margin: -3rem!important;
        }
        .mt-md-n5, .my-md-n5 {
        margin-top: -3rem!important;
        }
        .mr-md-n5, .mx-md-n5 {
        margin-right: -3rem!important;
        }
        .mb-md-n5, .my-md-n5 {
        margin-bottom: -3rem!important;
        }
        .ml-md-n5, .mx-md-n5 {
        margin-left: -3rem!important;
        }
        .m-md-auto {
        margin: auto!important;
        }
        .mt-md-auto, .my-md-auto {
        margin-top: auto!important;
        }
        .mr-md-auto, .mx-md-auto {
        margin-right: auto!important;
        }
        .mb-md-auto, .my-md-auto {
        margin-bottom: auto!important;
        }
        .ml-md-auto, .mx-md-auto {
        margin-left: auto!important;
        }
        }@media(min-width:992px) {
        .m-lg-0 {
        margin: 0!important;
        }
        .mt-lg-0, .my-lg-0 {
        margin-top: 0!important;
        }
        .mr-lg-0, .mx-lg-0 {
        margin-right: 0!important;
        }
        .mb-lg-0, .my-lg-0 {
        margin-bottom: 0!important;
        }
        .ml-lg-0, .mx-lg-0 {
        margin-left: 0!important;
        }
        .m-lg-1 {
        margin: .25rem!important;
        }
        .mt-lg-1, .my-lg-1 {
        margin-top: .25rem!important;
        }
        .mr-lg-1, .mx-lg-1 {
        margin-right: .25rem!important;
        }
        .mb-lg-1, .my-lg-1 {
        margin-bottom: .25rem!important;
        }
        .ml-lg-1, .mx-lg-1 {
        margin-left: .25rem!important;
        }
        .m-lg-2 {
        margin: .5rem!important;
        }
        .mt-lg-2, .my-lg-2 {
        margin-top: .5rem!important;
        }
        .mr-lg-2, .mx-lg-2 {
        margin-right: .5rem!important;
        }
        .mb-lg-2, .my-lg-2 {
        margin-bottom: .5rem!important;
        }
        .ml-lg-2, .mx-lg-2 {
        margin-left: .5rem!important;
        }
        .m-lg-3 {
        margin: 1rem!important;
        }
        .mt-lg-3, .my-lg-3 {
        margin-top: 1rem!important;
        }
        .mr-lg-3, .mx-lg-3 {
        margin-right: 1rem!important;
        }
        .mb-lg-3, .my-lg-3 {
        margin-bottom: 1rem!important;
        }
        .ml-lg-3, .mx-lg-3 {
        margin-left: 1rem!important;
        }
        .m-lg-4 {
        margin: 1.5rem!important;
        }
        .mt-lg-4, .my-lg-4 {
        margin-top: 1.5rem!important;
        }
        .mr-lg-4, .mx-lg-4 {
        margin-right: 1.5rem!important;
        }
        .mb-lg-4, .my-lg-4 {
        margin-bottom: 1.5rem!important;
        }
        .ml-lg-4, .mx-lg-4 {
        margin-left: 1.5rem!important;
        }
        .m-lg-5 {
        margin: 3rem!important;
        }
        .mt-lg-5, .my-lg-5 {
        margin-top: 3rem!important;
        }
        .mr-lg-5, .mx-lg-5 {
        margin-right: 3rem!important;
        }
        .mb-lg-5, .my-lg-5 {
        margin-bottom: 3rem!important;
        }
        .ml-lg-5, .mx-lg-5 {
        margin-left: 3rem!important;
        }
        .p-lg-0 {
        padding: 0!important;
        }
        .pt-lg-0, .py-lg-0 {
        padding-top: 0!important;
        }
        .pr-lg-0, .px-lg-0 {
        padding-right: 0!important;
        }
        .pb-lg-0, .py-lg-0 {
        padding-bottom: 0!important;
        }
        .pl-lg-0, .px-lg-0 {
        padding-left: 0!important;
        }
        .p-lg-1 {
        padding: .25rem!important;
        }
        .pt-lg-1, .py-lg-1 {
        padding-top: .25rem!important;
        }
        .pr-lg-1, .px-lg-1 {
        padding-right: .25rem!important;
        }
        .pb-lg-1, .py-lg-1 {
        padding-bottom: .25rem!important;
        }
        .pl-lg-1, .px-lg-1 {
        padding-left: .25rem!important;
        }
        .p-lg-2 {
        padding: .5rem!important;
        }
        .pt-lg-2, .py-lg-2 {
        padding-top: .5rem!important;
        }
        .pr-lg-2, .px-lg-2 {
        padding-right: .5rem!important;
        }
        .pb-lg-2, .py-lg-2 {
        padding-bottom: .5rem!important;
        }
        .pl-lg-2, .px-lg-2 {
        padding-left: .5rem!important;
        }
        .p-lg-3 {
        padding: 1rem!important;
        }
        .pt-lg-3, .py-lg-3 {
        padding-top: 1rem!important;
        }
        .pr-lg-3, .px-lg-3 {
        padding-right: 1rem!important;
        }
        .pb-lg-3, .py-lg-3 {
        padding-bottom: 1rem!important;
        }
        .pl-lg-3, .px-lg-3 {
        padding-left: 1rem!important;
        }
        .p-lg-4 {
        padding: 1.5rem!important;
        }
        .pt-lg-4, .py-lg-4 {
        padding-top: 1.5rem!important;
        }
        .pr-lg-4, .px-lg-4 {
        padding-right: 1.5rem!important;
        }
        .pb-lg-4, .py-lg-4 {
        padding-bottom: 1.5rem!important;
        }
        .pl-lg-4, .px-lg-4 {
        padding-left: 1.5rem!important;
        }
        .p-lg-5 {
        padding: 3rem!important;
        }
        .pt-lg-5, .py-lg-5 {
        padding-top: 3rem!important;
        }
        .pr-lg-5, .px-lg-5 {
        padding-right: 3rem!important;
        }
        .pb-lg-5, .py-lg-5 {
        padding-bottom: 3rem!important;
        }
        .pl-lg-5, .px-lg-5 {
        padding-left: 3rem!important;
        }
        .m-lg-n1 {
        margin: -.25rem!important;
        }
        .mt-lg-n1, .my-lg-n1 {
        margin-top: -.25rem!important;
        }
        .mr-lg-n1, .mx-lg-n1 {
        margin-right: -.25rem!important;
        }
        .mb-lg-n1, .my-lg-n1 {
        margin-bottom: -.25rem!important;
        }
        .ml-lg-n1, .mx-lg-n1 {
        margin-left: -.25rem!important;
        }
        .m-lg-n2 {
        margin: -.5rem!important;
        }
        .mt-lg-n2, .my-lg-n2 {
        margin-top: -.5rem!important;
        }
        .mr-lg-n2, .mx-lg-n2 {
        margin-right: -.5rem!important;
        }
        .mb-lg-n2, .my-lg-n2 {
        margin-bottom: -.5rem!important;
        }
        .ml-lg-n2, .mx-lg-n2 {
        margin-left: -.5rem!important;
        }
        .m-lg-n3 {
        margin: -1rem!important;
        }
        .mt-lg-n3, .my-lg-n3 {
        margin-top: -1rem!important;
        }
        .mr-lg-n3, .mx-lg-n3 {
        margin-right: -1rem!important;
        }
        .mb-lg-n3, .my-lg-n3 {
        margin-bottom: -1rem!important;
        }
        .ml-lg-n3, .mx-lg-n3 {
        margin-left: -1rem!important;
        }
        .m-lg-n4 {
        margin: -1.5rem!important;
        }
        .mt-lg-n4, .my-lg-n4 {
        margin-top: -1.5rem!important;
        }
        .mr-lg-n4, .mx-lg-n4 {
        margin-right: -1.5rem!important;
        }
        .mb-lg-n4, .my-lg-n4 {
        margin-bottom: -1.5rem!important;
        }
        .ml-lg-n4, .mx-lg-n4 {
        margin-left: -1.5rem!important;
        }
        .m-lg-n5 {
        margin: -3rem!important;
        }
        .mt-lg-n5, .my-lg-n5 {
        margin-top: -3rem!important;
        }
        .mr-lg-n5, .mx-lg-n5 {
        margin-right: -3rem!important;
        }
        .mb-lg-n5, .my-lg-n5 {
        margin-bottom: -3rem!important;
        }
        .ml-lg-n5, .mx-lg-n5 {
        margin-left: -3rem!important;
        }
        .m-lg-auto {
        margin: auto!important;
        }
        .mt-lg-auto, .my-lg-auto {
        margin-top: auto!important;
        }
        .mr-lg-auto, .mx-lg-auto {
        margin-right: auto!important;
        }
        .mb-lg-auto, .my-lg-auto {
        margin-bottom: auto!important;
        }
        .ml-lg-auto, .mx-lg-auto {
        margin-left: auto!important;
        }
        }@media(min-width:1200px) {
        .m-xl-0 {
        margin: 0!important;
        }
        .mt-xl-0, .my-xl-0 {
        margin-top: 0!important;
        }
        .mr-xl-0, .mx-xl-0 {
        margin-right: 0!important;
        }
        .mb-xl-0, .my-xl-0 {
        margin-bottom: 0!important;
        }
        .ml-xl-0, .mx-xl-0 {
        margin-left: 0!important;
        }
        .m-xl-1 {
        margin: .25rem!important;
        }
        .mt-xl-1, .my-xl-1 {
        margin-top: .25rem!important;
        }
        .mr-xl-1, .mx-xl-1 {
        margin-right: .25rem!important;
        }
        .mb-xl-1, .my-xl-1 {
        margin-bottom: .25rem!important;
        }
        .ml-xl-1, .mx-xl-1 {
        margin-left: .25rem!important;
        }
        .m-xl-2 {
        margin: .5rem!important;
        }
        .mt-xl-2, .my-xl-2 {
        margin-top: .5rem!important;
        }
        .mr-xl-2, .mx-xl-2 {
        margin-right: .5rem!important;
        }
        .mb-xl-2, .my-xl-2 {
        margin-bottom: .5rem!important;
        }
        .ml-xl-2, .mx-xl-2 {
        margin-left: .5rem!important;
        }
        .m-xl-3 {
        margin: 1rem!important;
        }
        .mt-xl-3, .my-xl-3 {
        margin-top: 1rem!important;
        }
        .mr-xl-3, .mx-xl-3 {
        margin-right: 1rem!important;
        }
        .mb-xl-3, .my-xl-3 {
        margin-bottom: 1rem!important;
        }
        .ml-xl-3, .mx-xl-3 {
        margin-left: 1rem!important;
        }
        .m-xl-4 {
        margin: 1.5rem!important;
        }
        .mt-xl-4, .my-xl-4 {
        margin-top: 1.5rem!important;
        }
        .mr-xl-4, .mx-xl-4 {
        margin-right: 1.5rem!important;
        }
        .mb-xl-4, .my-xl-4 {
        margin-bottom: 1.5rem!important;
        }
        .ml-xl-4, .mx-xl-4 {
        margin-left: 1.5rem!important;
        }
        .m-xl-5 {
        margin: 3rem!important;
        }
        .mt-xl-5, .my-xl-5 {
        margin-top: 3rem!important;
        }
        .mr-xl-5, .mx-xl-5 {
        margin-right: 3rem!important;
        }
        .mb-xl-5, .my-xl-5 {
        margin-bottom: 3rem!important;
        }
        .ml-xl-5, .mx-xl-5 {
        margin-left: 3rem!important;
        }
        .p-xl-0 {
        padding: 0!important;
        }
        .pt-xl-0, .py-xl-0 {
        padding-top: 0!important;
        }
        .pr-xl-0, .px-xl-0 {
        padding-right: 0!important;
        }
        .pb-xl-0, .py-xl-0 {
        padding-bottom: 0!important;
        }
        .pl-xl-0, .px-xl-0 {
        padding-left: 0!important;
        }
        .p-xl-1 {
        padding: .25rem!important;
        }
        .pt-xl-1, .py-xl-1 {
        padding-top: .25rem!important;
        }
        .pr-xl-1, .px-xl-1 {
        padding-right: .25rem!important;
        }
        .pb-xl-1, .py-xl-1 {
        padding-bottom: .25rem!important;
        }
        .pl-xl-1, .px-xl-1 {
        padding-left: .25rem!important;
        }
        .p-xl-2 {
        padding: .5rem!important;
        }
        .pt-xl-2, .py-xl-2 {
        padding-top: .5rem!important;
        }
        .pr-xl-2, .px-xl-2 {
        padding-right: .5rem!important;
        }
        .pb-xl-2, .py-xl-2 {
        padding-bottom: .5rem!important;
        }
        .pl-xl-2, .px-xl-2 {
        padding-left: .5rem!important;
        }
        .p-xl-3 {
        padding: 1rem!important;
        }
        .pt-xl-3, .py-xl-3 {
        padding-top: 1rem!important;
        }
        .pr-xl-3, .px-xl-3 {
        padding-right: 1rem!important;
        }
        .pb-xl-3, .py-xl-3 {
        padding-bottom: 1rem!important;
        }
        .pl-xl-3, .px-xl-3 {
        padding-left: 1rem!important;
        }
        .p-xl-4 {
        padding: 1.5rem!important;
        }
        .pt-xl-4, .py-xl-4 {
        padding-top: 1.5rem!important;
        }
        .pr-xl-4, .px-xl-4 {
        padding-right: 1.5rem!important;
        }
        .pb-xl-4, .py-xl-4 {
        padding-bottom: 1.5rem!important;
        }
        .pl-xl-4, .px-xl-4 {
        padding-left: 1.5rem!important;
        }
        .p-xl-5 {
        padding: 3rem!important;
        }
        .pt-xl-5, .py-xl-5 {
        padding-top: 3rem!important;
        }
        .pr-xl-5, .px-xl-5 {
        padding-right: 3rem!important;
        }
        .pb-xl-5, .py-xl-5 {
        padding-bottom: 3rem!important;
        }
        .pl-xl-5, .px-xl-5 {
        padding-left: 3rem!important;
        }
        .m-xl-n1 {
        margin: -.25rem!important;
        }
        .mt-xl-n1, .my-xl-n1 {
        margin-top: -.25rem!important;
        }
        .mr-xl-n1, .mx-xl-n1 {
        margin-right: -.25rem!important;
        }
        .mb-xl-n1, .my-xl-n1 {
        margin-bottom: -.25rem!important;
        }
        .ml-xl-n1, .mx-xl-n1 {
        margin-left: -.25rem!important;
        }
        .m-xl-n2 {
        margin: -.5rem!important;
        }
        .mt-xl-n2, .my-xl-n2 {
        margin-top: -.5rem!important;
        }
        .mr-xl-n2, .mx-xl-n2 {
        margin-right: -.5rem!important;
        }
        .mb-xl-n2, .my-xl-n2 {
        margin-bottom: -.5rem!important;
        }
        .ml-xl-n2, .mx-xl-n2 {
        margin-left: -.5rem!important;
        }
        .m-xl-n3 {
        margin: -1rem!important;
        }
        .mt-xl-n3, .my-xl-n3 {
        margin-top: -1rem!important;
        }
        .mr-xl-n3, .mx-xl-n3 {
        margin-right: -1rem!important;
        }
        .mb-xl-n3, .my-xl-n3 {
        margin-bottom: -1rem!important;
        }
        .ml-xl-n3, .mx-xl-n3 {
        margin-left: -1rem!important;
        }
        .m-xl-n4 {
        margin: -1.5rem!important;
        }
        .mt-xl-n4, .my-xl-n4 {
        margin-top: -1.5rem!important;
        }
        .mr-xl-n4, .mx-xl-n4 {
        margin-right: -1.5rem!important;
        }
        .mb-xl-n4, .my-xl-n4 {
        margin-bottom: -1.5rem!important;
        }
        .ml-xl-n4, .mx-xl-n4 {
        margin-left: -1.5rem!important;
        }
        .m-xl-n5 {
        margin: -3rem!important;
        }
        .mt-xl-n5, .my-xl-n5 {
        margin-top: -3rem!important;
        }
        .mr-xl-n5, .mx-xl-n5 {
        margin-right: -3rem!important;
        }
        .mb-xl-n5, .my-xl-n5 {
        margin-bottom: -3rem!important;
        }
        .ml-xl-n5, .mx-xl-n5 {
        margin-left: -3rem!important;
        }
        .m-xl-auto {
        margin: auto!important;
        }
        .mt-xl-auto, .my-xl-auto {
        margin-top: auto!important;
        }
        .mr-xl-auto, .mx-xl-auto {
        margin-right: auto!important;
        }
        .mb-xl-auto, .my-xl-auto {
        margin-bottom: auto!important;
        }
        .ml-xl-auto, .mx-xl-auto {
        margin-left: auto!important;
        }
        }.text-monospace {
        font-family: SFMono-Regular, Menlo, Monaco, Consolas, liberation mono, courier new, monospace;
        }
        .text-justify {
        text-align: justify!important;
        }
        .text-wrap {
        white-space: normal!important;
        }
        .text-nowrap {
        white-space: nowrap!important;
        }
        .text-truncate {
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
        }
        .text-left {
        text-align: left!important;
        }
        .text-right {
        text-align: right!important;
        }
        .text-center {
        text-align: center!important;
        }
        @media(min-width:576px) {
        .text-sm-left {
        text-align: left!important;
        }
        .text-sm-right {
        text-align: right!important;
        }
        .text-sm-center {
        text-align: center!important;
        }
        }@media(min-width:768px) {
        .text-md-left {
        text-align: left!important;
        }
        .text-md-right {
        text-align: right!important;
        }
        .text-md-center {
        text-align: center!important;
        }
        }@media(min-width:992px) {
        .text-lg-left {
        text-align: left!important;
        }
        .text-lg-right {
        text-align: right!important;
        }
        .text-lg-center {
        text-align: center!important;
        }
        }@media(min-width:1200px) {
        .text-xl-left {
        text-align: left!important;
        }
        .text-xl-right {
        text-align: right!important;
        }
        .text-xl-center {
        text-align: center!important;
        }
        }.text-lowercase {
        text-transform: lowercase!important;
        }
        .text-uppercase {
        text-transform: uppercase!important;
        }
        .text-capitalize {
        text-transform: capitalize!important;
        }
        .font-weight-light {
        font-weight: 300!important;
        }
        .font-weight-lighter {
        font-weight: lighter!important;
        }
        .font-weight-normal {
        font-weight: 400!important;
        }
        .font-weight-bold {
        font-weight: 700!important;
        }
        .font-weight-bolder {
        font-weight: bolder!important;
        }
        .font-italic {
        font-style: italic!important;
        }
        .text-white {
        color: #fff!important;
        }
        .text-primary {
        color: #1a75e8!important;
        }
        a.text-primary:hover, a.text-primary:focus {
        color: #1152a5!important;
        }
        .text-secondary {
        color: #6c757d!important;
        }
        a.text-secondary:hover, a.text-secondary:focus {
        color: #494f54!important;
        }
        .text-success {
        color: #44eb5a!important;
        }
        a.text-success:hover, a.text-success:focus {
        color: #16cd2e!important;
        }
        .text-info {
        color: #17a2b8!important;
        }
        a.text-info:hover, a.text-info:focus {
        color: #0f6674!important;
        }
        .text-warning {
        color: #ffc107!important;
        }
        a.text-warning:hover, a.text-warning:focus {
        color: #ba8b00!important;
        }
        .text-danger {
        color: #e9241d!important;
        }
        a.text-danger:hover, a.text-danger:focus {
        color: #a91610!important;
        }
        .text-light {
        color: #f8f9fa!important;
        }
        a.text-light:hover, a.text-light:focus {
        color: #cbd3da!important;
        }
        .text-dark {
        color: #343a40!important;
        }
        a.text-dark:hover, a.text-dark:focus {
        color: #121416!important;
        }
        .text-body {
        color: #212529!important;
        }
        .text-muted {
        color: #6c757d!important;
        }
        .text-black-50 {
        color: rgba(0, 0, 0, .5)!important;
        }
        .text-white-50 {
        color: rgba(255, 255, 255, .5)!important;
        }
        .text-hide {
        font: 0/0 a;
        color: transparent;
        text-shadow: none;
        background-color: transparent;
        border: 0;
        }
        
        
        
        
        
        label 
        {
        font-size: 14px;
        line-height: 22px;
        width: 100%;
        color: #777;
        }
        .form-control {
        height: 36px;
        border: 1px solid #ccc;
        padding: 5px 12px;
        border-radius: 6px;
        font-size: 14px;
        }
        .form-control::-moz-placeholder {
        color: #d8d8d8;
        }
        .form-control::-webkit-input-placeholder {
        color: #d8d8d8;
        }
        .form-control:-ms-input-placeholder {
        color: #d8d8d8;
        }
        .form-control::placeholder {
        color: #d8d8d8;
        }
        .form-control:focus {
        border-color: #999;
        outline: none;
        box-shadow: none;
        }
        .form-control.borderless {
        border: none;
        border-radius: 0;
        }
        
        .select-wrap {
        position: relative;
        }
        .select-wrap::after {
        content: "";
        position: absolute;
        right: 10px;
        top: 50%;
        margin-top: 1px;
        -webkit-transform: translate(0, -50%);
        -moz-transform: translate(0, -50%);
        -ms-transform: translate(0, -50%);
        -o-transform: translate(0, -50%);
        transform: translate(0, -50%);
        border-top: 5px solid #333;
        border-left: 5px solid transparent;
        border-right: 5px solid transparent;
        }
        
        
        
        
        
        .registration {
        background: #fff;
        width: 100%;
        float: left;
        padding: 50px 0;
        }
        @media(max-width:767.98px) {
        .registration {
        padding: 40px 0;
        }
        }@media(max-width:767.98px) {
        .registration .top-head h1 {
        font-size: 24px;
        }
        }.registration .top-head p {
        margin: 0 auto 20px;
        }
        .registration .top-head p span {
        font-weight: 500;
        color: #26bd68;
        }
        .registration .top-head p.disc {
        max-width: 370px;
        }
        @media(max-width:991.98px) {
        .registration .side-img {
        display: none;
        }
        }
        }.form-reg .shadow::before {
        content: "";
        position: absolute;
        left: 18px;
        top: 35px;
        right: 18px;
        bottom: 18px;
        background: #066759;
        -webkit-filter: blur(19px);
        -moz-filter: blur(19px);
        -ms-filter: blur(19px);
        -o-filter: blur(19px);
        filter: blur(19px);
        z-index: 1;
        border-radius: 20px;
        }
        .form-reg .content
        {
        /*border-radius: 20px;*/
        /*padding: 35px;*/
        /*z-index: 2;*/
        
        border-radius: 20px;
        padding: 35px;
        padding-bottom: 1px !important;
        padding-top: 10px !important;
        z-index: 2;
        }
        
        @media(max-width:767.98px) 
        {
        .form-reg .content 
        {
        padding: 20px;
        }
        }@media(max-width:767.98px) {
        .form-reg .custom-control-inline {
        width: 100%}
        }.form-reg .button-col .button {
        width: 150px;
        }
        @media(max-width:767.98px) {
        .form-reg .button-col .button {
        width: 100px;
        }
        
        
        </style>

</body>

<script type="text/javascript">
   $(document).ready(function () {
    $("#country").change(function () {
        var country = $('#country').val();
        console.log('Selected Country:', country);

        if (country != '') {
            $("#state").empty();
            $("#state").append('<option value="">-Select-</option>');

            $.ajax({
                url: "<?= site_url() ?>/user/GetStates_gotonikah",
                data: { country: country },
                type: "POST",
                success: function (data) {
                    console.log('Received States:', data);
                    $("#state").html(data);
                }
            });
        }
    });

    $("#state").change(function () {
        var state = $('#state').val();
        console.log('Selected State:', state);

        if (state != '') {
            $("#home_district").empty();
            $("#home_district").append('<option value="">-Select-</option>');

            $.ajax({
                url: "<?= site_url() ?>/user/GetDistrict2",
                data: { state: state },
                type: "POST",
                success: function (data) {
                    console.log('Received Districts:', data);
                    $("#home_district").html(data);
                }
            });
        }
    });

    $("#home_district").change(function () {
        var home_district = $('#home_district').val();
        console.log('Selected District:',home_district);

        if (home_district != '') {
            $("#city").empty();
            $("#city").append('<option value="">-Select-</option>');

            $.ajax({
                url: "<?= site_url() ?>/user/GetCity",
                data: { home_district: home_district },
                type: "POST",
                success: function (data) {
                    console.log('Received Cities:', data);
                    $("#city").html(data);
                }
            });
        }
     });
   });  
 </script>


</html>


    
