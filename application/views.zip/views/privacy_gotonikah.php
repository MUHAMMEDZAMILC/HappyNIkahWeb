<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <title>Privacy and Policy of Goto Nikah Muslim Marriage Website | Kerala Nikah Matrimony</title>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    
       <meta name="viewport" content="width=device-width, initial-scale=1">
    
      <meta name="robots" content="noindex, nofollow">

   <meta name="description" content="This is a muslim marriage bureau in Kerala.This muslim community matrimony site
is one of the most popular marriage bureaus. Contact goto
nikah muslim community marriage site">

 <link rel="icon" type="image/png" sizes="32x32" href="favicon.ico">
 <link rel="icon" type="image/png" sizes="32x32" href="<?php echo base_url();?>/happyadmin/assets/images/gotonikh.jpg">

    <link rel="preconnect" href="https://fonts.googleapis.com">

    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

    <link href="https://fonts.googleapis.com/css2?family=Archivo:wght@300;400;500;600;700;900&family=Noto+Sans+Malayalam:wght@400;500;600&family=Poppins:wght@300;400;500;600;700;800;900&family=Roboto:wght@400;500&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="<?php echo base_url() ?>assets/css/bootstrap.min.css">

    <link rel="stylesheet" href="<?php echo base_url() ?>assets/css/owl.carousel.min.css">

    <link rel="stylesheet" href="<?php echo base_url() ?>assets/css/owl.theme.default.min.css">

    <link href="//netdna.bootstrapcdn.com/font-awesome/3.2.1/css/font-awesome.css" rel="stylesheet">

   <link rel="stylesheet" href="<?php echo base_url() ?>assets/css/style.css?v=<?= rand(10, 100); ?>">

    <!-- Global site tag (gtag.js) - Google Analytics -->

    <script async src="https://www.googletagmanager.com/gtag/js?id=G-X44BV75LEC"></script>
    
</head>

<body>
    
   
  <section id="header" style="background-color: white;padding: 0px 0;position: fixed;top: 0;left: 0;right: 0;z-index: 11;box-shadow: 1px 5px #8e8c8c1c;">

        <nav class="navbar navbar-expand-lg">

            <div class="container">

                <a class="navbar-brand" href="<?php echo site_url(); ?>">

                    <img src="<?php echo base_url() ?>happyadmin/assets/images/goto nikah logo.png" alt="Go to Nikah" class="gotoNikahlogo" style="width:150px !important;" height="auto">

             </a>


                 <div class="mob-login" id="moblogin">

                    <n class="already-member">Already a member?</n>

                    <button type="button" class="btn loginbtn" data-bs-toggle="modal" data-bs-target="#loginModal" id="logmob" 
                    style="background: #5ABA47;width: 90px;margin-left: 8px;padding: 2px 0px;color: #ffff;">Login</button>

                </div>
                
                
                <!--<n class="already-member">Already a member?</n><button type="button" class="btn loginbtn" data-bs-toggle="modal" data-bs-target="#loginModal">Login</button>-->

                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarGoToNikah" aria-controls="navbarGoToNikah" aria-expanded="false" aria-label="Toggle navigation">

                    <div class="hamburger" id="hamburger-1">

                           <span class="line" style="background-color:#000;"></span>

                        <span class="line" style="background-color:#000;"></span>

                        <span class="line" style="background-color:#000;"></span>

                    </div>

                </button>

                <div class="collapse navbar-collapse" id="navbarGoToNikah">
                    
                    
                

                    <ul class="navbar-nav mx-auto mb-2 mb-lg-0 mt-3 mt-lg-0">

                        <li class="nav-item">

                            <a class="nav-link active" aria-current="page" href="<?php echo site_url('user/gotonikah'); ?>">Home</a>

                        </li>

                        <li class="nav-item">

                            <a class="nav-link" href="<?php echo site_url('user/about_gotonikah'); ?>">About us</a>

                        </li>
                        
                         

                        <li class="nav-item">

                            <a class="nav-link" href="<?php echo site_url('user/download_gotonikah'); ?>">Download</a>

                        </li>

                        <li class="nav-item">

                            <a class="nav-link" href="<?php echo site_url('user/contactus_gotonikah'); ?>">Contact</a>

                        </li>
                        
                       
                

                    </ul>
                    
                     <div class="d-flex" style="margin-left: 0px;">
                    <a href="javascript:void(0)" style="margin-top: -84px;" id="headicon">
                        <img src="<?php echo base_url() ?>assets/images/appleStoreF.png" alt="appleStore" id="apple" width="auto" height="auto" style="width: 90px;
    margin-bottom: -5px;" class="storeIcon me-3">
                    </a>
                    <a target="_blank" href="https://play.google.com/store/apps/details?id=com.sysol.goto_nikah" style="margin-top: -84px;">
                        <img src="<?php echo base_url() ?>assets/images/playStoreF.png" alt="playStore" width="auto"  style="width:90px;"   height="auto" class="storeIcon">
                    </a>
                </div>

                    <div class="web-login">

                        <n class="already-member" style="color:#000;">Already a member?</n>

                        <button type="button" class="btn loginbtn" data-bs-toggle="modal" data-bs-target="#loginModal" style="background: #5ABA47;width: 90px;margin-left: 8px;
    padding: 2px 0px;color: #ffff;">Login</button>

                    </div>

                    <!--<ul class="d-flex logList align-items-center mb-3 mb-lg-0">-->

                    <!--    <li>Already Member</li>-->

                    <!--    <li>-->

                    <!--        <button type="button" class="btn" data-bs-toggle="modal" data-bs-target="#loginModal">Login</button>-->

                    <!--    </li>-->

                    <!--</ul>-->



                </div>

            </div>

        </nav>

    </section> 
    
    
    <style type="text/css">
    
     #moblogin
        {
            visibility:hidden;
        }
        

        .validationclass 
        {
        
        color: red;
        
        font-size: 12px;
        
        padding: 5px 2px;
        
        }
        
        .otpInputs 
        {
        
        display: flex;
        
        flex-direction: row;
        
        flex-wrap: wrap;
        
        align-content: space-around;
        
        justify-content: space-evenly;
        
        }
        
        .errorotp 
        {
        
        text-align: center;
        
        color: red;
        
        background: #ff00000f;
        
        padding: 5px;
        
        }
        
        .already-member
        {
        
        float: left;
        
        width: 89px;
        
        font-size: 10px;
        
        color: white;
        
        padding-top: 7px;
        
        }
        .loginbtn
        {
        
        background: #fdfdfd;
        
        width: 90px;
        
        margin-left: 8px;
        
        padding: 2px 0px;
        
       }
        #banner .overlay 
        {
        
        background-color: rgb(253 232 232 / 0%);
        
        }
        
        #more
        {
        display: none;
        
        }
        
        #banner .bannerPara 
        {
        background: #ffffff38;
        
        padding: 15px 4px;
        
        }
        
        @media only screen and (max-width: 600px)
        {
        .already-member 
        {
        
        float: left;
        
        width: 89px;
        
        font-size: 10px;
        
        color: white;
        
        }
        
        .loginbtn 
        {
            
        background: #fdfdfd;
        
        width: 60px;
        
        margin-left: 8px;
        
        padding: 2px 0px;
        
        font-size: 12px;
        
        }
        }
        
        
        @media only screen and (max-width: 767px)
        {
        div#member
        {
        visibility:visible !important;
        }
        }
        
        @media (min-width: 280px) and (max-width: 991px)
        {
          #utilityPage .termPrivPara 
          {
            margin-right:20px !important;
            margin-left:20px !important;
          }
        #utilityPage .headBox h2
        {
        font-size:21px !important;
        }
        h6#notice
        {
            margin-left:20px;
        }
        
        #header
        {
        background-color: #ff5b85;
        padding: 30px 0;
        }
        #header .gotoNikahlogo 
        {
        
        width:70px !important;
        }
        .already-member {
        /*width: 320px;*/
        /*font-size: 29px;*/
        
        color: #fff !important;
        width: 100px;
        float: left;
    
        }
        
        #header .nav-link
        {
            /*font-size:30px !important;*/
        font-size:14px !important;
        }
        
        #header .navbar-toggler
        {
        /*padding:56px !important;*/
        margin-right: -2px;
        }
        }
        
        @media (min-width: 280px) and (max-width: 991px)
        { 
        a#headicon
        {
        margin-left:130px;
        }
        #header 
        {
        background-color: #ff5b85;
        padding: 0px 0;
        position: absolute;
        }
        
        img#apple
        {
        margin-left: 0px !important;
        }
        
        .agereq {
        color: red;
        font-size: 12px;
        margin-left: 0px !important;
        
        }
        h2.pOne
        {
        color: #ff5b85 !important;
        }
        
        #homeback
        {
        background-color: #fff !important;
        }
        
        p.bannerPara.mb-4.mb-md-0.pe-md-4 
        {
        display: none;
        }
        
        .form-control
        {
        width: 100% !important;
        }
        
        h3.hTwo {
        display: none;
        }
        
        label#ml
        {
        margin-left: 12px !important;
        margin-top:-12px;
        }
        
        input#name
        {
        margin-top: 56px !important;
        }
        
        input#male
        {
        /*margin-left: -4px !important;*/
        
        margin-top: -6px;
        margin-left: -6px !important;
        }
        label.form-check-label
        {
        /*margin-left: 15px !important; */
        margin-left: 0px !important; 
        }
        .vl
        {
        margin-left: 70px !important;
        
        }
        input#female {
        margin-left: 80px !important;
        }
        label#fml
        {
        margin-left: 98px !important;   
        }
        .v2{
        
        border-left: 0px solid #ff5b85 !important;
        }
        img#ml {
        margin-left: 42px !important;
        }
        img#fl {
        margin-left: 140px !important;
        }
        select#user_age
        {
        margin-left: -110px !important;   
        }
        
        #ctphone
        {
        margin-left:-3px !important;
        }
        select#countryCode
        {
        
        /*margin-left: -13px !important;  */
        margin-left: -7px !important;  
        }
        
        input#phone 
        {
        margin-left: -10px !important;
        width: 112% !important;
        /*margin-top: 13px;*/
        /*margin-left: -13px !important;  */
        }
        .regsub
        {
        margin-left:82px !important;
        }
        
        /*html {*/
        /*overflow-y: hidden;*/
        /*overflow-x: hidden;*/
        /*}*/
        
        /*body*/
        /*{*/
        /*overflow-y: hidden;*/
        /*overflow-x: hidden;  */
        /*}*/
        
        
        .subHead {
        font-size: 24px;
        margin-bottom: 16px;
        margin-top: 0px;
        
        }
        
        img#play
        {
        width: 100% !important;
        position: absolute;
        left: 0px !important;
        top: -540px !important;
        z-index: 1;
        }  
        
        .search
        {
        margin-top:170px;
        }
        
        
        h2.subHead1.mb-4 {
        font-size: 30px !important;
        }
        
        #homeDownload .pOne {
        font-size: 18px;
        }
        #homeDownload .pTwo {
        font-size: 18px;
        }
        #homeDownload .storeIcon {
        height: 45px !important;
        }
        
        .lPull{
        display:none;
        }
        
        .search
        {
        width: unset;
        margin-left: unset;
        }
        
        
        .mobText.mb-0 
        {
        font-size: 18px !important;
        }
        #homeVid
        {
        display:none;
        }
        #homeContact 
        {
        padding: 10px 0;
        }
        
        #moblogin
        
        {
        visibility:visible;
        }
        .already-member
        {
        color: #fff !important;
        width:100px;
        }
        
        button#logmob
        {
        visibility: visible !important;
        }
        .web-login
        {
        visibility: hidden !important;
        }
        
        p#txt
        {
        font-size:16px !important;
        }
        p#mob
        {
        font-size:16px !important;
        }
        p#mail_happy
        {
        font-size:17px !important;  
        }
        
        p#phone_val
        {
        margin-left: -7px !important;
        }
        
       }
       #header .nav-link
        {
            color:#000 !important;
        }
        
         #moblogin {
        margin-left: -105px;
        visibility: hidden;
        }
    </style>
    <section id="utilityPage">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="headBox" style="background: transparent linear-gradient(90deg, #1B3F1C 0%, #5ABA47 100%) 0% 0% no-repeat padding-box;">
                        <h2>Privacy and Policy</h2><hr><h6 style="color: white;">Privacy Statement of gotonikah.com </h6>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-12 col-md-10 mx-auto">
                    <p class="termPrivPara" align="justify">
                    
                     
                    Gotonikah.com is an online matrimonial website endeavouring constantly to provide you with quality matrimonial services. 
                    This privacy statement is common to all Gotonikah.com customers. Since we are strongly committed to your right to privacy, 
                    we have drawn out a privacy statement with regard to the information we collect from you.</p>
                    <p class="termPrivPara" align="justify">
                To register on the website you will be required to provide certain personal information. 
                This information includes (but is not limited to) data that specifically identifies an individual, such as a user name, name, address, 
                telephone number, e-mail address, religion, caste, gender, photos, employment details, income details, family background, physical and health data etc. 
        Please refer to FAQ section to identify the information that will be available to all Users of the Website and that which will be available only to those registered with our Website.
                   

                    </p>
                    <p class="termPrivPara mb-5" align="justify">
                    By using the services you acknowledge that: (a) we cannot ensure the security privacy of information you provide through the Internet and your email messages, and you release us from any and all liability in connection with the use of such information by other parties; (b) we are not responsible for, and cannot control, the use by others of any information which you provide to them and you should use caution in selecting the personal information you provide to others through the Service; and (c) we cannot assume any responsibility for the content of messages sent by other users of the Service, and you release us from any and all liability in connection with the contents of any communications you may receive from other users. We cannot guarantee, and assume no responsibility for verifying, the accuracy of the information provided by other users of the Service regarding particulars of status, age, income of other members. Your membership is only for personal use. It is not to be assigned, transferred or licensed so as to be used by any other person/entity.
                    

                    </p>
                    <p class="termPrivPara" align="justify">
                    The website uses cookies to track usage of the path of a user, to collect site statistical information and improve your customer experience. Since most web browsers automatically accept cookies, you can edit your browser options to block them if you does not want the website to use cookies to track usage of the path. We offer you choices when we ask for personal information, whenever reasonably possible. You may decline to provide personal information to us and/or refuse cookies in your browser, although please be aware that some of our features or services may not function properly as a result. You will have access to your personal information posted on our website and you may edit, delete or modify the same from time to time.
                    

                    </p>

                    <p class="termPrivPara" align="justify">
                    Our servers may also automatically collect information about your computer when you visit the website, including but not limited to the type of browser software and version you use, the operating system and platform you are running, the website that referred you to us, your IP or internet protocol address used to connect your computer to the Internet, average time spent on our site, pages viewed, information searched for, access times, “click stream data” and other relevant information about your online experience.
                    </p>


                    <p class="termPrivPara" align="justify">
                    By using the Gotonikah.com, you agree to receive certain specific email from the website relating to your membership or any alerts of any activity on the site or those of content promotion on the site. Should you not want to receive such e-mail, you may at any time cancel your subscription to such e-mails by sending a mail with the request for the same to in <a href="mailto:gotonikah@gmail.com.">gotonikah@gmail.com.</a>

                    </p>
                    <p class="termPrivPara" align="justify">
                    You hereby confirm that as on the date of your registration with the website, you have not registered yourselves on the Do Not Disturb (DND) subscriber list with any telecom operator / authority. In the event, you register yourselves as a Do Not Disturb (DND) subscriber; you hereby confirm that you do not have any objection to receiving messages (promotional or otherwise) from the website.
                    </p>

                    <p class="termPrivPara" align="justify">
                    User understands that the Institution does not guarantee any confidentiality with respect to your content (including any personal information) other than as specified in the Privacy and Security Policy. All visitors to our site may browse the site, search the ads and view any articles or features our site has to offer without entering any personal information or paying money. As a paid member of this site, you have the privilege to contact twenty of profiles in a single day. If you want to contact more profiles than the specified limit in a single day, he/she can do so after the completion of 12 hours of their login time.

                    </p>


                    <p class="termPrivPara" align="justify"><h6 id="notice"><b>Notice</b></h6> 
                  <p class="termPrivPara" align="justify">We may change this Privacy Policy from time to time based on your comments or as a result of a change of policy in our institution.
                    If you have any questions regarding our Privacy Statement, please write to <a href="mailto:gotonikah@gmail.com" >gotonikah@gmail.com</a></p></p>
                    













                    <!--                    <h2 class="subHead">Why Happy Nikkah</h2>
                    <p class="termPrivPara">Sed ut perspiciatis unde 
omnis iste natus error sit voluptatem accusantium doloremque laudantium,
 totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi
 architecto beatae vitae dicta sunt explicabo.</p>
                    <p class="termPrivPara"> qui dolorem ipsum quia 
dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius 
modi tempora incidunt ut labore et dolore magnam aliquam quaerat 
voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam 
corporis suscipit laboriosam,</p>
                    <p class="termPrivPara">Lorem ipsum, dolor sit amet,
 consectetur adipisicing elit. Quo est, quod laudantium totam 
consequatur alias fuga facere rerum earum magni labore sit veritatis? 
Distinctio dolor blanditiis dolore a incidunt nobis! Lorem ipsum, dolor 
sit amet, consectetur adipisicing elit. Quo est, quod laudantium totam 
consequatur alias fuga facere rerum earum magni labore sit veritatis? 
Distinctio dolor blanditiis dolore a incidunt nobis!
                    Lorem ipsum, dolor sit amet, consectetur adipisicing
 elit. Quo est, quod laudantium totam consequatur alias fuga facere 
rerum earum magni labore sit veritatis? Distinctio dolor blanditiis 
dolore a incidunt nobis!
                    Lorem ipsum, dolor sit amet, consectetur adipisicing
 elit. Quo est, quod laudantium totam consequatur alias fuga facere 
rerum earum magni labore sit veritatis? Distinctio dolor blanditiis 
dolore a incidunt nobis! Lorem ipsum, dolor sit amet, consectetur 
adipisicing elit. Quo est, quod laudantium totam consequatur alias fuga 
facere rerum earum magni labore sit veritatis? Distinctio dolor 
blanditiis dolore a incidunt nobis! Lorem ipsum, dolor sit amet, 
consectetur adipisicing elit. Quo est, quod laudantium totam consequatur
 alias fuga facere rerum earum magni labore sit veritatis? Distinctio 
dolor blanditiis dolore a incidunt nobis!
                    Lorem ipsum, dolor sit amet, consectetur adipisicing
 elit. Quo est, quod laudantium totam consequatur alias fuga facere 
rerum earum magni labore sit veritatis? Distinctio dolor blanditiis 
dolore a incidunt nobis!
                    Lorem ipsum, dolor sit amet, consectetur adipisicing
 elit. Quo est, quod laudantium totam consequatur alias fuga facere 
rerum earum magni labore sit veritatis? Distinctio dolor blanditiis 
dolore a incidunt nobis!</p>-->
                </div>
            </div>
        </div>
    </section>
    <section id="homeAbout" style="background-color: #fff;">
        <div class="container">
            <div class="row">
                <div class="col-12 col-md-8 mx-auto text-center">
                    <h2 class="subHead">Get ready <span style="color:#5ABA47;">with us</span></h2>
                    <p class="para1 mb-5">Goto Nikah is India’s most trusted and user friendly online matrimony portal for Muslims.
                        Goto Nikah has helped thousands of Muslim singles to find their perfect soul mate.</p>
                </div>
            </div>
            <div class="row my-5">
                <div class="col-12 col-sm-6 col-lg-3 text-center mb-4 mb-lg-0">
                    <img src="<?php echo base_url(); ?>assets/images/Trusted_goto.png" alt="Trusted Matrimonial Service" class="readyIcon" width="auto" height="auto">
                    <h3>No.1 &amp; Trusted<br>Matrimonial Service</h3>
                    <p>Our largest number of profiles<br>increases your chances.</p>
                </div>
                <div class="col-12 col-sm-6 col-lg-3 text-center mb-4 mb-lg-0">
                    <img src="<?php echo base_url(); ?>assets/images/Charge_goto.png" alt="No Charge for Registration" class="readyIcon" width="auto" height="auto">
                    <h3>No Charge for<br>Registration</h3>
                    <p>Registering with us is completely<br>free and simple.</p>
                </div>
                <div class="col-12 col-sm-6 col-lg-3 text-center mb-4 mb-sm-0">
                    <img src="<?php echo base_url(); ?>assets/images/Validation_goto.png" alt="Manual Screening and Validation" class="readyIcon" width="auto" height="auto">
                    <h3>Manual Screening<br>and Validation</h3>
                    <p>Our experts manually screen<br>and validate each profile.</p>
                </div>
                <div class="col-12 col-sm-6 col-lg-3 text-center">
                    <img src="<?php echo base_url(); ?>assets/images/Security_goto.png" alt="Best Data Security and Privacy" class="readyIcon" width="auto" height="auto">
                    <h3>Best Data Security<br>and Privacy</h3>
                    <p>We follow best practices to<br>keep your data safe.</p>
                </div>
            </div>
        </div>
    </section>
    
    <!--<section id="homeDownload" class="downAbout">-->
    <!--    <div class="container">-->
    <!--        <div class="row">-->
    <!--            <div class="col-12 col-xxl-10 mx-auto">-->
    <!--                <div class="row">-->
    <!--                    <div class="col-12 col-md-7 col-xl-6">-->
    <!--                        <h2 class="subHead mb-4">Search Profiles<br><span>Anytime! Anywhere!!</span></h2>-->
    <!--                        <p class="pOne">Finding your perfect match has never been easier with the Goto Nikah application</p>-->
    <!--                        <p class="pTwo">Download now and communicate with muslim matches on-the-go!</p>-->
    <!--                        <div class="d-flex">-->
    <!--                            <a href="javascript:void(0)">-->
    <!--                                <img src="<?php echo base_url(); ?>assets/images/appleStore.png" alt="appleStore" class="storeIcon me-3" width="auto" height="auto">-->
    <!--                            </a>-->
    <!--                            <a href="https://play.google.com/store/apps/details?id=com.sysol.goto_nikah">-->
    <!--                                <img src="<?php echo base_url(); ?>assets/images/playStore.png" alt="playStore" class="storeIcon" width="auto" height="auto">-->
    <!--                            </a>-->
    <!--                        </div>-->
    <!--                    </div>-->
    <!--                    <div class="col-12 col-md-5 col-xl-6 text-center position-relative">-->
    <!--                        <img src="<?php echo base_url(); ?>assets/images/appMob1.png" alt="playStore" class="appIcon" width="auto" height="auto">-->
    <!--                    </div>-->
    <!--                </div>-->
    <!--            </div>-->
    <!--        </div>-->
    <!--    </div>-->
    <!--</section>-->
    
    
    
    <?php include('include/footer_gotonikah.php'); ?>


    <!-- login Modal -->
    <div class="modal fade" id="loginModal" tabindex="-1" aria-labelledby="loginModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg">
            <div class="modal-content">
                <div class="modal-body p-0">
                    <div class="row">
                        <div class="col-12 col-lg-6 d-none d-lg-flex align-items-stretch">
                            <div class="leftBox w-100">
                                <h2 class="modalHead mb-4" id="loginModalLabel">Search Profiles<br><span style="color:#5ABA47;">Anytime! Anywhere!!</span></h2>
                                <p class="lpone">Finding your perfect match has never been easier with the Gotonikah application</p>
                                <p class="lptwo">Download now and communicate with muslim matches on-the-go!</p>
                                <div class="d-flex justify-content-center">
                                    <a href="javascript:void(0)">
                                        <img src="<?php echo base_url(); ?>assets/images/appleStore.png" alt="appleStore" class="storeIcon me-3" width="auto" height="auto">
                                    </a>
                                    <a href="https://play.google.com/store/apps/details?id=com.sysol.goto_nikah">
                                        <img src="<?php echo base_url(); ?>assets/images/playStore.png" alt="playStore" class="storeIcon" width="auto" height="auto">
                                    </a>
                                </div>
                            </div>
                        </div>
                        <div class="col-12 col-lg-6 d-flex align-items-stretch">
                            <div class="rbox w-100">
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                <div class="d-flex justify-content-between mb-5">
                                    <h3 class="welcomeHead">Welcome Back!<br><span>Please Login</span></h3>
                                    <img src="<?php echo base_url(); ?>assets/images/logo.png" alt="Goto Nikah" class="llogo" width="auto" height="auto">
                                </div>
                                <div class="emailLogBox">
                                    <form class="customForm">
                                        <div class="mb-3">
                                            <input type="text" name="" class="form-control" placeholder="Username/email">
                                        </div>
                                        <div class="mb-3">
                                            <input type="password" name="" class="form-control" placeholder="Password">
                                        </div>
                                        <p class="note">By continuing, you agree to GotoNikah's <a href="#">Terms of Use</a> and <a href="<?php echo site_url('user/privacy_gotonikah'); ?>">Privacy Policy</a></p>
                                        <button type="button" class="btn cstmBtnColr w-100" onclick="window.location.href='home.html'">Login</button>
                                        <p class="orTxt">OR</p>
                                        <button type="button" class="btn w-100 mb-3 loginOtpBtn">OTP Login</button>
                                    </form>
                                </div>
                                <div class="otpLogBox" style="display:none;">
                                    <form class="customForm">
                                        <div class="mb-3">
                                            <input type="text" name="" class="form-control" placeholder="Mobile Number/Email">
                                        </div>
                                        <p class="note">By continuing, you agree to GotoNikah's <a href="#">Terms of Use</a> and <a href="<?php echo site_url('user/privacy_gotonikah'); ?>">Privacy Policy</a></p>
                                        <button type="button" class="btn cstmBtnColr sendOtp w-100">Send OTP</button>
                                        <p class="orTxt">OR</p>
                                        <button type="button" class="btn w-100 mb-3 loginEmailBtn">Email Login</button>
                                    </form>
                                </div>
                                <div class="otpsendBox" style="display:none;">
                                    <form class="customForm">
                                        <div class="mb-3">
                                            <label class="form-label">Enter Your OTP</label>
                                            <div class="otpInputs">
                                                <input type="text" class="form-control" maxlength="1">
                                                <input type="text" class="form-control" maxlength="1">
                                                <input type="text" class="form-control" maxlength="1">
                                                <input type="text" class="form-control" maxlength="1">
                                                <input type="text" class="form-control" maxlength="1">
                                                <input type="text" class="form-control" maxlength="1">
                                            </div>
                                        </div>
                                        <button type="button" class="btn cstmBtnColr w-100" onclick="window.location.href='home.html'">Submit</button>
                                        <p class="note text-center mb-1"><a href="javascript:void(0)">Send the Code Again</a></p>
                                        <p class="note text-center mb-4"><a href="javascript:void(0)">Change Mobile Number/Emial</a></p>
                                        <button type="button" class="btn w-100 mb-3 loginEmailBtn">Email Login</button>
                                    </form>
                                </div>
                                <div class="d-flex justify-content-between mb-3">
                                    <a href="javascript:void(0)" class="regWtFb">
                                        <img src="<?php echo base_url(); ?>assets/images/fb2.png" alt="facebook" width="auto" height="auto">
                                        <span>Facebook</span>
                                    </a>
                                    <a href="javascript:void(0)" class="regWtgoogle">
                                        <img src="<?php echo base_url(); ?>assets/images/google.png" alt="google" width="auto" height="auto">
                                        <span>Google</span>
                                    </a>
                                </div>
                                <p class="text-center newtoTxt">New to GotoNikah <a href="#">Register Now</a></p>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script type="text/javascript" src="<?php echo base_url(); ?>assets/js/jquery-3.6.0.min.js"></script>
    <script type="text/javascript" src="<?php echo base_url(); ?>assets/js/bootstrap.bundle.min.js"></script>

    <script src="<?php echo base_url(); ?>assets/js/owl.carousel.js"></script>

    <script type="text/javascript">
        $(document).ready(function() {
            // partner slider
            $(".owl-partner").owlCarousel({
                margin: 25,
                responsiveClass: true,
                nav: false,
                dots: false,
                autoplay: true,
                autoplayHoverPause: false,
                loop: true,
                responsive: {
                    0: {
                        items: 1.2,
                    },
                    576: {
                        items: 1.5,
                    },
                    768: {
                        items: 2.2,
                    },
                    992: {
                        items: 2.5,
                    },
                    1200: {
                        items: 3.2,
                    },
                    1400: {
                        items: 3.5,
                    }
                },
            });
            // partner slider end

            // burger menu
            $(".hamburger").click(function() {
                $(this).toggleClass("is-active");
                $('body').toggleClass("is-scroll-disabled");
            });
            // burger menu end

            // login with otp and email switch
            $(".loginOtpBtn").click(function() {
                $(".emailLogBox").hide();
                $(".otpLogBox").show();
            });
            $(".loginEmailBtn").click(function() {
                $(".otpLogBox").hide();
                $(".emailLogBox").show();
            });
            $(".sendOtp").click(function() {
                $(".otpLogBox").hide();
                $(".otpsendBox").show();
            });
        });
    </script>


</body>

</html>