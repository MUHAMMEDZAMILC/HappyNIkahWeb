<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <title>Terms and condition of Goto Nikah Muslim Marriage Website | Kerala Nikah Matrimony</title>
 
       <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />

    <meta name="viewport" content="width=device-width, initial-scale=1">
    
   
   <meta name="robots" content="noindex, nofollow">
   <meta name="description" content="This is a muslim marriage bureau in Kerala.This muslim community matrimony site
is one of the most popular marriage bureaus. Contact goto
nikah muslim community marriage site">

 <link rel="icon" type="image/png" sizes="32x32" href="favicon.ico">
 <link rel="icon" type="image/png" sizes="32x32" href="<?php echo base_url();?>/happyadmin/assets/images/gotonikh.jpg">

    <link rel="preconnect" href="https://fonts.googleapis.com">

    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

    <link href="https://fonts.googleapis.com/css2?family=Archivo:wght@300;400;500;600;700;900&family=Noto+Sans+Malayalam:wght@400;500;600&family=Poppins:wght@300;400;500;600;700;800;900&family=Roboto:wght@400;500&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="<?php echo base_url() ?>assets/css/bootstrap.min.css">

    <link rel="stylesheet" href="<?php echo base_url() ?>assets/css/owl.carousel.min.css">

    <link rel="stylesheet" href="<?php echo base_url() ?>assets/css/owl.theme.default.min.css">

    <link href="//netdna.bootstrapcdn.com/font-awesome/3.2.1/css/font-awesome.css" rel="stylesheet">

   <link rel="stylesheet" href="<?php echo base_url() ?>assets/css/style.css?v=<?= rand(10, 100); ?>">

    <!-- Global site tag (gtag.js) - Google Analytics -->

    <script async src="https://www.googletagmanager.com/gtag/js?id=G-X44BV75LEC"></script>
    
</head>

<body>
    
   
  <section id="header" style="background-color: white;padding: 0px 0;position: fixed;top: 0;left: 0;right: 0;z-index: 11;box-shadow: 1px 5px #8e8c8c1c;">

        <nav class="navbar navbar-expand-lg">

            <div class="container">

                <a class="navbar-brand" href="<?php echo site_url(); ?>">

                    <img src="<?php echo base_url() ?>happyadmin/assets/images/goto nikah logo.png" alt="Go to Nikah" class="gotoNikahlogo" style="width:150px !important;" height="auto">

             </a>


                 <div class="mob-login" id="moblogin">

                    <n class="already-member">Already a member?</n>

                    <button type="button" class="btn loginbtn" data-bs-toggle="modal" data-bs-target="#loginModal" id="logmob" 
                    style="background: #5ABA47;width: 90px;margin-left: 8px;padding: 2px 0px;color: #ffff;">Login</button>

                </div>
                
                
                <!--<n class="already-member">Already a member?</n><button type="button" class="btn loginbtn" data-bs-toggle="modal" data-bs-target="#loginModal">Login</button>-->

                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarGoToNikah" aria-controls="navbarGoToNikah" aria-expanded="false" aria-label="Toggle navigation">

                    <div class="hamburger" id="hamburger-1">

                           <span class="line" style="background-color:#000;"></span>

                        <span class="line" style="background-color:#000;"></span>

                        <span class="line" style="background-color:#000;"></span>

                    </div>

                </button>

                <div class="collapse navbar-collapse" id="navbarGoToNikah">
                    
                    
                

                    <ul class="navbar-nav mx-auto mb-2 mb-lg-0 mt-3 mt-lg-0">

                        <li class="nav-item">

                            <a class="nav-link active" aria-current="page" href="<?php echo site_url('user/gotonikah'); ?>">Home</a>

                        </li>

                        <li class="nav-item">

                            <a class="nav-link" href="<?php echo site_url('user/about_gotonikah'); ?>">About us</a>

                        </li>
                        
                         

                        <li class="nav-item">

                            <a class="nav-link" href="<?php echo site_url('user/download_gotonikah'); ?>">Download</a>

                        </li>

                        <li class="nav-item">

                            <a class="nav-link" href="<?php echo site_url('user/contactus_gotonikah'); ?>">Contact</a>

                        </li>
                        
                       
                

                    </ul>
                    
                     <div class="d-flex" style="margin-left: 0px;">
                    <a href="javascript:void(0)" style="margin-top: -84px;" id="headicon">
                        <img src="<?php echo base_url() ?>assets/images/appleStoreF.png" alt="appleStore" id="apple" width="auto" height="auto" style="width: 90px;
    margin-bottom: -5px;" class="storeIcon me-3">
                    </a>
                    <a target="_blank" href="https://play.google.com/store/apps/details?id=com.sysol.goto_nikah" style="margin-top: -84px;">
                        <img src="<?php echo base_url() ?>assets/images/playStoreF.png" alt="playStore" width="auto"  style="width:90px;"   height="auto" class="storeIcon">
                    </a>
                </div>

                    <div class="web-login">

                        <n class="already-member" style="color:#000;">Already a member?</n>

                        <button type="button" class="btn loginbtn" data-bs-toggle="modal" data-bs-target="#loginModal" style="background: #5ABA47;width: 90px;margin-left: 8px;
    padding: 2px 0px;color: #ffff;">Login</button>

                    </div>

                    <!--<ul class="d-flex logList align-items-center mb-3 mb-lg-0">-->

                    <!--    <li>Already Member</li>-->

                    <!--    <li>-->

                    <!--        <button type="button" class="btn" data-bs-toggle="modal" data-bs-target="#loginModal">Login</button>-->

                    <!--    </li>-->

                    <!--</ul>-->



                </div>

            </div>

        </nav>

    </section> 
    
    
   
     <style type="text/css">
    
     #moblogin
        {
            visibility:hidden;
        }
        

        .validationclass 
        {
        
        color: red;
        
        font-size: 12px;
        
        padding: 5px 2px;
        
        }
        
        .otpInputs 
        {
        
        display: flex;
        
        flex-direction: row;
        
        flex-wrap: wrap;
        
        align-content: space-around;
        
        justify-content: space-evenly;
        
        }
        
        .errorotp 
        {
        
        text-align: center;
        
        color: red;
        
        background: #ff00000f;
        
        padding: 5px;
        
        }
        
        .already-member
        {
        
        float: left;
        
        width: 89px;
        
        font-size: 10px;
        
        color: white;
        
        padding-top: 7px;
        
        }
        .loginbtn
        {
        
        background: #fdfdfd;
        
        width: 90px;
        
        margin-left: 8px;
        
        padding: 2px 0px;
        
       }
        #banner .overlay 
        {
        
        background-color: rgb(253 232 232 / 0%);
        
        }
        
        #more
        {
        display: none;
        
        }
        
        #banner .bannerPara 
        {
        background: #ffffff38;
        
        padding: 15px 4px;
        
        }
        
        @media only screen and (max-width: 600px)
        {
        .already-member 
        {
        
        float: left;
        
        width: 89px;
        
        font-size: 10px;
        
        color: white;
        
        }
        
        .loginbtn 
        {
            
        background: #fdfdfd;
        
        width: 60px;
        
        margin-left: 8px;
        
        padding: 2px 0px;
        
        font-size: 12px;
        
        }
        }
        
        
        @media only screen and (max-width: 767px)
        {
        div#member
        {
        visibility:visible !important;
        }
        }
        
        @media (min-width: 280px) and (max-width: 991px)
        {
        #header
        {
        background-color: #ff5b85;
        padding: 30px 0;
        }
        #header .gotoNikahlogo 
        {
        
        width:70px !important;
        }
        .already-member {
        /*width: 320px;*/
        /*font-size: 29px;*/
        
        color: #fff !important;
        width: 100px;
        float: left;
    
        }
        
        #header .nav-link
        {
            /*font-size:30px !important;*/
        font-size:14px !important;
        }
        
        #header .navbar-toggler
        {
        /*padding:56px !important;*/
        margin-right: -2px;
        }
        }
        
        @media (min-width: 280px) and (max-width: 991px)
        { 
            #utilityPage .headBox h2
            {
                font-size:21px !important;
            }
        a#headicon
        {
        margin-left:130px;
        }
        #header 
        {
        background-color: #ff5b85;
        padding: 0px 0;
        position: absolute;
        }
        
        img#apple
        {
        margin-left: 0px !important;
        }
        
        .agereq {
        color: red;
        font-size: 12px;
        margin-left: 0px !important;
        
        }
        h2.pOne
        {
        color: #ff5b85 !important;
        }
        
        #homeback
        {
        background-color: #fff !important;
        }
        
        p.bannerPara.mb-4.mb-md-0.pe-md-4 
        {
        display: none;
        }
        
        .form-control
        {
        width: 100% !important;
        }
        
        h3.hTwo {
        display: none;
        }
        
        label#ml
        {
        margin-left: 12px !important;
        margin-top:-12px;
        }
        
        input#name
        {
        margin-top: 56px !important;
        }
        
        input#male
        {
        /*margin-left: -4px !important;*/
        
        margin-top: -6px;
        margin-left: -6px !important;
        }
        label.form-check-label
        {
        /*margin-left: 15px !important; */
        margin-left: 0px !important; 
        }
        .vl
        {
        margin-left: 70px !important;
        
        }
        input#female {
        margin-left: 80px !important;
        }
        label#fml
        {
        margin-left: 98px !important;   
        }
        .v2{
        
        border-left: 0px solid #ff5b85 !important;
        }
        img#ml {
        margin-left: 42px !important;
        }
        img#fl {
        margin-left: 140px !important;
        }
        select#user_age
        {
        margin-left: -110px !important;   
        }
        
        #ctphone
        {
        margin-left:-3px !important;
        }
        select#countryCode
        {
        
        /*margin-left: -13px !important;  */
        margin-left: -7px !important;  
        }
        
        input#phone 
        {
        margin-left: -10px !important;
        width: 112% !important;
        /*margin-top: 13px;*/
        /*margin-left: -13px !important;  */
        }
        .regsub
        {
        margin-left:82px !important;
        }
        
        /*html {*/
        /*overflow-y: hidden;*/
        /*overflow-x: hidden;*/
        /*}*/
        
        /*body*/
        /*{*/
        /*overflow-y: hidden;*/
        /*overflow-x: hidden;  */
        /*}*/
        
        
        .subHead {
        font-size: 24px;
        margin-bottom: 16px;
        margin-top: 50px;
        
        }
        
        img#play
        {
        width: 100% !important;
        position: absolute;
        left: 0px !important;
        top: -540px !important;
        z-index: 1;
        }  
        
        .search
        {
        margin-top:170px;
        }
        
        
        h2.subHead1.mb-4 {
        font-size: 30px !important;
        }
        
        #homeDownload .pOne {
        font-size: 18px;
        }
        #homeDownload .pTwo {
        font-size: 18px;
        }
        #homeDownload .storeIcon {
        height: 45px !important;
        }
        
        .lPull{
        display:none;
        }
        
        .search
        {
        width: unset;
        margin-left: unset;
        }
        
        
        .mobText.mb-0 
        {
        font-size: 18px !important;
        }
        #homeVid
        {
        display:none;
        }
        #homeContact 
        {
        padding: 10px 0;
        }
        
        #moblogin
        
        {
        visibility:visible;
        }
        .already-member
        {
        color: #fff !important;
        width:100px;
        }
        
        button#logmob
        {
        visibility: visible !important;
        }
        .web-login
        {
        visibility: hidden !important;
        }
        
        p#txt
        {
        font-size:16px !important;
        }
        p#mob
        {
        font-size:16px !important;
        }
        p#mail_happy
        {
        font-size:17px !important;  
        }
        
        p#phone_val
        {
        margin-left: -7px !important;
        }
        
       }
       #header .nav-link
        {
            color:#000 !important;
        }
        
         #moblogin {
        margin-left: -105px;
        visibility: hidden;
        }
    </style>
    <section id="utilityPage">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="headBox" style="background: transparent linear-gradient(90deg, #1B3F1C 0%, #5ABA47 100%) 0% 0% no-repeat padding-box;">
                        <h2>Terms and Conditions</h2>
                    </div>
                </div>
            </div>
            
            <div class="container-fluid">
            <div class="row">
                <div class="col-12 col-md-10 mx-auto">
                    <p class="termPrivPara" align="justify">
                    <h6><b>Welcome to gotonikah.com</b></h6>

                    <p style="text-align:justify">Please read the terms of use for this website carefully. In accordance with this terms and conditions, the users of gotonikah.com are provided with limited 
                    license to use the service and content of this website. By signing up the service, you give your acceptance to be bound by the Terms and conditions 
                    (herein referred to as “Agreement”). To become a member of this website and to be able to communicate with fellow members, you must register as a member and 
                    follow the instructions given during the Registration process. This Agreement outlines the terms that you are subjected to as a member of this website.
                    The Agreement may be revised from time to time at the sole discretion of gotonikah.com and will be intimated to you. Pursuant to such changes, 
                    if you continue to use the site then it will be constituted as your acceptance for the changes.</p>
                    <p class="termPrivPars" align="justify">
                    <h6><b>Criteria of Use</b></h6>

                    <p style="text-align:justify">You are at least 18 or 18+ years of age. The membership of those users will be declined whose eligibility does not match the criteria.
                    Using this site will determine that you possess the right, authority and competence to sign this Agreement and to be bound by the terms of use of this Agreement.

                    This site does not encourage and/or promote illegitimate sexual relations or affairs outside marriage.
                    If any member is found to be using this site as a means of promoting or indulging or engaging in any illegitimate sexual relations or affairs 
                    outside marriage or if gotonikah.com becomes aware of such activities then the membership of the particular user will be terminated without any refund.
                    gotonikah.com is not bound by any liability towards such individual. The binding and final termination will be the sole discretion of gotonikah.com</p>
                    <p class="termPrivPara mb-5" align="justify">
                    <h6><b>Terms of Use</b></h6>

                    <p style="text-align:justify">This Agreement will come into effect once you have registered as a member and will remain in full force as and when you continue to use the Site.
                    If you wish to terminate your membership for any reason and at any time, you may do so by informing gotonikah.com in writing. 
                    In the event of gotonikah.com terminating your membership or you terminate your membership, 
                    you will not be entitled any refund irrespective of whether you have any unutilized subscription fees,
                    gotonikah.com reserves the sole right to terminate your access to the Site and/or your membership for any reason.
                    You will be intimated of the same via email at the email address (or any other email address that you may later provide) you provided in your application for 
                    membership to gotonikah.com.In the event of gotonikah.com terminating your membership for breaching the Agreement, you will not be entitled to any refund.
                    Even after the termination of the Agreement, provisions including sections 4,5,7,9 -12 of this Agreement will remain in effect.</p>
                    <p class="termPrivPara" align="justify">
                    <h6><b>Non-Commercial Use by Members</b></h6>

                        <p style="text-align:justify">The service of this website is for the personal use of individual members only. Members of gotonikah.com will not use the services of the 
                    website for any commercial purpose including link building of any kind irrespective of whether it may be deemed competitive to gotonikah.com or otherwise. 
                    The membership of this website is restricted to individuals only therefore, non-individual entity may not become members of gotonikah.com,
                    Appropriate legal action will be taken against illegitimate and/or unauthorized use of the Site, which may include unauthorized framing of or linking to the Site.</p>

                    <p class="termPrivPara" align="justify">
                    <h6><b>Other Terms of Use</b></h6>1. Members of the website will not engage in any advertising or solicitation of selling or buying any services or products through this website.<br><br>

                    2. You will not send any chain letters or spam the email of gotonikah.com members.<br><br>

                    3. Using any information obtained from this service for the purpose of harassing, abusing or harming a fellow member will be considered as the violation of this agreement.<br><br>

                    4. Gotonikah.com has the sole right to restrict the number of communications, emails, of all the members in order to protect its members from any sort of abuse or misuse.<br><br>

                    5. Sending obscene, lewd, licentious, defamatory messages that promote hatred and/or are racial or abusive in any manner will be deemed as a breach of this agreement and shall be entitled to termination of your membership.<br><br>

                    6. Gotonikah.com at its own discretion reserves the right to screen messages that are sent to other Member(s). We also regulate the number of your chat sessions.<br><br>

                    7. Use of Bots, EXE's, CGI or any other programs/scripts to view content on or communicate/contact/respond/interact with gotonikah.com and/or its Members is restricted.</p>


                    <p class="termPrivPara" align="justify">
                    <h6><b>Propriety Rights</b></h6>
                    <p style="text-align:justify">The propriety rights of this website are owned by gotonikah.com and retain all intellectual property without any limitation. 
                    The proprietary information shall not be copied, modified, published, transmitted, distributes, displayed, sold or performs in any form.
                    Gotonikah.com website possesses copyrighted material, trademarks, and other proprietary information Ownership of content posted on the Site</p>
                    <p class="termPrivPara" align="justify">
                    <h6><b>You agree that</b></h6>
                    <p style="text-align:justify"> 
                    1) Gotonikah.com owns all the lawful, legal and non-objectionable messages, content and/or other information, content or material that are posted on the forum boards.<br><br>

                    2)  All such information, content and/or material posted on the forum boards may be scrutinized by gotonikah.com and have the sole right at 
                    its own discretion to remove, edit and/or display such information, material and/or content, messages, photos or profiles which might be deemed as offensive, illegitimate,
                    derogatory, obscene, libellous, or that might violate the rights, harm, or intimidate the safety of other members. 
                    It will be considered as a breach of this agreement and may be liable to termination.<br><br>

                    3) The Content that are published or displayed on the Site by you will be at your sole discretion.<br><br>

                    4) Gotonikah.com reserves the right to verify the authenticity of Content posted on the Site and may ask you to provide any documentary or other form of evidence supporting the Content you post on the Site. <br><br>

                    5) In the event of your failure to produce such evidence, or if the evidence is not sufficient to support and justify your claim then gotonikah.com may, in its sole discretion, terminate your Membership without any refund. <br><br>

                    6) You understand that by posting content to any public forum, you automatically grant gotonikah.com and other members the license to utilize, reproduce, exhibit, distribute and perform the information and content in any manner.<br><br>
                    </p>
                    </p>

                    <p class="termPrivPara" align="justify">
                    <h6><b>Content prohibited on the Site </b></h6>Any member violating the following provision will be subjected to appropriate legal action in the sole discretion of gotonikah.com. 
                    The violator will be removed and membership will be terminated from the website without refund. It includes (but is not limited to),<br><br>
                    1) New profiles will be verified for its authenticity by way of gotonikah.com and will be immediately activated after receiving quality declaration.<br><br>

                    2) In the event of unacceptable profile contents or if the profile contains violent language or unsolicited material then gotonikah.com reserves the sole right to discontinue, deactivate, or terminate the concerned profile.<br><br>

                    3) Only paid customer will have access to contact information of other members.<br><br>

                    4) The liability of your connections with other members through this Service solely lies with you. Gotonikah.com does not have any obligation to supervise the disputes between its members.<br><br>

                    5) Free membership may be discontinued by gotonikah.com as and when it is deemed to be of no more relevance.<br><br>

                    6) Gotonikah.com does not claim any responsibility for the misuse of this service. <br><br>

                    7) All the members are required to submit their profile with the necessary facts required for establishing a matrimonial alliance. Gotonikah.com will not be responsible for any loss or damage caused for concealing facts relevant to marriage.<br><br>

                    8) Gotonikah.com does not guarantee the legitimacy and validity of the information provided by the members. This may include information related religion, caste or creed or any other personal information.<br><br>

                    9) Gotonikah.com will not be responsible for any delays caused in posting information due to technical faults.<br><br>

                    10) For loss or damage due to the discontinuation of the service or for any damage caused due to accessing other member’s profile, gotonikah.com is not responsible.<br><br>

                    11) Gotonikah.com does not provide any guarantee that you as an applicant will receive responses and is not liable to any refunds or credits.<br><br>

                    12) The users will not promote any an illegal or unauthorized copy of another person's copyrighted work which may include pirated computer programs, providing information to circumvent manufacture-installed copy-protect devices, or pirated music.<br><br>

                    13) The users will not send any information with restricted contents or password only access pages, or hidden pages or images.<br><br>

                    14) The users will not encourage extra marital affairs, exploitation of people under 18 years of age in a sexual or violent manner, other illegal activities such as making or buying illegal weapons, violating someone's privacy, or providing or creating computer viruses.<br><br>

                    The service of gotonikah.com must be used in accordance to all local, state, and federal laws and regulations. Creation of more than one profile is not permitted in any case. Doing so may subject your membership to terminate without any refunds</p>


                    <p class="termPrivPara" align="justify">
                    <h6><b>Copyright Policy</b></h6>
                    <p style="text-align:justify">The copyrighted material, trademarks, or other proprietary information may not be copied, 
                    reproduced or distributed in any form without the prior written consent of the owner. In the event of your copyright materials being copied and posted,
                    you may get in touch with our copyright Agents for copyright infringement with an electronic or physical signature authorizing the person to act on
                    behalf of the owner and a description of the copyrighted material that you believe has been infringed.
                    You must also include the source of the material, your address, telephone number, and email address along with a written statement.
                    If applicable then you may also produce a certificate of the registration or any other intellectual property right. You can contact gotonikah.com's 
                    Copyright Agent for Notice of claims of copyright infringement by writing to the Mumbai address located under the Help/Contact section.</p>
                    <p class="termPrivPara" align="justify"><h6><b>Privacy</b></h6>The use of this service is governed by the gotonikah.com Privacy Policy.</p>
                    <p class="termPrivPara" align="justify"><h6><b>Disclaimers</b></h6>
                    <p style="text-align:justify">Gotonikah.com  does not claim any responsibility for the authenticity of the Content posted on the Site, 
                    whether caused by users visiting the Site, Members or by any equipment or programming associated with or utilized in the Service. 
                    Furthermore, gotonikah.com does not claim any responsibility for the conduct of any user and/or Member whether online or offline. 
                    Gotonikah.com assumes no responsibility for any error, omission, interruption, deletion, defect, delay in operation or transmission, 
                    communications line failure, theft or destruction or unauthorized access to, or alteration of, user and/or Member communications. 
                    The exchange of profile(s) through or by gotonikah.com should not in any way be construed as any offer and/or recommendation from/by  gotonikah.com.
                    The Site and the Service are provided "AS-IS AVALAIBLE BASIS" and gotonikah.com expressly disclaims any warranty of fitness for a particular purpose or non-infringement. 
                    Gotonikah.com cannot guarantee and does not promise any specific results from use of the Site and/or the gotonikah.com Service.</p>
                    </p>
                    <p class="termPrivPara" align="justify"><h6><b>Limitation on Liability</b></h6>
                    <p style="text-align:justify">Except in jurisdictions where such provisions are limited, 
                    in any event, gotonikah.com will not be liable to you or any third person for any indirect, consequential, exemplary, incidental, 
                    special or punitive damages, including also lost profits arising from your use of the Site. Notwithstanding anything to the contrary contained herein,
                    gotonikah.com, liability to you for any cause whatsoever, and regardless of the form of the action, will at all times be limited to the amount paid, if any,
                    by you to gotonikah.com, for the Service during the term of membership.</p></p>
                    <p class="termPrivPara" align="justify"><h6><b>Disputes</b></h6>
                    <p style="text-align:justify">If any dispute involving the Site and/or the Service arises, 
                    you agree that the dispute will be governed by the laws of India under the exclusive jurisdiction to the courts of Mumbai, India.</p></p>
                    <p class="termPrivPara" align="justify"><h6><b>Indemnity</b></h6>
                    <p style="text-align:justify">You agree to indemnify and hold gotonikah.com, its subsidiaries, directors, affiliates, 
                    officers, agents, and other partners and employees, harmless from any loss, liability, claim, or demand, including reasonable attorney's fees,
                    made by any third party due to or arising out of your use of the Service in violation of this Agreement and/or arising from a breach of these 
                    Terms of Use and/or any breach of your representations and warranties set forth above.</p></p>
                    <p class="termPrivPara" align="justify"><h6><b>Other</b></h6>
                    <p style="text-align:justify">By becoming a Member of gotonikah.com Service, you agree to receive specific emails from gotonikah.com.
                    This Agreement, accepted upon use of the Site and further affirmed by becoming a Member of the gotonikah.com Service, contains the entire agreement between you 
                    and gotonikah.com regarding the use of the Site and/or the Service. If any provision of this Agreement is held invalid, the remainder of this Agreement shall 
                    continue in full force and effect. You are under an obligation to report any misuse or abuse of the Site to gotonikah.com by writing to Customer Care. 
                    On receiving such complaint, gotonikah.com may, if necessary, terminate the membership of the Member responsible for such violation abuse or misuse.
                    If the complainant is at fault then they will be liable for termination of his / her membership without any refund of the subscription fee.</p></p>


                </div>
                </div>
                </div>
                </div>
                </div>
                </section>
    
    
    <!--<section id="homeAbout">-->
    <!--    <div class="container">-->
    <!--        <div class="row">-->
    <!--            <div class="col-12 col-md-8 mx-auto text-center">-->
    <!--                <h2 class="subHead">Get ready <span style="color:#5aba47;">with us</span></h2>-->
    <!--                <p class="para1 mb-5">Goto Nikah is India’s most trusted and user friendly online matrimony portal for Muslims.-->
    <!--                    Goto Nikah has helped thousands of Muslim singles to find their perfect soul mate</p>-->
    <!--            </div>-->
    <!--        </div>-->
    <!--        <div class="row my-5">-->
    <!--            <div class="col-12 col-sm-6 col-lg-3 text-center mb-4 mb-lg-0">-->
    <!--                <img src="<?php echo base_url(); ?>assets/images/Trusted.png" alt="Trusted Matrimonial Service" class="readyIcon" width="auto" height="auto">-->
    <!--                <h3>No.1 &amp; Trusted<br>Matrimonial Service</h3>-->
    <!--                <p>Our largest number of profiles<br>increases your chances</p>-->
    <!--            </div>-->
    <!--            <div class="col-12 col-sm-6 col-lg-3 text-center mb-4 mb-lg-0">-->
    <!--                <img src="<?php echo base_url(); ?>assets/images/Charge.png" alt="No Charge for Registration" class="readyIcon" width="auto" height="auto">-->
    <!--                <h3>No Charge for<br>Registration</h3>-->
    <!--                <p>Registering with us is completely<br>free and simple</p>-->
    <!--            </div>-->
    <!--            <div class="col-12 col-sm-6 col-lg-3 text-center mb-4 mb-sm-0">-->
    <!--                <img src="<?php echo base_url(); ?>assets/images/Validation.png" alt="Manual Screening and Validation" class="readyIcon" width="auto" height="auto">-->
    <!--                <h3>Manual Screening<br>and Validation</h3>-->
    <!--                <p>Our experts manually screen<br>and validate each profile</p>-->
    <!--            </div>-->
    <!--            <div class="col-12 col-sm-6 col-lg-3 text-center">-->
    <!--                <img src="<?php echo base_url(); ?>assets/images/Security.png" alt="Best Data Security and Privacy" class="readyIcon" width="auto" height="auto">-->
    <!--                <h3>Best Data Security<br>and Privacy</h3>-->
    <!--                <p>We follow best practices to<br>keep your data safe</p>-->
    <!--            </div>-->
    <!--        </div>-->
    <!--    </div>-->
    <!--</section>-->
    
    
    <!--<section id="homeDownload" class="downAbout" style="margin-bottom:0px !important;">-->
    <!--    <div class="container">-->
    <!--        <div class="row">-->
    <!--            <div class="col-12 col-xxl-10 mx-auto">-->
    <!--                <div class="row">-->
    <!--                    <div class="col-12 col-md-7 col-xl-6">-->
    <!--                        <h2 class="subHead mb-4">Search Profiles<br><span>Anytime! Anywhere!!</span></h2>-->
    <!--                        <p class="pOne">Finding your perfect match has never been easier with the Goto Nikah application</p>-->
    <!--                        <p class="pTwo">Download now and communicate with muslim matches on-the-go!</p>-->
    <!--                        <div class="d-flex">-->
    <!--                            <a href="javascript:void(0)">-->
    <!--                                <img src="<?php echo base_url(); ?>assets/images/appleStore.png" alt="appleStore" class="storeIcon me-3" width="auto" height="auto">-->
    <!--                            </a>-->
    <!--                            <a href="javascript:void(0)">-->
    <!--                                <img src="<?php echo base_url(); ?>assets/images/playStore.png" alt="playStore" class="storeIcon" width="auto" height="auto">-->
    <!--                            </a>-->
    <!--                        </div>-->
    <!--                    </div>-->
    <!--                    <div class="col-12 col-md-5 col-xl-6 text-center position-relative">-->
    <!--                        <img src="<?php echo base_url(); ?>assets/images/appMob1.png" alt="playStore" class="appIcon" width="auto" height="auto">-->
    <!--                    </div>-->
    <!--                </div>-->
    <!--            </div>-->
    <!--        </div>-->
    <!--    </div>-->
    <!--</section>-->
    
    
       <?php include('include/footer_gotonikah.php'); ?>


    <!-- login Modal -->
    <div class="modal fade" id="loginModal" tabindex="-1" aria-labelledby="loginModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg">
            <div class="modal-content">
                <div class="modal-body p-0">
                    <div class="row">
                        <div class="col-12 col-lg-6 d-none d-lg-flex align-items-stretch">
                            <div class="leftBox w-100">
                                <h2 class="modalHead mb-4" id="loginModalLabel">Search Profiles<br><span style="color:#5aba47;">Anytime! Anywhere!!</span></h2>
                                <p class="lpone">Finding your perfect match has never been easier with the Gotonikah application</p>
                                <p class="lptwo">Download now and communicate with muslim matches on-the-go!</p>
                                <div class="d-flex justify-content-center">
                                    <a href="javascript:void(0)">
                                        <img src="<?php echo base_url(); ?>assets/images/appleStore.png" alt="appleStore" class="storeIcon me-3" width="auto" height="auto">
                                    </a>
                                    <a href="https://play.google.com/store/apps/details?id=com.sysol.goto_nikah">
                                        <img src="<?php echo base_url(); ?>assets/images/playStore.png" alt="playStore" class="storeIcon" width="auto" height="auto">
                                    </a>
                                </div>
                            </div>
                        </div>
                        <div class="col-12 col-lg-6 d-flex align-items-stretch">
                            <div class="rbox w-100">
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                <div class="d-flex justify-content-between mb-5">
                                    <h3 class="welcomeHead">Welcome Back!<br><span>Please Login</span></h3>
                                    <img src="<?php echo base_url(); ?>assets/images/logo.png" alt="Goto Nikah" class="llogo" width="auto" height="auto">
                                </div>
                                <div class="emailLogBox">
                                    <form class="customForm">
                                        <div class="mb-3">
                                            <input type="text" name="" class="form-control" placeholder="Username/email">
                                        </div>
                                        <div class="mb-3">
                                            <input type="password" name="" class="form-control" placeholder="Password">
                                        </div>
                                        <p class="note">By continuing, you agree to GotoNikah's <a href="<?php echo site_url('user/terms_gotonikah'); ?>">Terms of Use</a> and <a href="<?php echo site_url('user/privacy_gotonikah'); ?>">Privacy Policy.</a></p>
                                        <button type="button" class="btn cstmBtnColr w-100" onclick="window.location.href='home.html'">Login</button>
                                        <p class="orTxt">OR</p>
                                        <button type="button" class="btn w-100 mb-3 loginOtpBtn">OTP Login</button>
                                    </form>
                                </div>
                                <div class="otpLogBox" style="display:none;">
                                    <form class="customForm">
                                        <div class="mb-3">
                                            <input type="text" name="" class="form-control" placeholder="Mobile Number/Email">
                                        </div>
                                        <p class="note">By continuing, you agree to GotoNikah's <a href="#">Terms of Use</a> and <a href="<?php echo site_url('user/privacy_gotonikah'); ?>">Privacy Policy.</a></p>
                                        <button type="button" class="btn cstmBtnColr sendOtp w-100">Send OTP</button>
                                        <p class="orTxt">OR</p>
                                        <button type="button" class="btn w-100 mb-3 loginEmailBtn">Email Login</button>
                                    </form>
                                </div>
                                <div class="otpsendBox" style="display:none;">
                                    <form class="customForm">
                                        <div class="mb-3">
                                            <label class="form-label">Enter Your OTP</label>
                                            <div class="otpInputs">
                                                <input type="text" class="form-control" maxlength="1">
                                                <input type="text" class="form-control" maxlength="1">
                                                <input type="text" class="form-control" maxlength="1">
                                                <input type="text" class="form-control" maxlength="1">
                                                <input type="text" class="form-control" maxlength="1">
                                                <input type="text" class="form-control" maxlength="1">
                                            </div>
                                        </div>
                                        <button type="button" class="btn cstmBtnColr w-100" onclick="window.location.href='home.html'">Submit</button>
                                        <p class="note text-center mb-1"><a href="javascript:void(0)">Send the Code Again</a></p>
                                        <p class="note text-center mb-4"><a href="javascript:void(0)">Change Mobile Number/Emial</a></p>
                                        <button type="button" class="btn w-100 mb-3 loginEmailBtn">Email Login</button>
                                    </form>
                                </div>
                                <div class="d-flex justify-content-between mb-3">
                                    <a href="javascript:void(0)" class="regWtFb">
                                        <img src="<?php echo base_url(); ?>assets/images/fb2.png" alt="facebook" width="auto" height="auto">
                                        <span>Facebook</span>
                                    </a>
                                    <a href="javascript:void(0)" class="regWtgoogle">
                                        <img src="<?php echo base_url(); ?>assets/images/google.png" alt="google" width="auto" height="auto">
                                        <span>Google</span>
                                    </a>
                                </div>
                                <p class="text-center newtoTxt">New to HappyNikah <a href="#">Register Now</a></p>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script type="text/javascript" src="<?php echo base_url(); ?>assets/js/jquery-3.6.0.min.js"></script>
    <script type="text/javascript" src="<?php echo base_url(); ?>assets/js/bootstrap.bundle.min.js"></script>

    <script src="<?php echo base_url(); ?>assets/js/owl.carousel.js"></script>

    <script type="text/javascript">
        $(document).ready(function() {
            // partner slider
            $(".owl-partner").owlCarousel({
                margin: 25,
                responsiveClass: true,
                nav: false,
                dots: false,
                autoplay: true,
                autoplayHoverPause: false,
                loop: true,
                responsive: {
                    0: {
                        items: 1.2,
                    },
                    576: {
                        items: 1.5,
                    },
                    768: {
                        items: 2.2,
                    },
                    992: {
                        items: 2.5,
                    },
                    1200: {
                        items: 3.2,
                    },
                    1400: {
                        items: 3.5,
                    }
                },
            });
            // partner slider end

            // burger menu
            $(".hamburger").click(function() {
                $(this).toggleClass("is-active");
                $('body').toggleClass("is-scroll-disabled");
            });
            // burger menu end

            // login with otp and email switch
            $(".loginOtpBtn").click(function() {
                $(".emailLogBox").hide();
                $(".otpLogBox").show();
            });
            $(".loginEmailBtn").click(function() {
                $(".otpLogBox").hide();
                $(".emailLogBox").show();
            });
            $(".sendOtp").click(function() {
                $(".otpLogBox").hide();
                $(".otpsendBox").show();
            });
        });
    </script>


</body>

</html>