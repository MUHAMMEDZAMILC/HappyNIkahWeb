<!DOCTYPE html>
<html>
<?php include('include/contactheader.php'); ?>
    <section id="utilityPage" class="pb-0">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="headBox mb-0">
                        <h2>Contact Us</h2>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
    
    
    
    <style>
    
    #moblogin 
    {
    margin-left: -105px;
    visibility: hidden;
    }
    
    @media (min-width: 280px) and (max-width: 991px)
    {
    input#name 
    {
    margin-top: 0px !important;
    }
    p.termPrivPara
    {
        margin-right:20px;
        margin-left:20px;
    }
    
    }
    </style>
        <div class="container-fluid">
    <div class="row">

                <div class="col-12 col-md-10 mx-auto">

                 

                   <!--- <p class="termPrivPara">Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo.</p>

                    <p class="termPrivPara"> qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam,</p>-->

                        <p class="termPrivPara" style="font-size: 15px;font-weight: 400;margin-bottom: 30px;margin-top: 35px;text-align:justify;">
                        Happy Nikah is a trustworthy Muslim community matrimony site for Malayalee
                        Muslims around the world. We are here for every Muslim bachelor to help them find
                        their better half. This Muslim marriage bureau Kerala is not meant for dating but to
                        provide a way to find life partners for mature Muslim women and men</p>

                        <p class="termPrivPara" style="font-size: 15px;font-weight: 400;margin-bottom: 30px;text-align:justify;margin-top: 35px;"> 
                        You can undoubtedly trust Happy Nikah, one of the best Muslim marriage bureaus in
                        Kerala. Contact Happy Nikah to register and search for your better half.</p>

                        <p class="termPrivPara" style="font-size: 15px;font-weight: 400;margin-bottom: 30px;text-align:justify;margin-top: 35px;">
                        Finding your partner through Happy Nikah Muslim community matrimony makes your
                        life feel like happily ever after. We assure you that we can provide you with an
                        awesome experience in matchmaking through this marriage agency. We provide
                        every Muslim bachelor out there the opportunity to register on the 'Happy Nikkah'
                        Muslim community matrimony site for absolutely free. We are here to understand
                        your concerns and help you find your true love. Contact us now!.</p>

                       
            </div>
                </div>

            </div>
            
    <section id="homeContact">
        <div class="container">
            <div class="row">
                <div class="col-12 col-xl-10 mx-auto">
                    <div class="row">
                        <div class="col-12 col-md-6 col-xxl-6 d-flex align-items-center mb-5 mb-md-0">
                        

                            <form class="customForm w-100" method="post" action="<?php echo base_url('user/contact_submit'); ?>">
                            <span id="success" style="color:green"></span>
                            <span id="error" style="color:red"></span>
                            
                            
                            <div id="success-message" class="popup">
                    <p><b><?php echo $this->session->flashdata('success'); ?></b></p>
                     </div>
                     
                         <div id="failure-message" class="popup">
                    <p><b><?php echo $this->session->flashdata('failure'); ?></b></p>
                     </div>
    
                            <br>
                                <div class="row">
                                    <div class="col-12 col-md-6 mb-3">
                                        <input type="text" name="name" id="name" placeholder="Name" class="form-control" required>
                                    </div>
                                    <div class="col-12 col-md-6 mb-3">
                                        <input type="email" name="email" id="email" placeholder="Email" class="form-control" required>
                                    </div>
                                </div>
                                <div class="mb-4">
                                    <textarea class="form-control" rows="5" id="message">Message Here....</textarea>
                                </div>
                                <div class="d-flex justify-content-end">
                                    <input type="submit" class="btn cstmBtnColr" value="Submit">
                                </div>
                            </form>
                        </div>
                        <div class="col-12 col-md-6 col-xxl-5 d-flex align-items-center ms-auto">
                            <div class="w-100">
                                <h2 class="subHead" style="font-size:31px;">Begin your <span>journey with us</span></h2>
                                <p class="addText mb-4">We are ready to help your nikah dream come true..!</p>
                                <div class="d-flex align-items-center mb-4">
                                    <div class="flex-shrink-0" style="margin-top: -160px;">
                                        <img src="<?php echo base_url();?>assets/images/address.png" alt="address" class="icon">
                                    </div>
                                    <div class="flex-grow-1 ms-3">
                                        <p class="addText mb-0">IV th Floor, Neospace,Kinfra Techno Industrial Park, Calicut University(PO),Malappuram, India.</p>
                                        
                                            <p class="addText mb-0">
                                                <h6 style="font-size: 20px;margin-top: 25px;">Head Office</h6>
                                               <b>HAPPY NIKAH</b><br/>
                                               
                                               CD TOWER,4TH FLOOR,<br/>
                                               Mini Bypass Road,Arayidathupalam,<br/>
                                               Kozhikode,Kerala-673004<br/>
                                               </p>
                                            
                                    </div>
                                    
                                   
                                     
                                    
                                    
                                </div>
                                <div class="d-flex align-items-center mb-4">
                                    <div class="flex-shrink-0">
                                        <a href="tel:+918593999888" style="color:#000;">
                                        <img src="<?php echo base_url();?>assets/images/telephone.png" alt="telephone" class="icon">
                                        </a>
                                    </div>
                                    <div class="flex-grow-1 ms-3">
                                        <p class="mobText mb-0">
                                        <a href="tel:+918593999888" style="color:#000;">
                                        +91 8593999888</a>,<br/>
                                        <a href="tel:+917594979772" style="color:#000;">
                                        +91 7594979772
                                        </a>
                                        </p>
                                    </div>
                                </div>
                                <div class="d-flex align-items-center">
                                    <div class="flex-shrink-0">
                                        <a href="mailto:info@happynikah.com" style="color:#000;text-decoration:none;">
                                        <img src="<?php echo base_url();?>assets/images/mail.png" alt="mail" class="icon">
                                        </a>
                                    </div>
                                    <div class="flex-grow-1 ms-3">
                                    <a href="mailto:info@happynikah.com" style="color:#000;text-decoration:none;">
                                    <p class="addText mb-0">info@happynikah.com
                                    </a>
                                    </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <?php include('include/footer.php'); ?>

        <script>
        
         $(document).ready(function() {
            // Show the success message popup
            $('#success-message').fadeIn('fast');

            // Hide the success message after a few seconds
            setTimeout(function() {
                $('#success-message').fadeOut('fast');
            }, 6000); // Adjust the duration as needed
            
             $('#failure-message').fadeIn('fast');

            // Hide the success message after a few seconds
            setTimeout(function() {
                $('#failure-message').fadeOut('fast');
            }, 6000); // Adjust the duration as needed
        });
        
        function SendMessage() {
        if($("#email").val()=="" || $("#name").val()=="" || $("#message").val()=="")
        {
        $("#error").html("All Fields are Required.");
        }
        else{
        
        
        $.ajax({
        url: '<?php echo site_url('Home/ContactNow'); ?>',
        type: "post",
        data: {mail: $("#email").val(), name: $("#name").val(), message: $("#message").val()},
        success: function (response) {
        if(response==1){
        $("#success").html("Mail has been sent successfully.");
        }
        else{
        $("#error").html("Couldnt sent mail.");
        }
        
        
        
        // You will get response from your PHP page (what you echo or print)
        },
        // error: function(jqXHR, textStatus, errorThrown) {
        //   console.log(textStatus, errorThrown);
        // }
        });
        }
        }
        </script>
        
     </body>
     </html>