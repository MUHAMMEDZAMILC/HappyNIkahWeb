<section id="footer">

    <div>

    </div>
  
    <div class="container">
        <div class="row">
            <div class="col-12 col-lg-4 col-md-12 mb-5 mb-md-0">
                <img src="<?php echo base_url() ?>assets/images/HappyNikah.png" alt="go to Nikah" width="auto" height="auto" class="flogo">
                <p class="para1" style="">Happy Nikah is an exclusive matrimonial website for Muslims to make happy lives.
                    We are ready to help Muslims to find their suitable life partner in an Islamic way.
                    <!--We do not support anything against Islamic law,-->
                    <!--Only matured Muslim men and women with an intention of marriage are allowed to register at-->
                    <!--Happynikah.com.-->
                    Happynikah.com will make your matrimonial searches and online-match making a simple, easy and
                    happy experience.
                </p>
            </div>
            <div class="col-12 col-md-1">
            </div>
            <div class="col-12 col-md-12 col-lg-3 mb-5 mb-md-0">
                <h2 id="quick">Quick Links</h2>
                <ul class="flinks">
                    <li>
                        <a href="<?php echo site_url(); ?>" style="text-decoration:none;">Register</a>
                    </li>
                    <li>
                        <a href="<?php echo site_url();?>about" style="text-decoration:none;">About Us</a>
                    </li>
                    <li>
                        <a href="<?php echo site_url();?>terms" style="text-decoration:none;">Terms and Condition</a>
                    </li>
                    <li>
                        <a href="<?php echo site_url();?>privacy" style="text-decoration:none;">Privacy Policy</a>
                    </li>
                     
                      <li>
                        <a href="<?php echo site_url();?>refund_policy" style="text-decoration:none;">Refund Policy</a>
                    </li>
                    
                    <li>
                        <span class="credit">credits</span><br>
                        <a style="font-size: 10px;" href="https://www.freepik.com/free-photo/smiling-woman-headset-presentation-something_12652765.htm#query=customer%20service&position=33&from_view=search&track=sph">Image by gpointstudio on Freepik</a>
                        <br>
                        <a style="font-size: 10px;" href="https://www.freepik.com/free-photo/arabic-girl-pretty-cute-young-muslim-woman-wrapped-beautiful-pink-hijab-pointing-left_29071258.htm#page=4&query=pointing%20muslim%20traditional&position=1&from_view=search&track=ais">Image by KamranAydinov on Freepik</a>
                    </li>
                </ul>
            </div>
            <div class="col-12 col-lg-4 col-md-12">
                <h2>Follow us</h2>
                <ul class="socialIcons d-flex">
                    <li>
                        <a href="https://www.facebook.com/happynikahmatrimony">
                            <img src="<?php echo base_url() ?>assets/images/fb.png" alt="facebook" width="auto" height="auto" class="socialLoogo">
                        </a>
                    </li>
                    <li>
                        <a href="https://www.instagram.com/happynikahmatrimony/">
                            <img src="<?php echo base_url() ?>assets/images/instagram.png" alt="instagram" width="auto" height="auto" class="socialLoogo">
                        </a>
                    </li>
                    <!--<li>-->
                    <!--    <a href="javascript:void(0)">-->
                    <!--        <img src="<?php echo base_url() ?>assets/images/twitter.png" alt="twitter" width="auto" height="auto" class="socialLoogo">-->
                    <!--    </a>-->
                    <!--</li>-->
                    <li>
                        <a href="https://youtube.com/channel/UCbZ6wkcWuVxDBCDG5AGRvhQ">
                            <img src="<?php echo base_url() ?>assets/images/youtube.png" alt="youtube" width="auto" height="auto" class="socialLoogo">
                        </a>
                    </li>
                </ul>
                
                





                <h3>Contact Info</h3>
                <div class="d-flex">
                    <ul class="flinks">
                        <li>
                            <div class="flex-grow-1">
                                <a href="tel:+918593999888" style="color:#000;text-decoration:none;">
                                <img src="<?php echo base_url() ?>assets/images/telephone.png" alt="telephone" class="icon" style="width: 20px;margin-right: 10px;">
                                </a>
                                 <a href="tel:+918593999888" style="color:#000;text-decoration:none;">
                                <span class="mobText mb-0" style="font-family: 'Poppins', sans-serif;font-weight: 600;font-size: 16px;">+91-8593999888</span>
                                </a>
                            </div>
                        </li>
                        <li>
                            <div class="flex-grow-1">
                                <a href="mailto:info@happynikah.com" style="color:#000;text-decoration:none;">
                                <img src="<?php echo base_url() ?>assets/images/mail.png" alt="mail" class="icon" style="width: 20px;margin-right: 10px;">
                                </a>
                                
                                <a href="mailto:info@happynikah.com" style="color:#000;text-decoration:none;">
                                <span class="addText mb-0" style="font-family: 'Poppins', sans-serif;font-weight: 500;font-size: 15px;">
                                    <!--<i class="fa fa-envelope"></i>-->
                                info@happynikah.com</span>
                                </a>
                                
                            </div>
                        </li>
                    </ul>
                </div>
                
                <h3>Download App</h3>
                <div class="d-flex">
                    <a href="https://apps.apple.com/in/app/happy-nikah/id1638696026">
                        <img src="<?php echo base_url() ?>assets/images/appleStoreF.png" alt="appleStore" width="auto" height="auto" class="storeIcon me-3">
                    </a>
                    <a target="_blank" href="https://play.google.com/store/apps/details?id=com.sysol.happy_nikah">
                        <img src="<?php echo base_url() ?>assets/images/playStoreF.png" alt="playStore" width="auto" height="auto" class="storeIcon">
                    </a>
                </div>
                
            </div>
        </div>
        <div class="row">
            <div class="col-12 text-center">
                <p class="at">© 2023 Happynikah All Rights Reserved</p>
            </div>
        </div>
    </div>
</section>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">


<style> 

    .toggle-password 
    {
    position: absolute;
    top: 38%;
    /* margin-top: -66px; */
    margin-right: 53px;
    right: 10px;
    transform: translateY(-50%);
    cursor: pointer;
    } 
    
    
    @media (min-width: 768px) and (max-width: 991px)
    { 
    #footer h2 {
    font-family: "Poppins", sans-serif;
    font-weight: 600;
    /*font-size: 29px;*/
    /*margin-bottom: 28px;*/
    /*margin-top: 25px;*/
    font-size: 20px;
    margin-bottom: 24px;
    margin-top: 9px;
    }
    
    h2#quick
    {
    margin-bottom: 20px !important;
    margin-top: 20px !important;  
    }
    }
    

  @media (min-width: 280px) and (max-width: 767px)
  { 
    #footer h2 
    {
    font-family: "Poppins", sans-serif;
    font-weight: 600;
    /*font-size: 29px;*/
    /*margin-bottom: 28px;*/
    /*margin-top: 25px;*/
    font-size: 20px;
    margin-bottom: 28px;
    margin-top: -40px;
    }
    
    #footer h3
    {
         font-size: 22px; 
         margin-bottom:30px;
    }
    
    .icon
    {
        width:35px !important;
    }
    .mobText.mb-0
    {
        font-size: 22px !important;
        font-weight:normal !important;
    }
    .addText.mb-0
    {
       /*font-size: 22px !important;   */
    }
    .addText.mb-0 
    {
    /*font-size: 16px !important;*/
    font-weight: normal !important;
    font-size: 17px !important;
    }
    .credit
    {
       font-size: 25px;   
    }
    #footer .at
    {
       font-size: 20px;     
    }
    #footer .socialLoogo
    {
    height: 22px;
    margin-left: 0px;
    }
    
    #footer .flogo
    {
    width:75px !important;
    margin-top: -63px;
    margin-bottom: 23px;
    }
    
    .modal-content
    {
        /*background: url(https://happynikah.com/assets/images/Splashbg.png);*/
    background: url(https://happynikah.com/assets/images/Splashbg.png);
    background-size: contain;
    background-position: center center;
    }
 }
 
   @media (min-width: 280px) and (max-width: 991px)
  { 
   i.toggle-password.fas.fa-eye
   {
       display:none;
   }
  }
</style>

<!-- login Modal -->
<div class="modal fade" id="loginModal" tabindex="-1" aria-labelledby="loginModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content">
            <div class="modal-body p-0">
                <div class="row">
                    <div class="col-12 col-lg-6 d-none d-lg-flex align-items-stretch">
                        <div class="leftBox w-100">
                            <h2 class="modalHead mb-4" id="loginModalLabel">Search Profiles<br><span>Anytime! Anywhere!!</span></h2>
                            <p class="lpone">Finding your perfect match has never been easier with the Happy nikah application</p>
                            <p class="lptwo">Download now and communicate with muslim matches on-the-go!</p>
                            <div class="d-flex justify-content-center">
                                <a href="https://apps.apple.com/in/app/happy-nikah/id1638696026">
                                    <img src="<?php echo base_url() ?>assets/images/appleStore.png" alt="appleStore" class="storeIcon me-3" width="auto" height="auto">
                                </a>
                                <a href="https://play.google.com/store/apps/details?id=com.sysol.happy_nikah">
                                    <img src="<?php echo base_url() ?>assets/images/playStore.png" alt="playStore" class="storeIcon" width="auto" height="auto">
                                </a>
                            </div>
                        </div>
                    </div>
                    
                    
                    <div class="col-12 col-lg-6 d-flex align-items-stretch" style="background: url(https://happynikah.com/assets/images/Splashbg.png);
                       background-size: contain;background-position: center center;">
                        <div class="rbox w-100">
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            <div class="d-flex justify-content-between mb-5">
                                <h3 class="welcomeHead">Welcome Back!<br><span>Please Login</span></h3>
                                <img src="<?php echo base_url() ?>assets/images/logo.png" alt="go to Nikah" class="llogo" width="auto" height="auto">
                            </div>
                            <div class="emailLogBox">
                                <form class="customForm">
                                    <div class="mb-3" id="loginerror" style="display:none">
                                        <font color="red">Invalid Username or Password..</font>
                                    </div>
                                    <div class="mb-3">
                                        <input type="text" name="username_login" class="form-control" id="username_login" placeholder="Username">
                                    </div>
                                    <div class="mb-3">
                                        <input type="password" name="password_login" class="form-control" id="password_login" placeholder="Password">
                                            <i class="toggle-password fas fa-eye" onclick="togglePassword()"></i>

                                    </div>
                                    <p class="note">By continuing, you agree to Happy nikah's <a href="<?php echo site_url();?>terms">Terms of Use</a> and 
                                    
                                    <a href="<?php echo site_url();?>privacy">Privacy Policy.</a>
                                    </p>
                                    
                                    <button type="button" class="btn cstmBtnColr w-100" id="loginbtn" onclick="login()">Login</button>
                                    <p class="orTxt">OR</p>
                                    <button type="button" class="btn w-100 mb-3 loginOtpBtn">OTP Login</button>
                                </form>
                            </div>
                            <div class="otpLogBox" style="display:none;">
                                
                                <form class="customForm" id="otplogin">
                                <div class="d-flex">
                                <select name="otpcountryCode" id="otpcountryCode" class="form-control phoneSelect" required>
                                <option value="">ISD</option>
                                <?php
                                foreach ($countryCode as $val) {
                                if ($val['country_order'] != '0') { ?>
                                <option value="<?= $val['country_code']; ?>"><?= "+" . $val['country_code']; ?></option>
                                <?php }
                                } ?>
                                </select>
                                
                                <input type="text" class="form-control" placeholder="Mobile Number" id="otpmobile" name="otpmobile" maxlength="10" 
                                onkeypress="return event.charCode > 47 && event.charCode < 58;">
                                </div>
                                <span id="otpmobilecode_val" class="validationclass" style="color: red;font-size: 15px;"></span>
                                
                                <div class="mb-3">
                                
                                <p class="note">By continuing, you agree to Happy nikah's <a href="<?php echo site_url();?>terms">Terms of Use</a> and 
                                
                                <a href="<?php echo site_url();?>privacy">Privacy Policy</a>
                                </p>
                                
                                <button type="button" class="btn cstmBtnColr sendOtp w-100" onclick="otplogin()">Send OTP</button>
                                <p class="orTxt">OR</p>
                                <button type="button" class="btn w-100 mb-3 loginEmailBtn"> Login with Id & Password</button>
                                </div>
                                </form>
                                
                            </div>
                            
                            
                            <div class="otpsendBox" style="display:none;">
                                <form class="customForm">
                                    <div class="mb-3">
                                        <label class="form-label">Enter Your OTP</label>
                                        <div class="otpInputs">
                                            <input type="text" id="verify7" class="form-control" maxlength="1" onkeyup="tabChange(this,'verify8')" />
                                            <input type="text" id="verify8" class="form-control" maxlength="1" onkeyup="tabChange(this,'verify9')" />
                                            <input type="text" id="verify9" class="form-control" maxlength="1" onkeyup="tabChange(this,'verify10')" />
                                            <input type="text" id="verify10" class="form-control" maxlength="1" onkeyup="tabChange(this,'verify11')" />
                                            <input type="text" id="verify11" class="form-control" maxlength="1" onkeyup="tabChange(this,'verify12')" />
                                            <input type="text" id="verify12" class="form-control" maxlength="1" />
                                        </div>
                                    </div>
                                    <button type="button" class="btn cstmBtnColr w-100" onclick="verify_mobile_forlogin()">Submit</button>
                                    <p class="note text-center mb-1"><a href="#" onclick="resend_otp()">Send the Code Again</a></p>
                                    <p class="note text-center mb-4"><a href="javascript:void(0)">Change Mobile Number</a></p>
                                    <button type="button" class="btn w-100 mb-3 loginEmailBtn">Login</button>
                                </form>
                                <span id="userexist_val" class="validationclass" style="color: red;font-size: 15px;"></span>

                            </div>
                           <!-- <div class="d-flex justify-content-between mb-3">
                                <a href="javascript:void(0)" class="regWtFb">
                                    <img src="<?php echo base_url() ?>assets/images/fb2.png" alt="facebook" width="auto" height="auto">
                                    <span>Facebook</span>
                                </a>
                                <a href="javascript:void(0)" class="regWtgoogle">
                                    <img src="<?php echo base_url() ?>assets/images/google.png" alt="google" width="auto" height="auto">
                                    <span>Google</span>
                                </a>
                            </div>-->
                            <p class="text-center newtoTxt">New to Happy Nikah <a href="<?php echo site_url(); ?>">Register Now</a></p>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script type="text/javascript" src="<?php echo base_url(); ?>/assets/js/jquery-3.6.0.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>/assets/js/bootstrap.bundle.min.js"></script>

<script src="<?php echo base_url(); ?>/assets/js/owl.carousel.js"></script>




<script type="text/javascript">

        function togglePassword() 
        {
        const passwordField = document.getElementById("password_login");
        const icon = document.querySelector(".toggle-password");
        
        if (passwordField.type === "password") 
        {
        passwordField.type = "text";
        icon.classList.remove("fa-eye");
        icon.classList.add("fa-eye-slash");
        } 
        
        else 
        {
        passwordField.type = "password";
        icon.classList.remove("fa-eye-slash");
        icon.classList.add("fa-eye");
        }
        }
   
        // partner slider end

        // burger menu
        $(".hamburger").click(function() {
            $(this).toggleClass("is-active");
            $('body').toggleClass("is-scroll-disabled");
        });
        // burger menu end

        // login with otp and email switch
        $(".loginOtpBtn").click(function() {
            $(".emailLogBox").hide();
            $(".otpLogBox").show();
        });
        $(".loginEmailBtn").click(function() {
            $(".otpLogBox").hide();
            $(".otpsendBox").hide();
            $(".emailLogBox").show();
        });
      /*  $(".sendOtp").click(function() {
            $(".otpLogBox").hide();
            $(".otpsendBox").show();
        });*/

        // partner slider
     

    function login() {
        var username = $('#username_login').val();
        var password = $('#password_login').val();
        if (username == "" || password == "") {
            $('#loginerror').show();
            $('#loginbtn').html('Login');
        } else {
            $('#loginbtn').html('<i class="fa fa-circle-o-notch fa-spin" style="font-size:24px"></i>  Please wait....');

            $.ajax({
                url: "<?php echo site_url('user/login'); ?>",
                type: "post",
                data: {
                    username: username,
                    password: password
                },
                dataType: "html",
                async: 'true',
                success: function(response) 
                {
                    
                if (response == 1)
                {
                window.location.href = "<?php echo site_url('registration_steptwo?currentpage=1'); ?>";
                return true;
                
                }
                else if (response == 2) 
                {
                window.location.href = "<?php echo site_url('registration_stepthree?currentpage=1'); ?>";
                return true;
                }
                else if (response == 3) 
                {
                window.location.href = "<?php echo site_url('registration_stepfour?currentpage=1'); ?>";
                return true;
                }
                else if (response == 4) 
                {
                window.location.href = "<?php echo site_url();?>home";
                return true;
                } 
                else if (response == 6)
                {
                
                $('#loginerror').show();
                
                $('#loginbtn').html('Login'); return true;
                }
                else
                {
                $('#loginerror').show();
                
                $('#loginbtn').html('Login');
                
                // window.location.href = "<?php echo site_url('registration_step1?currentpage=1'); ?>";
                }

                    // You will get response from your PHP page (what you echo or print)
                },
                // error: function(jqXHR, textStatus, errorThrown) {
                //   console.log(textStatus, errorThrown);
                // }
            });
        }

    }

    function otplogin() {

        if ($("#otpmobile").val() == "" || $("#otpcountryCode").val() == "") {
            $('#otpmobilecode_val').html('Field Required');
           // alert($("#otpmobile").val());
            return false;

        } else {
            $('#otpmobilecode_val').html('');
        
        var code = $("#otpcountryCode").val();
        var mobile = $("#otpmobile").val();
        if (code != "" && mobile != "") {
            $.ajax({
                url: "<?php echo site_url('user/user_otplogin'); ?>",
                type: "post",
                data: {
                    code: code,
                    mobile: mobile,
                },
                success: function(response) {
                    // alert("mnm");
                    // alert(response);
                    if (response == "1") {
                        $(".otpLogBox").hide();
                        $(".otpsendBox").show();
                        $("#verify7").focus();
                        $('#userexist_val').html();
                    } else if (response == "2") {
                        $('#otpmobilecode_val').html('Couldnt send otp..');
                    } else if (response == "3") {
                        $('#otpmobilecode_val').html('Phone Number doesnt exist..');

                    } else {
                        $('#otpmobilecode_val').html();
                    }
                    // You will get response from your PHP page (what you echo or print)
                },
                // error: function(jqXHR, textStatus, errorThrown) {
                //   console.log(textStatus, errorThrown);
                // }
            });
        }}
    }

    function verify_mobile_forlogin() {

        var otpdigit1 = $('#verify7').val();
        var otpdigit2 = $('#verify8').val();
        var otpdigit3 = $('#verify9').val();
        var otpdigit4 = $('#verify10').val();
        var otpdigit5 = $('#verify11').val();
        var otpdigit6 = $('#verify12').val();

        $.ajax({
            url: "<?php echo site_url(); ?>user/verify_mobile_forlogin?currentpage=1",
            type: "post",
            data: {
                otpdigit1: otpdigit1,
                otpdigit2: otpdigit2,
                otpdigit3: otpdigit3,
                otpdigit4: otpdigit4,
                otpdigit5: otpdigit5,
                otpdigit6: otpdigit6
            },
            success: function(response) {
                // alert(response);
                console.log(response);
                if (response == 1) {
                    $('.errorotplogin').html('OTP Verified');
                    $('.errorotplogin').css('color', 'green');
                    window.location.href = "<?php echo site_url('registration_steptwo?currentpage=1'); ?>";

                } else if (response == 2) {
                    $('.errorotplogin').html('OTP Verified');
                    $('.errorotplogin').css('color', 'green');
                    window.location.href = "<?php echo site_url('registration_stepthree?currentpage=1'); ?>";

                } else if (response == 3) {
                    $('.errorotplogin').html('OTP Verified');
                    $('.errorotplogin').css('color', 'green');
                    window.location.href = "<?php echo site_url('registration_stepfour?currentpage=1'); ?>";

                } else if (response == 4) {
                    $('.errorotplogin').html('OTP Verified');
                    $('.errorotplogin').css('color', 'green');
                    window.location.href = "<?php echo site_url();?>home";

                } else if (response == 6) {

                    $('#loginerror').show();

                    $('#loginbtn').html('Login');
                } else {

                    window.location.href = "<?php echo site_url('registration_step1?currentpage=1'); ?>";
                }
                if (response == 1) {
                    $('.errorotplogin').html('OTP Verified');
                    $('.errorotplogin').css('color', 'green');
                    // window.location.href = "<?php echo base_url(); ?>index.php/user/registration_steptwo?currentpage=1";
                    setTimeout(function() {
                        window.location.href = "<?php echo base_url(); ?>congratulations";
                    }, 1500);
                } else {
                    $('.errorotplogin').html('Invalid OTP');
                }

            },
        });

    }

    function resend_otp() {
        $.ajax({
            url: "<?php echo site_url(); ?>user/resend_otp",
            type: "post",
            data: {
                code: "resend",
            },
            success: function(response) {
                if (response == "1") {
                    $(".otpLogBox").hide();
                    $(".otpsendBox").show();
                    $("#verify7").focus();
                    $('#userexist_val').html();
                } else if (response == "2") {
                    $('#userexist_val').html('Couldnt send otp..');
                }
            }
        });
    }
    
</script>