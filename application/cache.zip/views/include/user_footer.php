<section id="userFooter">
        <div class="container">
            <div class="row">
                <div class="col-12 text-center">
                    <p class="at">© 2023 happynikah All Rights Reserved</p>
                </div>
            </div>
        </div>
    </section>
    
    <script type="text/javascript" src="<?php echo base_url(); ?>assets/js/jquery-3.6.0.min.js"></script>
    <script type="text/javascript" src="<?php echo base_url(); ?>assets/js/bootstrap.bundle.min.js"></script>
 <!---the core firebasejs sdk is always required and must be listed first -->
