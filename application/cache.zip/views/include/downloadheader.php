<head>

    <meta charset="UTF-8">

    <title>Download Happy Nikah Matrimony App | Muslim Marriage Agency in Kerala</title>

    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />

    <meta name="viewport" content="width=device-width, initial-scale=1">

   <meta name="description" content="Download Happy Nikah, the best matrimony app on the Google Play store and App
store, and search for your partner from this muslim marriage agency">

    <link rel="icon" type="image/png" sizes="32x32" href="favicon.ico">
 <link rel="icon" type="image/png" sizes="32x32" href="https://happynikah.com/assets/images/hnicon.png">


    <link rel="preconnect" href="https://fonts.googleapis.com">

    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

    <link href="https://fonts.googleapis.com/css2?family=Archivo:wght@300;400;500;600;700;900&family=Noto+Sans+Malayalam:wght@400;500;600&family=Poppins:wght@300;400;500;600;700;800;900&family=Roboto:wght@400;500&display=swap" rel="stylesheet">



    <link rel="stylesheet" href="<?php echo base_url() ?>assets/css/bootstrap.min.css">



    <link rel="stylesheet" href="<?php echo base_url() ?>assets/css/owl.carousel.min.css">

    <link rel="stylesheet" href="<?php echo base_url() ?>assets/css/owl.theme.default.min.css">

    <link href="//netdna.bootstrapcdn.com/font-awesome/3.2.1/css/font-awesome.css" rel="stylesheet">



    <link rel="stylesheet" href="<?php echo base_url() ?>assets/css/style.css?v=<?= rand(10, 100); ?>">

    <!-- Global site tag (gtag.js) - Google Analytics -->

    <script async src="https://www.googletagmanager.com/gtag/js?id=G-X44BV75LEC"></script>

    <script>

        window.dataLayer = window.dataLayer || [];



        function gtag() {

            dataLayer.push(arguments);

        }

        gtag('js', new Date());



        gtag('config', 'G-X44BV75LEC');

    </script>

    <!-- Meta Pixel Code -->

    <script>

        ! function(f, b, e, v, n, t, s) {

            if (f.fbq) return;

            n = f.fbq = function() {

                n.callMethod ?

                    n.callMethod.apply(n, arguments) : n.queue.push(arguments)

            };

            if (!f._fbq) f._fbq = n;

            n.push = n;

            n.loaded = !0;

            n.version = '2.0';

            n.queue = [];

            t = b.createElement(e);

            t.async = !0;

            t.src = v;

            s = b.getElementsByTagName(e)[0];

            s.parentNode.insertBefore(t, s)

        }(window, document, 'script',

            'https://connect.facebook.net/en_US/fbevents.js');

        fbq('init', '435890978249652');

        fbq('track', 'PageView');

    </script>

    <noscript><img height="1" width="1" style="display:none" src="https://www.facebook.com/tr?id=435890978249652&ev=PageView&noscript=1" /></noscript>

    <!-- End Meta Pixel Code -->

    <style type="text/css">
    
     #moblogin
        {
            visibility:hidden;
        }
        
        

        .validationclass 
        {
        
        color: red;
        
        font-size: 12px;
        
        padding: 5px 2px;
        
        }
        
        .otpInputs 
        {
        
        display: flex;
        
        flex-direction: row;
        
        flex-wrap: wrap;
        
        align-content: space-around;
        
        justify-content: space-evenly;
        
        }
        
        .errorotp 
        {
        
        text-align: center;
        
        color: red;
        
        background: #ff00000f;
        
        padding: 5px;
        
        }
        
        .already-member
        {
        
        float: left;
        
        width: 89px;
        
        font-size: 10px;
        
        color: white;
        
        padding-top: 7px;
        
        }
        .loginbtn
        {
        
        background: #fdfdfd;
        
        width: 90px;
        
        margin-left: 8px;
        
        padding: 2px 0px;
        
       }
        #banner .overlay 
        {
        
        background-color: rgb(253 232 232 / 0%);
        
        }
        
        #more
        {
        display: none;
        
        }
        
        #banner .bannerPara 
        {
        background: #ffffff38;
        
        padding: 15px 4px;
        
        }
        
        @media only screen and (max-width: 600px)
        {
        .already-member 
        {
        
        float: left;
        
        width: 89px;
        
        font-size: 10px;
        
        color: white;
        
        }
        
        .loginbtn 
        {
            
        background: #fdfdfd;
        
        width: 60px;
        
        margin-left: 8px;
        
        padding: 2px 0px;
        
        font-size: 12px;
        
        }
        }
        
        
        @media only screen and (max-width: 767px)
        {
        div#member
        {
        visibility:visible !important;
        }
        }
        
        @media (min-width: 280px) and (max-width: 991px)
        {
        #header
        {
        background-color: #ff5b85;
        padding: 30px 0;
        }
        #header .gotoNikahlogo 
        {
        
        width:70px !important;
        }
        .already-member {
        /*width: 320px;*/
        /*font-size: 29px;*/
        
        color: #fff !important;
        width: 100px;
        float: left;
    
        }
        
        #header .nav-link
        {
            /*font-size:30px !important;*/
        font-size:14px !important;
        }
        
        #header .navbar-toggler
        {
        /*padding:56px !important;*/
        margin-right: -2px;
        }
        }
        
        @media (min-width: 280px) and (max-width: 991px)
        { 
        a#headicon
        {
        margin-left:130px;
        }
        #header 
        {
        background-color: #ff5b85;
        padding: 0px 0;
        position: absolute;
        }
        
        img#apple
        {
        margin-left: 0px !important;
        }
        
        .agereq {
        color: red;
        font-size: 12px;
        margin-left: 0px !important;
        
        }
        h2.pOne
        {
        color: #ff5b85 !important;
        }
        
        #homeback
        {
        background-color: #fff !important;
        }
        
        p.bannerPara.mb-4.mb-md-0.pe-md-4 
        {
        display: none;
        }
        
        .form-control
        {
        width: 100% !important;
        }
        
        h3.hTwo {
        display: none;
        }
        
        label#ml
        {
        margin-left: 12px !important;
        margin-top:-12px;
        }
        
        input#name
        {
        margin-top: 56px !important;
        }
        
        input#male
        {
        /*margin-left: -4px !important;*/
        
        margin-top: -6px;
        margin-left: -6px !important;
        }
        label.form-check-label
        {
        /*margin-left: 15px !important; */
        margin-left: 0px !important; 
        }
        .vl
        {
        margin-left: 70px !important;
        
        }
        input#female {
        margin-left: 80px !important;
        }
        label#fml
        {
        margin-left: 98px !important;   
        }
        .v2{
        
        border-left: 0px solid #ff5b85 !important;
        }
        img#ml {
        margin-left: 42px !important;
        }
        img#fl {
        margin-left: 140px !important;
        }
        select#user_age
        {
        margin-left: -110px !important;   
        }
        
        #ctphone
        {
        margin-left:-3px !important;
        }
        select#countryCode
        {
        
        /*margin-left: -13px !important;  */
        margin-left: -7px !important;  
        }
        
        input#phone 
        {
        margin-left: -10px !important;
        width: 112% !important;
        /*margin-top: 13px;*/
        /*margin-left: -13px !important;  */
        }
        .regsub
        {
        margin-left:82px !important;
        }
        
        /*html {*/
        /*overflow-y: hidden;*/
        /*overflow-x: hidden;*/
        /*}*/
        
        /*body*/
        /*{*/
        /*overflow-y: hidden;*/
        /*overflow-x: hidden;  */
        /*}*/
        
        
        .subHead {
        font-size: 24px;
        margin-bottom: 16px;
        margin-top: 50px;
        
        }
        
        img#play
        {
        width: 100% !important;
        position: absolute;
        left: 0px !important;
        top: -540px !important;
        z-index: 1;
        }  
        
        .search
        {
        margin-top:170px;
        }
        
        
        h2.subHead1.mb-4 {
        font-size: 30px !important;
        }
        
        #homeDownload .pOne {
        font-size: 18px;
        }
        #homeDownload .pTwo {
        font-size: 18px;
        }
        #homeDownload .storeIcon {
        height: 45px !important;
        }
        
        .lPull{
        display:none;
        }
        
        .search
        {
        width: unset;
        margin-left: unset;
        }
        
        
        .mobText.mb-0 
        {
        font-size: 18px !important;
        }
        #homeVid
        {
        display:none;
        }
        #homeContact 
        {
        padding: 10px 0;
        }
        
        #moblogin
        
        {
        visibility:visible;
        }
        .already-member
        {
        color: #fff !important;
        width:100px;
        }
        
        button#logmob
        {
        visibility: visible !important;
        }
        .web-login
        {
        visibility: hidden !important;
        }
        
        p#txt
        {
        font-size:16px !important;
        }
        p#mob
        {
        font-size:16px !important;
        }
        p#mail_happy
        {
        font-size:17px !important;  
        }
        
        p#phone_val
        {
        margin-left: -7px !important;
        }
        
        }

    </style>

</head>



<body>

  <section id="header">

        <nav class="navbar navbar-expand-lg">

            <div class="container">

                <a class="navbar-brand" href="<?php echo site_url(); ?>">

                    <img src="<?php echo base_url() ?>assets/images/HappyNikkahwhite.png" alt="Happy Nikah" width="auto" height="auto" class="gotoNikahlogo">

                </a>



                 <div class="mob-login" id="moblogin">

                    <n class="already-member">Already a member?</n>

                    <button type="button" class="btn loginbtn" data-bs-toggle="modal" data-bs-target="#loginModal" id="logmob">Login</button>

                </div>
                
                
                

                <!--<n class="already-member">Already a member?</n><button type="button" class="btn loginbtn" data-bs-toggle="modal" data-bs-target="#loginModal">Login</button>-->

                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarGoToNikah" aria-controls="navbarGoToNikah" aria-expanded="false" aria-label="Toggle navigation">

                    <div class="hamburger" id="hamburger-1">

                        <span class="line"></span>

                        <span class="line"></span>

                        <span class="line"></span>

                    </div>

                </button>

                <div class="collapse navbar-collapse" id="navbarGoToNikah">
                    
                    
                

                    <ul class="navbar-nav mx-auto mb-2 mb-lg-0 mt-3 mt-lg-0">

                        <li class="nav-item">

                            <a class="nav-link active" aria-current="page" href="<?php echo site_url(); ?>">Home</a>

                        </li>

                        <li class="nav-item">

                            <a class="nav-link" href="<?php echo site_url('user/about'); ?>">About us</a>

                        </li>
                        
                         

                        <li class="nav-item">

                            <a class="nav-link" href="<?php echo site_url('user/download'); ?>">Download</a>

                        </li>

                        <li class="nav-item">

                            <a class="nav-link" href="<?php echo site_url('user/contactus'); ?>">Contact</a>

                        </li>
                        
                       
                

                    </ul>
                    
                     <div class="d-flex" style="margin-left: 0px;">
                    <a href="javascript:void(0)" style="margin-top: -84px;" id="headicon">
                        <img src="<?php echo base_url() ?>assets/images/appleStoreF.png" alt="appleStore" id="apple" width="auto" height="auto" style="width: 90px;
    margin-bottom: -5px;" class="storeIcon me-3">
                    </a>
                    <a target="_blank" href="https://play.google.com/store/apps/details?id=com.sysol.happy_nikah" style="margin-top: -84px;">
                        <img src="<?php echo base_url() ?>assets/images/playStoreF.png" alt="playStore" width="auto"  style="width:90px;"   height="auto" class="storeIcon">
                    </a>
                </div>

                    <div class="web-login">

                        <n class="already-member" style="color:#fff;">Already a member?</n>

                        <button type="button" class="btn loginbtn" data-bs-toggle="modal" data-bs-target="#loginModal">Login</button>

                    </div>

                    <!--<ul class="d-flex logList align-items-center mb-3 mb-lg-0">-->

                    <!--    <li>Already Member</li>-->

                    <!--    <li>-->

                    <!--        <button type="button" class="btn" data-bs-toggle="modal" data-bs-target="#loginModal">Login</button>-->

                    <!--    </li>-->

                    <!--</ul>-->



                </div>

            </div>

        </nav>

    </section> 