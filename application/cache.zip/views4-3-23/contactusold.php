<!DOCTYPE html>
<html><head>
	<meta charset="UTF-8">
    <title>Contact Happy Nikah Muslim Marriage Bureau Kerala |Muslim Community Matrimony</title>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    
    <meta name="description" content="This is a muslim marriage bureau in Kerala. This muslim community matrimony site is one of the most popular marriage bureaus. Contact happy nikah muslim community marriage site">

    <link rel="icon" type="image/png" sizes="32x32" href="https://happynikah.com/assets/images/hnicon.png">

    <link rel="preconnect" href="https://fonts.googleapis.com/">
    <link rel="preconnect" href="https://fonts.gstatic.com/" crossorigin="">
    <link href="<?php echo base_url() ?>assets/css/css2.css" rel="stylesheet"> 

    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/bootstrap.min.css">

    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/owl.carousel.min.css">
    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/owl.theme.default.min.css">

    <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/style.css">
</head>
<body>
    <section id="header">
        <nav class="navbar navbar-expand-lg">
            <div class="container">
                <a class="navbar-brand" href="https://www.happynikah.com">
                    <img src="<?php echo base_url(); ?>assets/images/HappyNikkahwhite.png" alt="Happy Nikah" class="gotoNikahlogo" width="auto" height="auto">
                </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarGoToNikah" aria-controls="navbarGoToNikah" aria-expanded="false" aria-label="Toggle navigation">
                    <div class="hamburger" id="hamburger-1">
                        <span class="line"></span>
                        <span class="line"></span>
                        <span class="line"></span>
                    </div>
                </button>
                <div class="collapse navbar-collapse" id="navbarGoToNikah">
                    <ul class="navbar-nav mx-auto mb-2 mb-lg-0 mt-3 mt-lg-0">
                        <li class="nav-item">
                            <a class="nav-link active" aria-current="page" href="https://www.happynikah.com">Home</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo site_url('user/about');?>">About us</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo site_url('user/download');?>">Download</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo site_url('user/contactus');?>">Contact</a>
                        </li>
                    </ul>
<!--                    <ul class="d-flex logList align-items-center mb-3 mb-lg-0">
                        <li>Already Member</li>
                        <li>
                            <button type="button" class="btn" data-bs-toggle="modal" data-bs-target="#loginModal">Login</button>
                        </li>
                    </ul>-->
                  
                </div>
            </div>
        </nav>
    </section>
    <section id="utilityPage" class="pb-0">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="headBox mb-0">
                        <h2>Contact Us</h2>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section id="homeContact">
        <div class="container">
            <div class="row">
                <div class="col-12 col-xl-10 mx-auto">
                    <div class="row">
                        <div class="col-6">
                            <p align="justify" class="termPrivPara">
                                Happy Nikah is a trustworthy Muslim community matrimony site for Malayalee Muslims around the world. We are here for every Muslim bachelor to help them find their better half. This Muslim marriage bureau Kerala is not meant for dating but to provide a way to find life partners for mature Muslim women and men.
                            </p>
                             <p align="justify" class="termPrivPara">
                                You can undoubtedly trust Happy Nikah, one of the best Muslim marriage bureaus in Kerala. Contact Happy Nikah to register and search for your better half.
                            </p>
                            <p align="justify" class="termPrivPara">
                               Finding your partner through Happy Nikah Muslim community matrimony makes your life feel like happily ever after. We assure you that we can provide you with an awesome experience in matchmaking through this marriage agency. We provide every Muslim bachelor out there the opportunity to register on the 'Happy Nikkah' Muslim community matrimony site for absolutely free. We are here to understand your concerns and help you find your true love. Contact us now!
                            </p>
                           
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-12 col-md-6 col-xxl-6 d-flex align-items-center mb-5 mb-md-0">
                            <form class="customForm w-100">
                                <div class="row">
                                    <div class="col-12 col-md-6 mb-3">
                                        <input type="text" name="" id="name" placeholder="Name" class="form-control">
                                    </div>
                                    <div class="col-12 col-md-6 mb-3">
                                        <input type="email" name="" id="email" placeholder="Email" class="form-control">
                                    </div>
                                </div>
                                <div class="mb-4">
                                    <textarea class="form-control" id="message" rows="5"></textarea>
                                </div>
                                <div class="d-flex justify-content-end">
                                    <button type="button" id="sendmail" onclick="SendMessage()" class="btn cstmBtnColr">Submit</button>
                                </div>
                                 <div id="sucess" style="display:none;margin-top:20px" class="alert alert-success" role="alert">
 Message Succefully Send
</div>
                            </form>
                        </div>
                        <div class="col-12 col-md-6 col-xxl-5 d-flex align-items-center ms-auto">
                            <div class="w-100">
                                <h2 class="subHead">Begin your <span>journey with us.</span></h2>
                                <p class="addText mb-4">We are ready to help your nikah dream come true..!</p>
                                <div class="d-flex align-items-center mb-4">
                                    <div class="flex-shrink-0">
                                        <img src="<?php echo base_url(); ?>assets/images/address.png" alt="address" class="icon">
                                    </div>
                                    <div class="flex-grow-1 ms-3">
                                        <p class="addText mb-0">A Venture of Sysol System Solutions Pvt Ltd. 4th Floor Neospace. Kinfra Techno industrial Park, Kakkanchery, Thenhipalam, Kerala 673635.</p>
                                    </div>
                                </div>
                                <div class="d-flex align-items-center mb-4">
                                    <div class="flex-shrink-0">
                                        <img src="<?php echo base_url(); ?>assets/images/telephone.png" alt="telephone" class="icon">
                                    </div>
                                    <div class="flex-grow-1 ms-3">
                                        <p class="mobText mb-0">+918593999888</p>
                                    </div>
                                </div>
                                <div class="d-flex align-items-center">
                                    <div class="flex-shrink-0">
                                        <img src="<?php echo base_url(); ?>assets/images/mail.png" alt="mail" class="icon">
                                    </div>
                                    <div class="flex-grow-1 ms-3">
                                        <p class="addText mb-0">info@happynikah.com</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section id="footer">
        <div class="container">
            <div class="row">
                <div class="col-12 col-md-4 mb-5 mb-md-0">
                    <img src="<?php echo base_url(); ?>assets/images/HappyNikah.png" alt="Happy Nikah" class="flogo" width="auto" height="auto">
                    <p class="para1">Happy Nikah is an exclusive matrimonial website for Muslims to make happy lives. We are ready to help Muslims to find their suitable life partner in an Islamic way. Happynikah.com will make your matrimonial searches and online-match making a simple, easy and happy experience.</p>
                </div>
                <div class="col-12 col-md-1">
                </div>
                <div class="col-12 col-md-3 mb-5 mb-md-0">
                    <h2>Quick Links</h2>
                    <ul class="flinks"> 
                        <li>
                            <a href="https://www.happynikah.com">Register</a>
                        </li>
                        <li>
                            <a href="<?php echo site_url('user/about');?>">About Us</a>
                        </li>
                        <li>
                            <a href="<?php echo site_url('user/terms');?>">Terms of Use</a>
                        </li>
                        <li>
                            <a href="<?php echo site_url('user/privacy');?>">Privacy Policy</a>
                        </li>
                    </ul>
                </div>
                <div class="col-12 col-md-4">
                    <h2>Follow us</h2>
                    <ul class="socialIcons d-flex">
                        <li>
                            <a href="https://www.facebook.com/happynikahmatrimony">
                                <img src="<?php echo base_url(); ?>assets/images/fb.png" alt="facebook" class="socialLoogo" width="auto" height="auto">
                            </a>
                        </li>
                        <li>
                            <a href="https://www.instagram.com/happynikahmatrimony/">
                                <img src="<?php echo base_url(); ?>assets/images/instagram.png" alt="instagram" class="socialLoogo" width="auto" height="auto">
                            </a>
                        </li>
                        <!--<li>-->
                        <!--    <a href="javascript:void(0)">-->
                        <!--        <img src="<?php echo base_url(); ?>assets/images/twitter.png" alt="twitter" class="socialLoogo" width="auto" height="auto">-->
                        <!--    </a>-->
                        <!--</li>-->
                        <li>
                            <a href="javascript:void(0)">
                                <img src="<?php echo base_url(); ?>assets/images/youtube.png" alt="youtube" class="socialLoogo" width="auto" height="auto">
                            </a>
                        </li>
                    </ul>
                    <h3>Download App</h3>
                    <div class="d-flex">
                        <a href="javascript:void(0)">
                            <img src="<?php echo base_url(); ?>assets/images/appleStoreF.png" alt="appleStore" class="storeIcon me-3" width="auto" height="auto">
                        </a>
                        <a href="javascript:void(0)">
                            <img src="<?php echo base_url(); ?>assets/images/playStoreF.png" alt="playStore" class="storeIcon" width="auto" height="auto">
                        </a>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-12 text-center">
                    <p class="at">© 2022 Happy Nikah All Rights Reserved</p>
                </div>
            </div>
        </div>
    </section>


    <!-- login Modal -->
    <div class="modal fade" id="loginModal" tabindex="-1" aria-labelledby="loginModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg">
            <div class="modal-content">
                <div class="modal-body p-0">
                    <div class="row">
                        <div class="col-12 col-lg-6 d-none d-lg-flex align-items-stretch">
                            <div class="leftBox w-100">
                                <h2 class="modalHead mb-4" id="loginModalLabel">Search Profiles<br><span>Anytime! Anywhere!!</span></h2>
                                <p class="lpone">Finding your perfect match has never been easier with the Gotonikah application</p>
                                <p class="lptwo">Download now and communicate with muslim matches on-the-go!</p>
                                <div class="d-flex justify-content-center">
                                    <a href="javascript:void(0)">
                                        <img src="<?php echo base_url(); ?>assets/images/appleStore.png" alt="appleStore" class="storeIcon me-3" width="auto" height="auto">
                                    </a>
                                    <a href="javascript:void(0)">
                                        <img src="<?php echo base_url(); ?>assets/images/playStore.png" alt="playStore" class="storeIcon" width="auto" height="auto">
                                    </a>
                                </div>
                            </div>
                        </div>
                        <div class="col-12 col-lg-6 d-flex align-items-stretch">
                            <div class="rbox w-100">
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                <div class="d-flex justify-content-between mb-5">
                                    <h3 class="welcomeHead">Welcome Back!<br><span>Please Login</span></h3>
                                    <img src="<?php echo base_url(); ?>assets/images/logo.png" alt="go to Nikah" class="llogo" width="auto" height="auto">
                                </div>
                                <div class="emailLogBox">
                                    <form class="customForm">
                                        <div class="mb-3">
                                            <input type="text" name="" class="form-control" placeholder="Username/email">
                                        </div>
                                        <div class="mb-3">
                                            <input type="password" name="" class="form-control" placeholder="Password">
                                        </div>
                                        <p class="note">By continuing, you agree to Happynikah's <a href="<?php echo base_url('user/terms');?>">Terms of Use</a> and <a href="<?php echo base_url('user/privacy');?>">Privacy Policy.</a></p>
                                        <button type="button" class="btn cstmBtnColr w-100" onclick="window.location.href='home.html'">Login</button>
                                        <p class="orTxt">OR</p>
                                        <button type="button" class="btn w-100 mb-3 loginOtpBtn">OTP Login</button>
                                    </form>
                                </div>
                                <div class="otpLogBox" style="display:none;">
                                    <form class="customForm">
                                        <div class="mb-3">
                                            <input type="text" name="" class="form-control" placeholder="Mobile Number/Email">
                                        </div>
                                        <p class="note">By continuing, you agree to Gotonikkah's <a href="<?php echo site_url('user/terms');?>">Terms of Use</a> and <a href="<?php echo site_url('user/privacy');?>">Privacy Policy.</a></p>
                                        <button type="button" class="btn cstmBtnColr sendOtp w-100">Send OTP</button>
                                        <p class="orTxt">OR</p>
                                        <button type="button" class="btn w-100 mb-3 loginEmailBtn">Email Login</button>
                                    </form>
                                </div>
                                <div class="otpsendBox" style="display:none;">
                                    <form class="customForm">
                                        <div class="mb-3">
                                            <label class="form-label">Enter Your OTP</label>
                                            <div class="otpInputs">
                                                <input type="text" class="form-control" maxlength="1">
                                                <input type="text" class="form-control" maxlength="1">
                                                <input type="text" class="form-control" maxlength="1">
                                                <input type="text" class="form-control" maxlength="1">
                                                <input type="text" class="form-control" maxlength="1">
                                                <input type="text" class="form-control" maxlength="1">
                                            </div>
                                        </div>
                                        <button type="button" class="btn cstmBtnColr w-100" onclick="window.location.href='home.html'">Submit</button>
                                        <p class="note text-center mb-1"><a href="javascript:void(0)">Send the Code Again</a></p>
                                        <p class="note text-center mb-4"><a href="javascript:void(0)">Change Mobile Number/Emial</a></p>
                                        <button type="button" class="btn w-100 mb-3 loginEmailBtn">Email Login</button>
                                    </form>
                                </div>
                                <div class="d-flex justify-content-between mb-3">
                                    <a href="https://www.facebook.com/happynikahmatrimony" class="regWtFb">
                                        <img src="<?php echo base_url(); ?>assets/images/fb2.png" alt="facebook" width="auto" height="auto">
                                        <span>Facebook</span>
                                    </a>
                                    <a href="https://www.instagram.com/happynikahmatrimony/" class="regWtgoogle">
                                        <img src="<?php echo base_url(); ?>assets/images/google.png" alt="google" width="auto" height="auto">
                                        <span>Google</span>
                                    </a>
                                </div>
                                <p class="text-center newtoTxt">New to Happy Nikkah <a href="https://www.happynikah.com">Register Now</a></p>
                            </div>
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script type="text/javascript" src="assets/js/jquery-3.6.0.min.js"></script>
    <script type="text/javascript" src="assets/js/bootstrap.bundle.min.js"></script>

    <script src="assets/js/owl.carousel.js"></script>

    <script type="text/javascript">
        $(document).ready(function () {
            // partner slider
            $(".owl-partner").owlCarousel({
                margin: 25,
                responsiveClass: true,
                nav: false,
                dots: false,
                autoplay: true,
                autoplayHoverPause: false,
                loop:true,
                responsive: {
                    0: {
                        items: 1.2,
                    },
                    576: {
                        items: 1.5,
                    },
                    768: {
                        items: 2.2,
                    },
                    992: {
                        items: 2.5,
                    },
                    1200: {
                        items: 3.2,
                    },
                    1400: {
                        items: 3.5,
                    }
                },
            });
            // partner slider end

            // burger menu
            $(".hamburger").click(function(){
                $(this).toggleClass("is-active");
                $('body').toggleClass("is-scroll-disabled");
            });
            // burger menu end

            // login with otp and email switch
            $(".loginOtpBtn").click(function(){
                $(".emailLogBox").hide();
                $(".otpLogBox").show();
            }); 
            $(".loginEmailBtn").click(function(){
                $(".otpLogBox").hide();
                $(".emailLogBox").show();
            });
            $(".sendOtp").click(function(){
                $(".otpLogBox").hide();
                $(".otpsendBox").show();
            });
        });
        function SendMessage() {
                                                    
                                                    $.ajax({
                                                        url: 'index.php/Home/ContactNow',
                                                        type: "post",
                                                        data: {mail: $("#email").val(), name: $("#name").val(), message: $("#message").val()},
                                                        success: function (response) {
                                                            //alert(response);
                                                            if(response==1){
                                                               // alert('enter');
                                                                $("#sucess").css("display", "block")
                                                            }

                                                           

                                                            // You will get response from your PHP page (what you echo or print)
                                                        },
                                                        // error: function(jqXHR, textStatus, errorThrown) {
                                                        //   console.log(textStatus, errorThrown);
                                                        // }
                                                    });
                                                }
        
    </script>


</body></html>