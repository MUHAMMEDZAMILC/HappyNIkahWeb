<div class="profBalence">
                        <!--<div class="d-flex justify-content-between balenceHead">-->
                        <!--    <span class="head">Your Credit Balance :</span>-->
                        <!--    <button type="button" class="upgrdBtn">-->
                        <!--        <img src="<?php echo base_url() ?>assets/images/crown.png">-->
                        <!--        Upgarde to Premium-->
                        <!--    </button>-->
                        <!--</div>-->
                        <div class="row">
                            <!--<div class="col-12 col-md-6 d-flex align-items-stretch mb-3 mb-md-0">-->

                            <!--    <a href="<?php echo site_url('user/profile') ?>">-->
                            <!--    <div class="balenceBox bdBlue d-flex justify-content-between">-->
                            <!--        <div class="d-flex flex-column justify-content-between">-->
                            <!--            <p>View Profile </p>-->
                            <!--        </div>-->
                            <!--        <div class="d-flex align-items-center">profile-->
                            <!--            <img src="<?php echo base_url() ?>assets/images/animation_500_kzxr3da6.gif">-->
                            <!--        </div>-->
                            <!--    </div>-->
                            <!--    </a>-->
                            <!--</div>-->
                            
                            <div class="col-6 col-md-6 mb-1">
                                <a href="<?php echo site_url('user/profile') ?>">
                                    <div class="d-flex justify-content-center align-items-center profMenuBox profMenuBox1">
                                        <img src="<?php echo base_url() ?>assets/images/animation_500_kzxr3da6.gif">
                                        <span>My Profile</span>
                                    </div>
                                </a>
                            </div>

                            <div class="col-6 col-md-6 mb-1">
                                <a href="<?php echo site_url('user/home') ?>">
                                    <div class="d-flex justify-content-center align-items-center profMenuBox profMenuBox1">
                                        <img src="<?php echo base_url() ?>assets/images/profileIcon.png">
                                        <span>Home</span>
                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="profMenu mb-4">
                        <div class="row">
                            <div class="col-6 col-md-6 mb-1">
                                <a href="<?php echo site_url('user/explore') ?>">
                                    <div class="d-flex justify-content-center align-items-center profMenuBox profMenuBox3">
                                        <img src="<?php echo base_url() ?>assets/images/explore.png">
                                        <span>Explore</span>
                                    </div>
                                </a>
                            </div>
                            <div class="col-6 col-md-6 mb-1">
                                <a href="<?php echo site_url('user/search_profile') ?>">
                                    <div class="d-flex justify-content-center align-items-center profMenuBox profMenuBox2">
                                        <img src="<?php echo base_url() ?>assets/images/search.png">
                                        <span>Search</span>
                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="enrollBox mb-5">
                        <img src="<?php echo base_url() ?>assets/images/enrollImg.jpg" class="enrollImg">
                        
                        <div class="contentBox">
                            <p class="enrollPara">Enroll for the assisted services &amp; enjoy personalized matchmaking</p>
                            <button type="button" class="enrollBtn">Enroll Now</button>
                        </div>
                    </div>