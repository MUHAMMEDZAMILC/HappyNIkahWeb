<!DOCTYPE html>
<!-- saved from url=(0043)http://gotonikah.foxiomit.com/download.html -->
<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	
    <title>Download Happy Nikah Matrimony App | Muslim Marriage Agency in Kerala</title>
    
    <meta name="description" content="Download Happy Nikah, the best matrimony app on the Google Play store and App store, and search for your partner from this muslim marriage agency">

    <link rel="icon" type="image/png" sizes="32x32" href="./assets/images/HappyNikah.png">

    <link rel="preconnect" href="https://fonts.googleapis.com/">
    <link rel="preconnect" href="https://fonts.gstatic.com/" crossorigin="">
    <link href="<?php echo base_url();?>assets/css/css2.css?v=1" rel="stylesheet"> 

    <link rel="stylesheet" href="<?php echo base_url();?>/assets/css/bootstrap.min.css">

    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/owl.carousel.min.css">
    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/owl.theme.default.min.css">

    <link rel="stylesheet" href="<?php echo base_url();?>assets/css/style.css">

    <!-- fotawsome icon link   -->
    <script src="https://kit.fontawesome.com/a6b3ff972a.js" crossorigin="anonymous"></script>



</head>
<body>
    <section id="header">
        <nav class="navbar navbar-expand-lg">
            <div class="container">
                <a class="navbar-brand" href="https://happynikah.com/">
                    <img src="<?php echo base_url();?>assets/images/HappyNikkahwhite.png" alt="Go to Nikah" width="auto" height="auto" class="gotoNikahlogo">
                </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarGoToNikah" aria-controls="navbarGoToNikah" aria-expanded="false" aria-label="Toggle navigation">
                    <div class="hamburger" id="hamburger-1">
                        <span class="line"></span>
                        <span class="line"></span>
                        <span class="line"></span>
                    </div>
                </button>
                <div class="collapse navbar-collapse" id="navbarGoToNikah">
                    <ul class="navbar-nav mx-auto mb-2 mb-lg-0 mt-3 mt-lg-0">
                        <li class="nav-item">
                            <a class="nav-link active" aria-current="page" href="https://happynikah.com/">Home</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="https://happynikah.com/user/about">About us</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="https://happynikah.com/user/download">Download</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="https://happynikah.com/user/contactus">Contact</a>
                        </li>
                    </ul>
                    <!-- <ul class="d-flex logList align-items-center mb-3 mb-lg-0">
                        <li>Already Member</li>
                        <li>
                            <button type="button" class="btn" data-bs-toggle="modal" data-bs-target="#loginModal">Login</button>
                        </li>
                    </ul> -->
                  
                </div>
            </div>
        </nav>
    </section>
    <section id="downloadSearch">
        <div class="container">
            <div class="row">
                <div class="col-12 col-xxl-10 mx-auto">
                    <div class="row">
                        <div class="col-12 col-md-6 col-xl-6 d-flex align-items-center">
                            <div class="w-100">
                                <h2 class="subHead mb-4">Simplify Your Partner Search<br><span>With Fastest Growing & Most Trusted Matrimonial App.</span></h2>
                                <!-- <p class="pOne">Finding your perfect match has never been easier with the Gotonikah application</p> -->
                                <p class="pOne mb-5">Download the perfect matrimony app on the Google Play store and App store to find your perfect partner</p>
                                <div class="d-flex">
                                    <a href="#" data-bs-toggle="modal" data-bs-target="#exampleModalCenter">
                                        <img src="<?php echo base_url();?>assets/images/appleStore.png" alt="appleStore" width="auto" height="auto" class="storeIcon me-3">
                                    </a>
                                    <div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                                        <div class="modal-dialog modal-dialog-centered" role="document">
                                          <div class="modal-content">
                                            <div class="modal-header">
                                              <h5 class="modal-title" id="exampleModalLongTitle">Work in progress &nbsp;&nbsp;<svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" fill="currentColor" class="bi bi-tools" viewBox="0 0 16 16">
                                                <path d="M1 0 0 1l2.2 3.081a1 1 0 0 0 .815.419h.07a1 1 0 0 1 .708.293l2.675 2.675-2.617 2.654A3.003 3.003 0 0 0 0 13a3 3 0 1 0 5.878-.851l2.654-2.617.968.968-.305.914a1 1 0 0 0 .242 1.023l3.27 3.27a.997.997 0 0 0 1.414 0l1.586-1.586a.997.997 0 0 0 0-1.414l-3.27-3.27a1 1 0 0 0-1.023-.242L10.5 9.5l-.96-.96 2.68-2.643A3.005 3.005 0 0 0 16 3c0-.269-.035-.53-.102-.777l-2.14 2.141L12 4l-.364-1.757L13.777.102a3 3 0 0 0-3.675 3.68L7.462 6.46 4.793 3.793a1 1 0 0 1-.293-.707v-.071a1 1 0 0 0-.419-.814L1 0Zm9.646 10.646a.5.5 0 0 1 .708 0l2.914 2.915a.5.5 0 0 1-.707.707l-2.915-2.914a.5.5 0 0 1 0-.708ZM3 11l.471.242.529.026.287.445.445.287.026.529L5 13l-.242.471-.026.529-.445.287-.287.445-.529.026L3 15l-.471-.242L2 14.732l-.287-.445L1.268 14l-.026-.529L1 13l.242-.471.026-.529.445-.287.287-.445.529-.026L3 11Z"/>
                                              </svg> </h5>
                                              
                                              </button>
                                            </div>
                                            <div class="modal-body">
                                              Currently We are working on it 
                                            </div>
                                            <div class="modal-footer">
                                              <!-- <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                              <button type="button" class="btn btn-primary">Save changes</button> -->
                                            </div>
                                          </div>
                                        </div>
                                      </div>
                                    <a href="https://play.google.com/store/apps/details?id=com.sysol.happy_nikah">
                                        <img src="<?php echo base_url();?>assets/images/playStore.png" alt="playStore" width="auto" height="auto" class="storeIcon">
                                    </a>
                                </div>
                            </div>
                        </div>
                        <div class="col-12 col-md-6 col-xl-6  d-flex align-items-center justify-content-center">
                            <div class="appCircle">
                                <img src="<?php echo base_url();?>assets/images/appMob1.png" alt="playStore" width="auto" height="auto" class="appIcon">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section id="aboutApp">
        <div class="container">
            <div class="row">
                <div class="col-12 col-xxl-10 mx-auto">
                    <div class="row">
                        <div class="col-12 col-md-10 col-lg-8 mx-auto text-center">
                            <h2 class="subHead">The Perfect Matchmaking App</h2>
                            <p class="para1 mb-5" align="justify"><i style="padding-bottom: 1px;" class="fa-solid fa-quote-left "></i>
                                If you are urgently looking for a life partner, you can start using the <a href="https://happynikah.com/user/about"> Happy Nikah Matrimony </a> app as soon as possible for free. To experience the features of Happy Nikah, Muslim marriage agency's app get it on the Google Play store and App store. It is the latest and most trustworthy marriage agency to help Muslim bachelors find their spouses. You can enjoy this matrimony app with the uninterrupted features.
                                If you are a Malayalee and you want to search for a partner through the Happy Nikah Muslim marriage agency you can download this matrimonial app and start using it from anywhere in the world. Enjoy finding your pair with the best and easy-to-use interface.
                                <i class="fa-solid fa-quote-right"></i></p>
                        </div>
                    </div>
                    <div class="row mt-3">
                        <div class="col-12 col-md-4 text-center mb-4 mb-md-0 h-103">
                            <div style="height:375px;" class="appFBox">
                                <div class="diamond">
                                    <svg xmlns="http://www.w3.org/2000/svg" class="appFIcons" viewBox="0 0 16 16">
                                        <path d="M5 8a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm4 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm3 1a1 1 0 1 0 0-2 1 1 0 0 0 0 2z"></path>
                                        <path d="m2.165 15.803.02-.004c1.83-.363 2.948-.842 3.468-1.105A9.06 9.06 0 0 0 8 15c4.418 0 8-3.134 8-7s-3.582-7-8-7-8 3.134-8 7c0 1.76.743 3.37 1.97 4.6a10.437 10.437 0 0 1-.524 2.318l-.003.011a10.722 10.722 0 0 1-.244.637c-.079.186.074.394.273.362a21.673 21.673 0 0 0 .693-.125zm.8-3.108a1 1 0 0 0-.287-.801C1.618 10.83 1 9.468 1 8c0-3.192 3.004-6 7-6s7 2.808 7 6c0 3.193-3.004 6-7 6a8.06 8.06 0 0 1-2.088-.272 1 1 0 0 0-.711.074c-.387.196-1.24.57-2.634.893a10.97 10.97 0 0 0 .398-2z"></path>
                                    </svg>
                                </div>
                                <h3>24/7 Support</h3>
                                <p align="center">We always value our customers, so we have a dedicated support team to provide 24/7 online support for your concerns.</p>
                            </div>
                        </div>
                        <div class="col-12 col-md-4 text-center mb-4 mb-md-0 h-103">
                            <div style="height:377px;" class="appFBox">
                                <div class="diamond">
                                    <svg xmlns="http://www.w3.org/2000/svg" class="appFIcons" viewBox="0 0 16 16">
                                        <path d="M8 1a2 2 0 0 1 2 2v4H6V3a2 2 0 0 1 2-2zm3 6V3a3 3 0 0 0-6 0v4a2 2 0 0 0-2 2v5a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2zM5 8h6a1 1 0 0 1 1 1v5a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V9a1 1 0 0 1 1-1z"></path>
                                    </svg>
                                </div>
                                <h3>Data Privacy</h3>
                                <p align="center">We provide you with 100% security. Whatever information you share with us always remains confidential. We never disclose your information to anyone without your permission.</p>
                            </div>
                        </div>
                        <div class="col-12 col-md-4 text-center mb-4 mb-md-0">
                            <div class="appFBox">
                                <div class="diamond">
                                    <svg xmlns="http://www.w3.org/2000/svg" class="appFIcons" viewBox="0 0 16 16">
                                        <path d="M.5 9.9a.5.5 0 0 1 .5.5v2.5a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-2.5a.5.5 0 0 1 1 0v2.5a2 2 0 0 1-2 2H2a2 2 0 0 1-2-2v-2.5a.5.5 0 0 1 .5-.5z"></path>
                                        <path d="M7.646 11.854a.5.5 0 0 0 .708 0l3-3a.5.5 0 0 0-.708-.708L8.5 10.293V1.5a.5.5 0 0 0-1 0v8.793L5.354 8.146a.5.5 0 1 0-.708.708l3 3z"></path>
                                    </svg>
                                </div>
                                <h3>Easy Download</h3>
                                <p align="center">Our app is one of the best user-friendly matrimonial apps in the market. The best advantages of working with our app is that we have a big database of each bride and groom's profiles. Therefore, you could get access to a broad variety of profiles.</p>
                            </div>
                        </div>
                        
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section id="appFeatures">
        <div class="container">
            <div class="row">
                <div class="col-12 col-xxl-10 mx-auto">
                    <div class="row">
                        <div class="col-12 col-md-10 col-lg-8 mx-auto text-center">
                            <h2 class="subHead">Our Features</h2>
                            <p class="para1 mb-5"></p>
                        </div>
                    </div>
                    <div class="row mt-5">
                        <div class="col-12 col-md-6 col-lg-5 d-flex align-items-center justify-content-center mb-4 mb-md-0">
                            <img src="<?php echo base_url();?>assets/images/1507.png" class="appScreen1" alt="app screen">
                        </div>
                        <div class="col-12 col-md-6 col-lg-7 d-flex align-items-center mb-4 mb-md-0">
                            <div class="w-100">
                                <div class="fBox d-flex">
                                    <div class="fIconBox">
                                        <img src="<?php echo base_url();?>assets/images/handshake.svg" alt="">
                                    </div>
                                    <div class="fContentBox">
                                        <h3>User Friendly</h3>
                                        <p>We have our own unique app interface that makes our apps more comfortable for the users. From registration to matchmaking, we consider each step to create this unique interface.</p>
                                    </div>
                                </div>
                                <div class="fBox d-flex">
                                    <div class="fIconBox">
                                        <img src="<?php echo base_url();?>assets/images/simple.svg" alt="">
                                    </div>
                                    <div class="fContentBox">
                                        <h3>Simple Registration</h3>
                                        <p>Registering with this matrimonial app is very simple. You only need to update your primary facts like name, gender, age, e-mail address, and phone number to start with. Filling in mandatory fields helps to get the best matching profiles</p>
                                    </div>
                                </div>
                                <div class="fBox d-flex">
                                    <div class="fIconBox">
                                        <img src="<?php echo base_url();?>assets/images/secure.svg" alt="">
                                    </div>
                                    <div class="fContentBox">
                                        <h3>100 % Secured </h3>
                                        <p>We assure 100 % data security to our users. The complete information that you have shared with us is always secure and safe. We don’t share your information with anyone without your permission.</p>
                                    </div>
                                </div>
                                <div class="fBox d-flex">
                                    <div class="fIconBox">
                                        <img src="<?php echo base_url();?>assets/images/verified.svg" alt="">
                                    </div>
                                    <div class="fContentBox">
                                        <h3>Verified Profiles</h3>
                                        <p>We are more concerned about each and every registration of our matrimony. Only verified profiles are allowed to be listed on our matrimony and we have a dedicated team to review each profile manually</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section id="talkUser">
        <img src="<?php echo base_url();?>assets/images/wave.png" class="w-100">
        <!-- <div class="container">
            <div class="row">
                <div class="col-12 col-xl-10 mx-auto">
                    <div class="row">
                        <div class="col-12 col-md-10 col-lg-8 mx-auto text-center">
                            <h2 class="subHead mb-5">SOME TALK OF OUR USERS</h2>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-12">
                            <div class="owl-userTalk owl-carousel owl-theme owl-loaded owl-drag">
                                
                                
                                
                            <div class="owl-stage-outer"><div class="owl-stage" style="transform: translate3d(-550px, 0px, 0px); transition: all 0.25s ease 0s; width: 1652px;"><div class="owl-item" style="width: 525.5px; margin-right: 25px;"><div class="item">
                                    <div class="tstiBox">
                                        <div class="imgCircle">
                                            <img src="./download_files/myProfile2.png">
                                        </div>
                                        <h3 class="nameHead">OLIVER GOMEZ</h3>
                                        <p class="desgntn">CEO of google</p>
                                        <p class="testiPara">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,good.</p>
                                    </div>
                                </div></div><div class="owl-item active" style="width: 525.5px; margin-right: 25px;"><div class="item">
                                    <div class="tstiBox">
                                        <div class="imgCircle">
                                            <img src="./assets/images/myProfile2.png">
                                        </div>
                                        <h3 class="nameHead">OLIVER GOMEZ</h3>
                                        <p class="desgntn">CEO of google</p>
                                        <p class="testiPara">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,good.</p>
                                    </div>
                                </div></div><div class="owl-item active" style="width: 525.5px; margin-right: 25px;"><div class="item">
                                    <div class="tstiBox">
                                        <div class="imgCircle">
                                            <img src="./assets/images/myProfile2.png">
                                        </div>
                                        <h3 class="nameHead">OLIVER GOMEZ</h3>
                                        <p class="desgntn">CEO of google</p>
                                        <p class="testiPara">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,good.</p>
                                    </div>
                                </div></div></div></div><div class="owl-nav disabled"><button type="button" role="presentation" class="owl-prev"><span aria-label="Previous"><img src="./download_files/chevron-l.png"></span></button><button type="button" role="presentation" class="owl-next"><span aria-label="Next"><img src="./download_files/chevron-r.png"></span></button></div><div class="owl-dots"><button role="button" class="owl-dot"><span></span></button><button role="button" class="owl-dot active"><span></span></button></div></div>
                        </div>
                    </div>
                </div>
            </div> -->
        </div>
    </section>
    
    <section id="footer">
        <div class="container">
            <div class="row">
                <div class="col-12 col-md-4 mb-5 mb-md-0">
                    <!-- <img src="./assets/images/logo.png" alt="go to Nikah" width="auto" height="auto" class="flogo"> -->
                    <img src="<?php echo base_url();?>assets/images/HappyNikah.png" alt="Happy nikkah" width="auto" height="auto" class="flogo">
                    <p class="para1" align="justify">Happy Nikah is an exclusive matrimonial website for Muslims to make happy lives. We are ready to help Muslims to find their suitable life partner in an Islamic way. Happynikah.com will make your matrimonial searches and online-match making a simple, easy and happy experience.</p>
                </div>
                <div class="col-12 col-md-1">
                </div>
                <div class="col-12 col-md-3 mb-5 mb-md-0">
                    <h2>Quick Links</h2>
                    <ul class="flinks"> 
                        <li>
                            <a href="https://happynikah.com/">Register</a>
                        </li>
                        <li>
                            <a href="https://happynikah.com/user/about">About Us</a>
                        </li>
                        <li>
                            <a href="https://happynikah.com/user/terms">Terms and condition</a>
                        </li>
                        <li>
                            <a href="https://happynikah.com/user/privacy">Privacy Policy</a>
                        </li>
                    </ul>
                </div>
                <div class="col-12 col-md-4">
                    <h2>Follow us</h2>
                    <ul class="socialIcons d-flex">
                        <li>
                            <a href="https://www.facebook.com/happynikahmatrimony">
                                <img src="<?php echo base_url();?>assets/images/fb.png" alt="facebook" width="auto" height="auto" class="socialLoogo">
                            </a>
                        </li>
                        <li>
                            <a href="https://www.instagram.com/happynikahmatrimony">
                                <img src="<?php echo base_url();?>assets/images/instagram.png" alt="instagram" width="auto" height="auto" class="socialLoogo">
                            </a>
                        </li>
                        <!-- <li>
                            <a href="javascript:void(0)">
                                <img src="./assets/images/twitter.png" alt="twitter" width="auto" height="auto" class="socialLoogo">
                            </a>
                        </li> -->
                        <li>
                            <a href="https://www.youtube.com/channel/UCbZ6wkcWuVxDBCDG5AGRvhQ">
                                <img src="<?php echo base_url();?>assets/images/youtube.png" alt="youtube" width="auto" height="auto" class="socialLoogo">
                            </a>
                        </li>
                    </ul>
                    <h3>Download App</h3>
                    <div class="d-flex">
                        <a href="#" data-bs-toggle="modal" data-bs-target="#exampleModalCenter">
                            <img src="<?php echo base_url();?>assets/images/appleStoreF.png" alt="appleStore" width="auto" height="auto" class="storeIcon me-3">
                        </a>
                        <a href="https://play.google.com/store/apps/details?id=com.sysol.happy_nikah">
                            <img src="<?php echo base_url();?>assets/images/playStoreF.png" alt="playStore" width="auto" height="auto" class="storeIcon">
                        </a>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-12 text-center">
                    <p class="at">© 2022 gotonikah All Rights Reserved</p>
                </div>
            </div>
        </div>
    </section>


    <!-- login Modal -->
    <div class="modal fade" id="loginModal" tabindex="-1" aria-labelledby="loginModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg">
            <div class="modal-content">
                <div class="modal-body p-0">
                    <div class="row">
                        <div class="col-12 col-lg-6 d-none d-lg-flex align-items-stretch">
                            <div class="leftBox w-100">
                                <h2 class="modalHead mb-4" id="loginModalLabel">Search Profiles<br><span>Anytime! Anywhere!!</span></h2>
                                <p class="lpone">Finding your perfect match has never been easier with the Gotonikah application</p>
                                <p class="lptwo">Download now and communicate with muslim matches on-the-go!</p>
                                <div class="d-flex justify-content-center">
                                    <a href="#" data-bs-toggle="modal" data-bs-target="#exampleModalCenter">
                                        <img src="<?php echo base_url();?>assets/images/appleStore.png" alt="appleStore" class="storeIcon me-3" width="auto" height="auto">
                                    </a>
                                    <a href="javascript:void(0)">
                                        <img src="<?php echo base_url();?>assets/images/playStore.png" alt="playStore" class="storeIcon" width="auto" height="auto">
                                    </a>
                                </div>
                            </div>
                        </div>
                        <div class="col-12 col-lg-6 d-flex align-items-stretch">
                            <div class="rbox w-100">
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                <div class="d-flex justify-content-between mb-5">
                                    <h3 class="welcomeHead">Welcome Back!<br><span>Please Login</span></h3>
                                    <img src="<?php echo base_url();?>assets/images/logo.png" alt="go to Nikah" class="llogo" width="auto" height="auto">
                                </div>
                                <div class="emailLogBox">
                                    <form class="customForm">
                                        <div class="mb-3">
                                            <input type="text" name="" class="form-control" placeholder="Username/email">
                                        </div>
                                        <div class="mb-3">
                                            <input type="password" name="" class="form-control" placeholder="Password">
                                        </div>
                                        <p class="note">By continuing, you agree to HappyNikah's <a href="<?php echo site_url('user/terms');?>">Terms of Use</a> and <a href="http://gotonikah.foxiomit.com/privacy.html">Privacy Policy.</a></p>
                                        <button type="button" class="btn cstmBtnColr w-100" onclick="window.location.href=&#39;home.html&#39;">Login</button>
                                        <p class="orTxt">OR</p>
                                        <button type="button" class="btn w-100 mb-3 loginOtpBtn">OTP Login</button>
                                    </form>
                                </div>
                                <div class="otpLogBox" style="display:none;">
                                    <form class="customForm">
                                        <div class="mb-3">
                                            <input type="text" name="" class="form-control" placeholder="Mobile Number/Email">
                                        </div>
                                        <p class="note">By continuing, you agree to Gotonikkah's <a href="<?php echo site_url('user/terms');?>">Terms of Use</a> and <a href="http://gotonikah.foxiomit.com/privacy.html">Privacy Policy.</a></p>
                                        <button type="button" class="btn cstmBtnColr sendOtp w-100">Send OTP</button>
                                        <p class="orTxt">OR</p>
                                        <button type="button" class="btn w-100 mb-3 loginEmailBtn">Email Login</button>
                                    </form>
                                </div>
                                <div class="otpsendBox" style="display:none;">
                                    <form class="customForm">
                                        <div class="mb-3">
                                            <label class="form-label">Enter Your OTP</label>
                                            <div class="otpInputs">
                                                <input type="text" class="form-control" maxlength="1">
                                                <input type="text" class="form-control" maxlength="1">
                                                <input type="text" class="form-control" maxlength="1">
                                                <input type="text" class="form-control" maxlength="1">
                                                <input type="text" class="form-control" maxlength="1">
                                                <input type="text" class="form-control" maxlength="1">
                                            </div>
                                        </div>
                                        <button type="button" class="btn cstmBtnColr w-100" onclick="window.location.href=&#39;home.html&#39;">Submit</button>
                                        <p class="note text-center mb-1"><a href="javascript:void(0)">Send the Code Again</a></p>
                                        <p class="note text-center mb-4"><a href="javascript:void(0)">Change Mobile Number/Emial</a></p>
                                        <button type="button" class="btn w-100 mb-3 loginEmailBtn">Email Login</button>
                                    </form>
                                </div>
                                <div class="d-flex justify-content-between mb-3">
                                    <a href="javascript:void(0)" class="regWtFb">
                                        <img src="<?php echo base_url();?>assets/images/fb2.png" alt="facebook" width="auto" height="auto">
                                        <span>Facebook</span>
                                    </a>
                                    <a href="javascript:void(0)" class="regWtgoogle">
                                        <img src="<?php echo base_url();?>assets/images/google.png" alt="google" width="auto" height="auto">
                                        <span>Google</span>
                                    </a>
                                </div>
                                <p class="text-center newtoTxt">New to Happy Nikah <a href="https://www.happynikah.com">Register Now</a></p>
                            </div>
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script type="text/javascript" src="<?php echo base_url();?>assets/js/jquery-3.6.0.min.js"></script>
    <script type="text/javascript" src="<?php echo base_url();?>assets/js/bootstrap.bundle.min.js"></script>

    <script src="<?php echo base_url();?>assets/js/owl.carousel.js"></script>

    <script type="text/javascript">
        $(document).ready(function () {
            // partner slider
            $(".owl-userTalk").owlCarousel({
                margin: 25,
                responsiveClass: true,
                nav: false,
                dots: true,
                autoplay: true,
                autoplayHoverPause: true,
                loop:false,
                responsive: {
                    0: {
                        items: 1,
                    },
                    576: {
                        items: 1,
                    },
                    767: {
                        items: 2,
                    }
                },
            });
            // partner slider end

            // burger menu
            $(".hamburger").click(function(){
                $(this).toggleClass("is-active");
                $('body').toggleClass("is-scroll-disabled");
            });
            // burger menu end

            // login with otp and email switch
            $(".loginOtpBtn").click(function(){
                $(".emailLogBox").hide();
                $(".otpLogBox").show();
            }); 
            $(".loginEmailBtn").click(function(){
                $(".otpLogBox").hide();
                $(".emailLogBox").show();
            });
            $(".sendOtp").click(function(){
                $(".otpLogBox").hide();
                $(".otpsendBox").show();
            });
        });
        
    </script>


</body></html>