<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Appservicemodel extends CI_Model {

    function __construct() {
        $this->load->database();
       
    }

    public function InsertReg() {
        ini_set('display_errors', 1);
        ini_set('display_startup_errors', 1);
        error_reporting(E_ALL);
        $json = file_get_contents('php://input');
        //print_r($json);
        //echo "Name:".$json["Name"];
        $data = json_decode($json, true);

        //print_r($data);
        if (isset($data['user_id']) && $data['user_id'] != "") {

            $this->db->select("COLUMN_NAME");
            $this->db->from("INFORMATION_SCHEMA.COLUMNS");
            $this->db->where("TABLE_NAME", "tbl_registration");
            $result = $this->db->get();

            $arr_reg = array();
            foreach ($result->result() as $row) {
                // echo $key."=".$value."</br>";
                $key = $row->COLUMN_NAME;
                if (isset($data[$key])) {

                    $arr_reg[$key] = $data[$key];
                }
            }
            //print_r($arr_reg);
            //echo "</br>";
            //die('ere');
            if (count($arr_reg) > 0) {
                //$reg_data['stage']=2;
                $this->db->where("id", $data['user_id']);
                $this->db->update("tbl_registration", $arr_reg);
            }
            $this->db->select("COLUMN_NAME");
            $this->db->from("INFORMATION_SCHEMA.COLUMNS");
            $this->db->where("TABLE_NAME", "tbl_otherdetails");
            $res = $this->db->get();
            $arr_other = array();
            foreach ($res->result() as $row) {
                // echo $key."=".$value."</br>";
                $key = $row->COLUMN_NAME;
                if (isset($data[$key])) {

                    $arr_other[$key] = $data[$key];
                }
            }
            if (count($arr_other) > 0) {
                //$reg_data['stage']=3;
                $this->db->where("user_id", $data['user_id']);
                $this->db->update("tbl_otherdetails", $arr_other);
                
                // $arstage['stage']=3;
                // $this->db->where("id",$data['user_id']);
                // $this->db->update("tbl_registration",$arstage);
            }
            $this->db->select("COLUMN_NAME");
            $this->db->from("INFORMATION_SCHEMA.COLUMNS");
            $this->db->where("TABLE_NAME", "tbl_familyprofile");
            $resfamily = $this->db->get();
            $arr_family = array();
            foreach ($resfamily->result() as $row) {
                // echo $key."=".$value."</br>";
                $key = $row->COLUMN_NAME;
                if (isset($data[$key])) {

                    $arr_family[$key] = $data[$key];
                }
            }

//            print_r($arr_family);
//            die('ere');
            if (count($arr_family) > 0) {
                $this->db->select("*");
                $this->db->where("user_id", $data['user_id']);
                $row = $this->db->get("tbl_familyprofile");
                //$reg_data['stage']=4;
                if ($row->num_rows() > 0) {
                    $this->db->where("user_id", $data['user_id']);
                    $this->db->update("tbl_familyprofile", $arr_family);
                } else {
                    //$this->db->where("user_id", $data['id']);
                    $this->db->insert("tbl_familyprofile", $arr_family);
                }
                
                // $this->db->where("id",$data['user_id']);
                // $this->db->update("tbl_registration",$arstage);
            }
            $jsondata = array();
            $jsondata['user_id'] = (int) $data['user_id'];
            return json_encode($jsondata);
        } else {


            $reg_data = $data;
            unset($reg_data["aboutme"]);
            unset($reg_data["partner_expectation"]);
            $reg_data['dob'] = date('Y-m-d', strtotime($reg_data['dob']));
            $from = new DateTime($reg_data['dob']);
            $to = new DateTime('today');
            $reg_data['age'] = $from->diff($to)->y;
            if (isset($reg_data['gender']) && $reg_data['gender'] == 'Female') {
                $reg_data['gender'] = 2;
            } else if (isset($reg_data['gender']) && $reg_data['gender'] == 'Male') {
                $reg_data['gender'] = 1;
            }
            $reg_data['reg_date']=date('Y-m-d');
            $reg_data['reg_through']=2;
            $reg_data['stage']=1;
            $this->db->insert("tbl_registration", $reg_data);

            $insert_id = $this->db->insert_id();

            $loginDetails['username'] = $reg_data['phone'];
            $password = 'HN' . rand(10, 10000);
            $loginDetails['password'] = md5($password);
            $loginDetails['user_id'] = $insert_id;
            $this->db->insert("tbl_userlogin", $loginDetails);
            //$this->General_Model->AddRecord('tbl_userlogin', $loginDetails);
            $msg = 'You%20have%20successfully%20initiated%20registration%20in%20happynikah.com.%20UserID:' . $reg_data['phone'] . '%20Password:' . $password . '%20Please%20login%20and%20complete%20your%20profile.SYSOL%20SYSTEM%20SOLUTIONS%20PRIVATE%20LIMITED';
            $this->smsotp($msg, (($reg_data["countryCode"]!="0")?$reg_data["countryCode"]:"91") . $reg_data['phone'], 2, "", "");

            $otherdetails = array();
            $otherdetails['user_id'] = $insert_id;
            $otherdetails['aboutme'] = $data['aboutme'];
            $this->db->insert('tbl_otherdetails', $otherdetails);
            $jsondata = array();
            $jsondata['user_id'] = $otherdetails['user_id'];
            return json_encode($jsondata);
        }
    }

    function VerifyOTP() {

        $json = file_get_contents('php://input');
        $data = json_decode($json, true);
        $this->db->select("r.id,o.otp,o.otp_time");
        $this->db->from("tbl_registration r");
        $this->db->join("tbl_otp o", "r.id=o.user_id");
        $this->db->where("r.phone", $data['phone']);
        $this->db->where("o.otp", $data['otp']);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            $arrdata = $query->row_array();
            $otptime = new DateTime($arrdata['otp_time']);
            $currtime = new DateTime(date("Y-m-d H:m:s"));
            $d1 = strtotime($arrdata['otp_time']);
            $d2 = strtotime(date("Y-m-d H:i:s"));
            $totalSecondsDiff = abs($d2 - $d1);
            //echo $arrdata['otp_time']." ";
            //echo date("Y-m-d H:i:s");
            $totalminute = $totalSecondsDiff / 60;
            //return $totalminute;
            // echo $otptime->format("%Y-m-d");
            // echo $currtime;

            $interval = $otptime->diff($currtime);
            if ($data['phone'] == "7907735451" && $data['otp'] == "432197") {
                $jsondata = array();
                $jsondata['user_id'] = (int) $arrdata['id'];
                return json_encode($jsondata);
            } else {
                if ((int) $totalminute < 10) {
                    $jsondata = array();
                    $jsondata['user_id'] = (int) $arrdata['id'];
                    return json_encode($jsondata);
                } else {
                    $jsondata = array();
                    $jsondata['user_id'] = -1;
                    return json_encode($jsondata);
                }
            }
        } else {
            $jsondata = array();
            $jsondata['user_id'] = 0;
            return json_encode($jsondata);
        }
    }

    function smsotp($msg, $mobile, $mode, $otp, $name) {
        
        $templateid = 1607100000000205213;
        if ($mode == 4) {
            $templateid = 1607100000000129109;
            $url='https://2factor.in/API/R1/?module=TRANS_SMS&apikey=7a8571c8-ed69-11ec-9c12-0200cd936042&to='.$mobile.'&from=SYSOLS&templatename=OTP+Template&var1='.$otp.'&var2='.$name.'&var3=happynikah.com';
            //$url = 'http://sms.sysol.in/api/api.php?ver=1&mode=1&action=push_sms&type=1&route=2&login_name=Sysolsystemsolutions&api_password=9d61ac8866c76e24cdde&message=' . $msg . '&number=' . $mobile . '&sender=SYSOLS&template_id=' . $templateid;
        } else {
            $url = 'http://sms.sysol.in/api/api.php?ver=1&mode=1&action=push_sms&type=1&route=2&login_name=Sysolsystemsolutions&api_password=9d61ac8866c76e24cdde&message=' . $msg . '&number=' . $mobile . '&sender=SYSOLS&template_id=' . $templateid;
        }




        // echo $url;
        file_get_contents($url);

        return 1;
    }

    public function MemDetails() {
        $id = $_GET['mode'];
        $this->db->select("name,age,ifnull(h.height,'') height,ifnull(sub_caste,'') belief,case when native_place='null' then '' else  native_place end native_place,ifnull(d.district,'') native_district,ifnull(job_name,'') job,case when r.photo='' then case when r.gender='1' then 'male.jpg' else 'female.jpg' end  else r.photo end photo,r.phone");
        $this->db->from("tbl_registration r");
        $this->db->join("tbl_subcaste c", "c.sid=r.caste", "left");
        $this->db->join("tbl_jobs j", "j.job_id=r.occupation", "left");
        $this->db->join("tbl_district d", "d.district_id=r.native_district", "left");
        $this->db->join("tbl_height h", "h.height_id=r.height", "left");
        $this->db->where("r.id", $id);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            $json = $query->row_array();
        } else {
            $json["error"] = true;
            $json["error_msg"] = "Data Not Found";
        }
        return json_encode($json);
    }

    public function UserBasic() {
        $id = $_GET['mode'];
        $userid = $_GET['m'];

        $this->db->select("r.id,name,age,ifnull(h.height,'') height,ifnull(sub_caste,'') belief,native_place,ifnull(d.district,'') native_district,ifnull(job_name,'') job,case when r.photo='' then case when r.gender='1' then 'male.jpg' else 'female.jpg' end  else r.photo end photo,ifnull(s.shortlist_id,0) shortlist,ifnull(i.interest_id,0) interest,ifnull(l.like_id,0) liked,r.phone,case when p.status=1 then 'Public' else r.photo_visibility end photo_visibility");
        $this->db->from("tbl_registration r");
        $this->db->join("tbl_subcaste c", "c.sid=r.caste", "left");
        $this->db->join("tbl_jobs j", "j.job_id=r.occupation", "left");
        $this->db->join("tbl_district d", "d.district_id=r.native_district", "left");
        $this->db->join("tbl_height h", "h.height_id=r.height", "left");
        $this->db->join("tbl_shortlist s", "s.receiver_id=r.id and s.sender_id=" . $userid, "left");
        $this->db->join("tbl_interest i", "i.receiver_id=r.id and i.sender_id=" . $userid, "left");
        $this->db->join("tbl_like l", "l.receiver_id=r.id and l.sender_id=" . $userid, "left");
        $this->db->join("tbl_photorequest p","p.receiver_id=r.id and p.sender_id=".$userid,"left");
        $this->db->where("r.id", $id);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            $json = $query->row_array();
        } else {
            $json["error"] = true;
            $json["error_msg"] = "Data Not Found";
        }
        return json_encode($json);
    }

    public function ProfileInfo() {
        $id = $_GET['mode'];
        $user_id = $_GET['m'];
        $this->db->SELECT("'About' head,o.aboutme,'Basic Information' head1,r.profile_for 'Create By',r.happynikah_id 'Id',r.name 'Name',case when r.gender=1 then 'Male' else 'Female' end 'Gender',r.age 'Age',r.marital_status 'Marital Status',ifnull(m.mothertongue,'') 'Mother Tongue',r.registration_hobbies 'Hobbies',
r.photo_visibility 'Photo Visiblity','Contact Info' head8,1 as contact,'Religious Information' head2,ifnull(rel.religion,'') 'Religion',ifnull(c.caste,'') 'Caste','Professional' head3,ifnull(q.qualification,'') 'Qualification',ifnull(j.job_name,'') 'Job',r.job_category 'Job Status',r.annual_income 'Annual Income','Physical Attribute' head4,ifnull(h.height,'') 'Height',ifnull(w.weight,'') 'Weight',r.color 'Color',r.physical_status 'Physical Status',r.blood_group 'Blood Group','Location' head5,r.native_place 'City/Street',r.pincode 'Pincode',ifnull(d.district,'') 'District',r.state 'State',r.country 'Country','Family' head6,ifnull(f.fathers_name,'') 'Father Name',ifnull(f.fathers_occupation,'') 'Occupation of Father',ifnull(f.mothers_name,'') 'Mother Name',ifnull(f.mothers_occupation,'') 'Occupation of Mother',f.total_members 'Number of family Members',f.financial_status 'Financial Status','Partner Preference' head7,o.partner_age_from,o.partner_age_to,ifnull(o.partner_height,'') partner_height,ifnull(o.partner_height_to,'') 'partner_height_to',ifnull(o.partner_education,'') 'partner_education',
o.partner_familytype ,o.partner_expectation");
        $this->db->from("tbl_registration r");
        $this->db->join("tbl_mothertongue m", "m.mothertongue_id=r.mother_tongue", "left");
        $this->db->join("tbl_religion rel", "rel.rid=r.religion", "left");
        $this->db->join("tbl_caste c", "c.cid=r.caste", "left");
        $this->db->join("tbl_qualification q", "q.qualification_id=r.education", "left");
        $this->db->join("tbl_jobs j", "j.job_id=r.occupation", "left");
        $this->db->join("tbl_height h", "h.height_id=r.height", "left");
        $this->db->join("tbl_weight w", "w.weight_id=r.weight", "left");
        $this->db->join("tbl_district d", "d.district_id=r.native_district", "left");
        $this->db->join("tbl_familyprofile f", "f.user_id=r.id", "left");
        $this->db->join("tbl_otherdetails o", "o.user_id=r.id", "left");
        $this->db->join("tbl_qualification pq", "pq.qualification_id=o.partner_education", "left");
        $this->db->join("tbl_height ph", "ph.height_id=o.partner_height", "left");
        $this->db->join("tbl_height ph_to", "ph_to.height_id=o.partner_height_to", "left");
        $this->db->where("r.id", $id);
        $query = $this->db->get();
        $resutl = $query->row_array();
        // print_r($resutl);
        $arrdata = array();
        $subhead = "";
        $arsub = array();
        foreach ($resutl as $key => $value) {


            if (substr($key, 0, 4) == "head") {
                if (count($arsub) > 0) {
                    $arrdata[count($arrdata)] = array("header" => $subhead);
                    $arvalue = array();
                    foreach ($arsub as $k => $v) {
                        $arvalue[count($arvalue)] = array("key" => $k, "value" => $v);
                    }
                    //print_r($arvalue);
                    //die('ere');
                    $arrdata[count($arrdata) - 1]["value"] = $arvalue;
                    $arsub = array();
                }

                $subhead = $value;
            } else {
                $arsub[$key] = $value;
            }
        }
        if (count($arsub) > 0) {
            $this->db->select("*");
            $this->db->from("tbl_otherdetails");
            $this->db->where("user_id", $user_id);
            $mypref = $this->db->get();
            $mypref = $mypref->row_array();

            //print_r($mypref);
            // print_r($arsub);
            $totcount = 0;
            $prefcount = 0;
            $arrpref = array();
            $arrpref[count($arrpref)] = array("head" => "Age", "title" => $mypref["partner_age_from"] . "-" . $mypref["partner_age_to"], "value" => 0);
            if (isset($arsub["partner_age_from"])) {
                $totcount++;
                //echo $mypref["partner_age_from"]."=".$arsub["partner_age_from"]."</br>";
                if ($arsub["partner_age_from"] >= $mypref["partner_age_from"] || $arsub["partner_age_to"] <= $mypref["partner_age_to"]) {
                    $arrpref[count($arrpref) - 1] = array("head" => "Age", "title" => $mypref["partner_age_from"] . "-" . $mypref["partner_age_to"], "value" => 1);

                    $prefcount++;
                }
            }

            $arrpref[count($arrpref)] = array("head" => "Height", "title" => $this->GetHeightValue($mypref["partner_height"]) . "-" . $this->GetHeightValue($mypref["partner_height_to"]), "value" => 0);
            if (isset($arsub["partner_height"])) {
                $totcount++;
                if ($mypref["partner_height"] >= $arsub["partner_height"] || $mypref["partner_height_to"] < $arsub["partner_height_to"]) {
                    $arrpref[count($arrpref) - 1] = array("head" => "height", "title" => $this->GetHeightValue($mypref["partner_height"]) . "-" . $this->GetHeightValue($mypref["partner_height_to"]), "value" => 1);

                    $prefcount++;
                }
            }

            if (strtolower($mypref["partner_education"]) != "null" && $mypref["partner_education"] != "") {
                $arrpref[count($arrpref)] = array("head" => "Education", "title" => $this->GetEducation($mypref["partner_education"]), "value" => 0);
                if (isset($arsub["partner_education"])) {
                    $totcount++;
                    if ($mypref["partner_education"] == $arsub["partner_education"]) {
                        $arrpref[count($arrpref) - 1] = array("head" => "Education", "title" => $this->GetEducation($mypref["partner_education"]), "value" => 1);

                        $prefcount++;
                    }
                }
            }
//             $arrpref["Weight"]=array($mypref["partner_weight"],0);
//            if($mypref["partner_weight"]==$arsub["partner_weight"]){
//                $arrpref["Weight"]=array($mypref["partner_weight"],1);
//            }
            if (strtolower($mypref['partner_familytype']) != "null" && $mypref['partner_familytype'] != "") {
                $arrpref[count($arrpref)] = array("head" => "Family Type", "title" => $mypref["partner_familytype"], "value" => 0);
                if (isset($arsub["partner_familytype"])) {
                    $totcount++;
                    if ($mypref["partner_familytype"] == $arsub["partner_familytype"]) {
                        $arrpref[count($arrpref) - 1] = array("head" => "Family Type", "title" => $mypref["partner_familytype"], "value" => 1);

                        $prefcount++;
                    }
                }
            }

            $arrpref[count($arrpref)] = array("head" => "Expectation", "title" => "expectation", "value" => (isset($arsub["partner_expectation"]) && $arsub["partner_expectation"] != null) ? $arsub["partner_expectation"] : "");

            // print_r($arrpref);
            // die('ere');


            $arrdata[count($arrdata)] = array("header" => $subhead);

            $arrdata[count($arrdata) - 1]["value"] = $arrpref;
            $arrdata[count($arrdata) - 1]["count"] = $prefcount . "/" . $totcount;

            $arsub = array();
        }
        // if (count($arsub) > 0) {
        //     $arrdata[count($arrdata)] = array("header" => $subhead);
        //     $arvalue = array();
        //     foreach ($arsub as $k => $v) {
        //         $arvalue[count($arvalue)] = array("key" => $k, "value" => $v);
        //     }
        //     //print_r($arvalue);
        //     //die('ere');
        //     $arrdata[count($arrdata) - 1]["value"] = $arvalue;
        //     $arsub = array();
        // }
        // print_r($arrdata);


        return json_encode($arrdata);
    }

    function GetHeightValue($heightid) {

        $this->db->select("height");
        $this->db->from("tbl_height");
        $this->db->where("height_id", $heightid);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            $query = $query->row_array();
            //print_r($query);
            return $query['height'];
        } else {
            return "";
        }
    }

    function GetEducation($eduid) {
        $this->db->select("qualification");
        $this->db->from("tbl_qualification");
        $this->db->where("qualification_id", $eduid);
        $query = $this->db->get();
        $query = $query->row_array();
        return $query['qualification'];
    }

    public function MyProfileInfo() {
        $id = $_GET['mode'];//r.profile_for 'Create By',r.happynikah_id 'Id',r.phone 'Phone',r.mail 'Mail',
        $this->db->SELECT("'About' head,o.aboutme,'Basic Information' head1,r.name 'Name',case when r.gender=1 then 'Male' else 'Female' end 'Gender',r.age 'Age',r.marital_status 'Marital Status',r.physical_status 'Physical Status',ifnull(m.mothertongue,'') 'Mother Tongue',r.no_of_children 'No. of Children (Divorced / Widows)',profile_for 'Created By','Religious Information' head2,ifnull(rel.religion,'') 'Religion',ifnull(c.caste,'') 'Caste','Education and Professional' head3,ifnull(q.qualification,'') 'Education',r.job_category 'Profession Type',ifnull(j.job_name,'') 'Profession',r.annual_income 'Annual Income','Physical Attribute' head4,ifnull(h.height,'') 'Height',ifnull(w.weight,'') 'Weight',ifnull(r.color,'') 'Skin Color',ifnull(r.blood_group,'') 'Blood Group',ifnull(r.bodytype,'') 'Body Type',ifnull(r.appearance,'') 'Appearance', 'Location and Contact Details' head5,concat(ifnull(d.district,''),',',ifnull(tbl_states.name,r.state),',',ifnull(tbl_country.name,r.country),',',ifnull(r.pincode,'')) 'Present Location',concat(ifnull(hd.district,''),',',ifnull(hs.name,''),',',ifnull(hc.name,r.country),',',ifnull(r.home_pincode,'')) 'Home Location',r.native_place 'City/Street',case when r.countryCode!=0 then concat(r.countryCode,r.phone) else r.phone end 'Mobile',case when r.secondary_code!=0 then cnt.country else r.secondary_code end 'Country Code',r. other_contact_number 'Secondary Number',r.mail 'Email',ifnull(r.contacttype,'') 'Contact Type','Family Details' head6,ifnull(f.familytype,'') 'Family Type',ifnull(f.financial_status,'') 'Financial Status',ifnull(f.hometype,'') 'Home Type',ifnull(f.total_members,'') 'Number of family Members',ifnull(f.fatherdetails,'') 'Father Details',ifnull(f.motherdetails,'') 'Mother Details',ifnull(f.fathers_occupation,'') 'Father Profession',f.mothers_occupation 'Mother Profession','Hobbies' head7,ifnull(r.hobbies,'') 'Hobbies','Partner Preference' head8,o.partner_age_from 'Age From',o.partner_age_to 'Age To',ifnull(ph.height,'') 'Height From',ifnull(ph_to.height,'') 'Height To',ifnull(GROUP_CONCAT(pq.qualification),'') 'Qualification Preference',
o.partner_familytype 'Family Type Preference',o.partner_expectation  'Partner Expectation'");
        $this->db->from("tbl_registration r");
        $this->db->join("tbl_mothertongue m", "m.mothertongue_id=r.mother_tongue", "left");
        $this->db->join("tbl_religion rel", "rel.rid=r.religion", "left");
        $this->db->join("tbl_caste c", "c.cid=r.caste", "left");
        $this->db->join("tbl_qualification q", "q.qualification_id=r.education", "left");
        $this->db->join("tbl_jobs j", "j.job_id=r.occupation", "left");
        $this->db->join("tbl_height h", "h.height_id=r.height", "left");
        $this->db->join("tbl_weight w", "w.weight_id=r.weight", "left");
        $this->db->join("tbl_district d", "d.district_id=r.native_district", "left");
        $this->db->join("tbl_familyprofile f", "f.user_id=r.id", "left");
        $this->db->join("tbl_otherdetails o", "o.user_id=r.id", "left");
        $this->db->join("tbl_qualification pq", "FIND_IN_SET(pq.qualification_id,o.partner_education)>0", "left");
        $this->db->join("tbl_height ph", "ph.height_id=o.partner_height", "left");
        $this->db->join("tbl_height ph_to", "ph_to.height_id=o.partner_height_to", "left");
        $this->db->join("tbl_country", "tbl_country.id=r.country", "left");
        $this->db->join("tbl_states", "tbl_states.id=r.state", "left");
        $this->db->join("tbl_country hc", "hc.id=r.home_country", "left");
        $this->db->join("tbl_states hs", "hs.id=r.home_state", "left");
        $this->db->join("tbl_district hd", "hd.district_id=r.home_district", "left");
        $this->db->join("tbl_countrycode cnt","cnt.id=r.secondary_code","left");
        $this->db->where("r.id", $id);
        $query = $this->db->get();
        $resutl = $query->row_array();
        // print_r($resutl);
        $arrdata = array();
        $subhead = "";
        $arsub = array();
        foreach ($resutl as $key => $value) {


            if (substr($key, 0, 4) == "head") {
                if (count($arsub) > 0) {
                    $arrdata[count($arrdata)] = array("header" => $subhead);
                    $arvalue = array();
                    foreach ($arsub as $k => $v) {
                        $arvalue[count($arvalue)] = array("key" => $k, "value" => $v);
                    }
                    //print_r($arvalue);
                    //die('ere');
                    $arrdata[count($arrdata) - 1]["value"] = $arvalue;
                    $arsub = array();
                }

                $subhead = $value;
            } else {
                $arsub[$key] = $value;
            }
        }
        if (count($arsub) > 0) {
            $arrdata[count($arrdata)] = array("header" => $subhead);
            $arvalue = array();
            foreach ($arsub as $k => $v) {
                $arvalue[count($arvalue)] = array("key" => $k, "value" => $v);
            }
            //print_r($arvalue);
            //die('ere');
            $arrdata[count($arrdata) - 1]["value"] = $arvalue;
            $arsub = array();
        }
        // print_r($arrdata);


        return json_encode($arrdata);
    }

    public function UploadImage() {
        $path = "assets/photo_storage";

        $data = $_POST;
        $fileName = $data['user_id'] . mt_rand(1111, 9999) . date('Y-m-d') . '.jpg';
        $config['upload_path'] = $path;
        $config['allowed_types'] = 'gif|jpg|png';
        $config['file_name'] = $fileName;

        $this->load->library('upload', $config);

        if (!$this->upload->do_upload('image')) {
            $d = array('error' => $this->upload->display_errors());
            $jsondata = array();
            $jsondata['error'] = $d['error'];
            return json_encode($jsondata);
            //$this->load->view('upload_form', $error);
        } else {
            //$d = array('upload_data' => $this->upload->data());
            if (!isset($data['profile'])) {
                $uploaddata['photo'] = $fileName;
                $uploaddata['photo_visibility'] = $data['photo_visibility'];
                $this->db->where("id", $data['user_id']);
                $this->db->update("tbl_registration", $uploaddata);
                $multiupload = array();
                $multiupload['user_id'] = $data['user_id'];
                $multiupload['user_image'] = $fileName;
                $this->db->insert("tbl_userimages", $multiupload);
            } else if (isset($data['profile']) && $data['profile'] == 1) {
                $uploaddata['photo'] = $fileName;
                $uploaddata['photo_visibility'] = $data['photo_visibility'];
                $this->db->where("id", $data['user_id']);
                $this->db->update("tbl_registration", $uploaddata);
            } else if (isset($data['profile']) && $data['profile'] == 0) {
                $multiupload = array();
                $multiupload['user_id'] = $data['user_id'];
                $multiupload['user_image'] = $fileName;
                $this->db->insert("tbl_userimages", $multiupload);
            }

            $jsondata = array();
            $jsondata['user_id'] = $data['user_id'];
            return json_encode($jsondata);
            //$this->load->view('upload_success', $data);
        }
    }

    function base64_to_jpeg($base64_string, $output_file) {
        // open the output file for writing
        $ifp = fopen($output_file, 'wb');

        // split the string on commas
        // $data[ 0 ] == "data:image/png;base64"
        // $data[ 1 ] == <actual base64 string>
        $data = explode(',', $base64_string);

        // we could add validation here with ensuring count( $data ) > 1
        fwrite($ifp, base64_decode($base64_string));

        // clean up the file resource
        fclose($ifp);

        return $output_file;
    }

    public function getDistrict() {
        $json = array();
        $json["error"] = false;
        $json["error_msg"] = "";
        $json["data"] = array();
        $this->db->select("district_id id,district value");
        $this->db->from("tbl_district");
        $query = $this->db->get();

        if ($query->num_rows() > 0) {
            $json["data"] = $query->result_array();
        } else {
            $json["error"] = true;
            $json["error_msg"] = "Data Not Found";
        }

        return json_encode($json);
    }

    public function getHeight() {
        $json = array();
        $json["error"] = false;
        $json["error_msg"] = "";
        $json["data"] = array();
        $this->db->select("height_id id,height value");
        $this->db->from("tbl_height");
        $query = $this->db->get();

        if ($query->num_rows() > 0) {
            $json["data"] = $query->result_array();
        } else {
            $json["error"] = true;
            $json["error_msg"] = "Data Not Found";
        }

        return json_encode($json);
    }

    public function getWeight() {
        $json = array();
        $json["error"] = false;
        $json["error_msg"] = "";
        $json["data"] = array();
        $this->db->select("weight_id id,weight value");
        $this->db->from("tbl_weight");
        $query = $this->db->get();

        if ($query->num_rows() > 0) {
            $json["data"] = $query->result_array();
        } else {
            $json["error"] = true;
            $json["error_msg"] = "Data Not Found";
        }

        return json_encode($json);
    }

    public function listBelief() {
        $json = array();
        $json["error"] = false;
        $json["error_msg"] = "";
        $json["data"] = array();
        $this->db->select("sid id,sub_caste value");
        $this->db->from("tbl_subcaste");
        $query = $this->db->get();

        if ($query->num_rows() > 0) {
            $json["data"] = $query->result_array();
        } else {
            $json["error"] = true;
            $json["error_msg"] = "Data Not Found";
        }

        return json_encode($json);
    }

    public function GetMotherTongue() {
        $json = array();
        $json["error"] = false;
        $json["error_msg"] = "";
        $json["data"] = array();
        $this->db->select("mothertongue_id id,mothertongue value");
        $this->db->from("tbl_mothertongue");
        $query = $this->db->get();

        if ($query->num_rows() > 0) {
            $json["data"] = $query->result_array();
        } else {
            $json["error"] = true;
            $json["error_msg"] = "Data Not Found";
        }

        return json_encode($json);
    }

    public function getQualification() {
        $json = array();
        $json["error"] = false;
        $json["error_msg"] = "";
        $json["data"] = array();
        $this->db->select("qualification_id id,qualification value");
        $this->db->from("tbl_qualification");
        $query = $this->db->get();

        if ($query->num_rows() > 0) {
            $json["data"] = $query->result_array();
        } else {
            $json["error"] = true;
            $json["error_msg"] = "Data Not Found";
        }

        return json_encode($json);
    }

    public function getJob() {
        $json = array();
        $json["error"] = false;
        $json["error_msg"] = "";
        $json["data"] = array();
        $this->db->select("job_id id,job_name value");
        $this->db->from("tbl_jobs");
        $query = $this->db->get();

        if ($query->num_rows() > 0) {
            $json["data"] = $query->result_array();
        } else {
            $json["error"] = true;
            $json["error_msg"] = "Data Not Found";
        }

        return json_encode($json);
    }

    public function GetCountry() {
        $json = array();
        $json["error"] = false;
        $json["error_msg"] = "";
        $json["data"] = array();
        $this->db->select("id,name value");
        $this->db->from("tbl_country");
        $query = $this->db->get();

        if ($query->num_rows() > 0) {
            $json["data"] = $query->result_array();
        } else {
            $json["error"] = true;
            $json["error_msg"] = "Data Not Found";
        }

        return json_encode($json);
    }
    public function GetDropDropdown($mode){
        $tablename="";
        $columnname="";
        switch ($mode){
            case 10:
                $tablename="tbl_appearance";
                $columnname="appearance";
                break;
            case 11:
                $tablename="tbl_maritalstatus";
                $columnname="maritalstatus";
                break;
            case 12:
                $tablename="tbl_physicalstatus";
                $columnname="physicalstatus";
                break;
             case 13:
                $tablename="tbl_bloodgroup";
                $columnname="bloodgroup";
                break;
            case 14:
                $tablename="tbl_contacttype";
                $columnname="contacttype";
                break;
            case 15:
                $tablename="tbl_financialstatus";
                $columnname="financialstatus";
                break;
                
             case 16:
                $tablename="tbl_skincolor";
                $columnname="skincolor";
                break;
             case 17:
                $tablename="tbl_bodytype";
                $columnname="bodytype";
                break;
            case 18:
                $tablename="tbl_familytype";
                $columnname="familytype";
                break;
            case 19:
                $tablename="tbl_hometype";
                $columnname="hometype";
                break;
            case 20:
                $tablename="tbl_countrycode";
                $columnname="country";
                break;
        }
        
        
        //echo $tablename;
        
        $json = array();
//        $json["error"] = false;
//        $json["error_msg"] = "";
        $json["data"] = array();
        $this->db->select("id,".$columnname." value");
        $this->db->from($tablename);
        $query = $this->db->get();

        if ($query->num_rows() > 0) {
            $json["data"] = $query->result_array();
        } else {
            $json["error"] = true;
            $json["error_msg"] = "Data Not Found";
        }

        return json_encode($json);
    }
    
   public function GetProfessionType(){
        $json = array();
        $json["error"] = false;
        $json["error_msg"] = "";
        $json["data"] = array();
        $this->db->select("id,professiontype value");
        $this->db->from("tbl_professiontype");
        $query = $this->db->get();

        if ($query->num_rows() > 0) {
            $json["data"] = $query->result_array();
        } else {
            $json["error"] = true;
            $json["error_msg"] = "Data Not Found";
        }

        return json_encode($json);
   }
    public function GetState() {
        $json = array();
        $json["error"] = false;
        $json["error_msg"] = "";
        $json["data"] = array();
        $this->db->select("id,name value");
        $this->db->from("tbl_states");
        $query = $this->db->get();

        if ($query->num_rows() > 0) {
            $json["data"] = $query->result_array();
        } else {
            $json["error"] = true;
            $json["error_msg"] = "Data Not Found";
        }

        return json_encode($json);
    }

    public function LoadUser() {
        $id = $_GET['mode'];
        $this->db->select("r.phone,r.name,r.photo,r.mail,ifnull(pl.contacts,0) contacts,ifnull(pl.messages,0) messages,count(v.sender_id) totviewed");
        $this->db->from("tbl_registration r");
        $this->db->join("tbl_payement p","r.id=p.user_id and p.expiry_date>CURDATE() and p.status=1","left");
        $this->db->join("tbl_plan pl","pl.plan_id=p.plan_id","left");
        $this->db->join("tbl_contact_viewed v","v.sender_id=r.id","left");
        
        $this->db->where("r.id", $id);
        $query = $this->db->get();
        
        $this->db->select("distinct (receiver_id) totmessage");
            $this->db->from("tbl_chating");
            $this->db->where("sender_id", $id);
            $this->db->group_by("receiver_id");
            $totmsg = $this->db->get();
        
        
        
        if ($query->num_rows() > 0) {
            $query=$query->row_array();
            if($totmsg->num_rows()>0){
               
                $query["totmessage"]=(string)$totmsg->num_rows();
            }else{
                $query["totmessage"]="0";
            }
            
            
            
            
            $json = $query;
        } else {
            $json["error"] = true;
            $json["error_msg"] = "Data Not Found";
        }
        return json_encode($json);
    }

    public function LoginWithId() {
        $userid = isset($_GET['mode']) ? $_GET['mode'] : "";
        $password = isset($_GET['m']) ? $_GET['m'] : "";
        //echo $phone;
        //echo $email;
        if ($userid == "" && $password == "") {
            $jsondata = array();
            $jsondata['user_id'] = 0;
            $jsondata['phone'] = "";
            return json_encode($jsondata);
        } else {
            $this->db->select("r.*");
            $this->db->from("tbl_registration r");
            $this->db->join("tbl_userlogin l", "r.id=l.user_id");
            $this->db->where("happynikah_id", $userid);
            $this->db->where("l.password", md5($password));
            //$this->db->where("r.deleted", 0);
           $this->db->where("r.status !=", 3);
            $query = $this->db->get();
            if ($query->num_rows() > 0) {

                $res = $query->row_array();
               
                    $phone = $res['phone'];
                    $jsondata = array();
                    $jsondata['user_id'] = (int) $res['id'];
                    $jsondata['phone'] = $phone;
               

                return json_encode($jsondata);
            } else {
                $this->db->select("r.*");
                $this->db->from("tbl_registration r");
                $this->db->join("tbl_userlogin l", "r.id=l.user_id");
                //$this->db->where("r.phone", $userid);
                $this->db->where("concat(r.countrycode,r.phone)='".$userid."' or r.phone='".$userid."'");
                $this->db->where("l.password", md5($password));
                //$this->db->where("r.deleted", 0);
                $this->db->where("r.status !=", 3);
                $query = $this->db->get();
                $jsondata = array();
                if ($query->num_rows() > 0) {
                    $res = $query->row_array();
                     $phone = $res['phone'];
                    $jsondata = array();
                    $jsondata['user_id'] = (int) $res['id'];
                    $jsondata['phone'] = $phone;
                }else{
                     
                $jsondata['user_id'] = 0;
                $jsondata['phone'] = "";
                }



               
                return json_encode($jsondata);
            }
        }
    }

    public function LoginDetails() {
        $phone = isset($_GET['mode']) ? $_GET['mode'] : "";
        $email = isset($_GET['m']) ? $_GET['m'] : "";
        //echo $phone;
        //echo $email;
        if ($phone == "" && $email == "") {
            $jsondata = array();
            $jsondata['user_id'] = 0;
            $jsondata['phone'] = "";
            return json_encode($jsondata);
        } else {
            $this->db->select("*");
            $this->db->from("tbl_registration");
            if ($phone != "") {
                // echo "nter";
                $this->db->where("concat(countrycode,phone)='".$phone."' or phone='".$phone."'");
            } else if ($email != "") {
                //echo 'entter';
                $this->db->where("mail", $email);
            }


            $this->db->where("phone!=''");
            //$this->db->where("deleted", 0);
            $this->db->where("status !=", 3);
            $query = $this->db->get();
            if ($query->num_rows() > 0) {

                $res = $query->row_array();
                if ($phone == "") {
                    $phone = $res['phone'];
                    $jsondata = array();
                    $jsondata['user_id'] = (int) $res['id'];
                    $jsondata['phone'] = $phone;
                } else {
                    $this->GenerateOtp($res['id'], $phone);
                    $jsondata = array();
                    $jsondata['user_id'] = 1;
                    $jsondata['phone'] = $phone;
                }

                return json_encode($jsondata);
            } else {
                $jsondata = array();
                $jsondata['user_id'] = 0;
                $jsondata['phone'] = "";
                return json_encode($jsondata);
            }
        }
    }

    function GenerateOtp($userid, $mobile) {
        $otp = mt_rand(100000, 999999);

        $this->db->select("r.name");
        $this->db->from("tbl_registration r");
        $this->db->where("id", $userid);
        $query = $this->db->get()->row_array();

        $otpdata = array();
        $otpdata["user_id"] = $userid;
        $otpdata["otp"] = $otp;
        $otpdata["otp_time"] = date("Y-m-d H:i:s");
        $this->db->insert("tbl_otp", $otpdata);
        $msg = "Your OTP code:" . $otp . "
Hi " . $query["name"] . ", Welcome to happynikah. To know your  details through online on happynikah.com.

SYSOL SYSTEM SOLUTIONS PRIVATE LIMITED";

        $this->smsotp(urlencode($msg), "91" . $mobile, 4, $otp, $query['name']);
    }

    function TotalProfileMatch() {
        $this->load->model("General_Model");
        $UserID = $_GET['mode'];

        $json[0] = array("id" => "totalprofiles", "value" => (string) $this->MatchingProfile(1));
        $json[1] = array("id" => "totalMembersviewed", "value" => $this->TotalMemberViewed($UserID));
        return json_encode($json);

//        $data['MatchingProfiles'] = $this->General_Model->getmatchingprofiles(0,$Details,1);
//        return json_encode($this->General_Model->getmatchingprofiles(0,$Details,1));
//        $count = 1;
//        // $data['MatchingProfilesCount'] = $this->General_Model->getmatchingprofiles($offset,$Details,$count);
//        $data['InterestExpressedCount'] = $this->General_Model->interestexpressed($offset,$Details,$count);
//        $data['liked_profilesCount'] = $this->General_Model->liked_profiles($offset,$Details,$count);
    }

    private function TotalMemberViewed($userid) {
        $this->db->select("count(v.receiver_id) totcount");
        $this->db->from("tbl_registration r");
        $this->db->join("tbl_viewed_profiles v", "v.receiver_id=r.id");
        $this->db->where("r.id", $userid);
        $query = $this->db->get();
        $query = $query->row_array();
        return $query["totcount"];
    }

    public function LastViewed() {
        $id = $_GET['mode'];

        $this->db->select("r.id,name,age,h.height,ifnull(sub_caste,'') belief,native_place,d.district native_district,ifnull(job_name,'') job,case when r.photo='' then case when r.gender='1' then 'male.jpg' else 'female.jpg' end  else r.photo end photo,ifnull(s.shortlist_id,0) shortlist,ifnull(i.interest_id,0) interest,ifnull(l.like_id,0) liked,r.phone,case when p.status=1 then 'Public' else r.photo_visibility end photo_visibility");
        $this->db->from("tbl_registration r");
        $this->db->join("tbl_subcaste c", "c.sid=r.caste", "left");
        $this->db->join("tbl_jobs j", "j.job_id=r.occupation", "left");
        $this->db->join("tbl_district d", "d.district_id=r.native_district", "left");
        $this->db->join("tbl_height h", "h.height_id=r.height", "left");
        $this->db->join("tbl_shortlist s", "s.receiver_id=r.id and s.sender_id=" . $id, "left");
        $this->db->join("tbl_interest i", "i.receiver_id=r.id and i.sender_id=" . $id, "left");
        $this->db->join("tbl_like l", "l.receiver_id=r.id and l.sender_id=" . $id, "left");
        $this->db->join("tbl_viewed_profiles p", "p.sender_id=r.id and p.receiver_id=" . $id);
        $this->db->join("tbl_photorequest pr","pr.receiver_id=r.id and pr.sender_id=".$id,"left");
        $this->db->where("r.id!=", $id);
        $this->db->where("p.viewed_id in (select max(viewed_id) from tbl_viewed_profiles where receiver_id='" . $id . "')");
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            $json = $query->row_array();
        } else {
            $json["error"] = true;
            $json["error_msg"] = "Data Not Found";
        }
        return json_encode($json);
    }

    public function LoadImages() {
        $id = $_GET['mode'];
        $query = $this->db->query("select * from (select r.id,ifnull(m.user_image,'') photo,ifnull(m.profile_pic,0) profimg  from tbl_registration r left join tbl_userimages m on m.user_id=r.id )x where x.id=" . $id . " order by x.profimg desc");

        if ($query->num_rows() > 0) {
            $json = $query->result_array();
        } else {
            $json["error"] = true;
            $json["error_msg"] = "Data Not Found";
        }
        return json_encode($json);
    }

    public function MatchingProfile($mode = 0) {
        $id = $_GET['mode'];
        $limit = 10;
        if (isset($_GET['m'])) {
            $limit = 500;
        }
        $this->db->select("*");
        $this->db->from("tbl_registration");
        $this->db->where("id", $id);
        $user = $this->db->get()->row_array();

        $this->db->select("*");
        $this->db->from("tbl_otherdetails");
        $this->db->where("user_id", $id);
        $pref = $this->db->get()->row_array();

        $gender = "";
        $photo = "";
        if ($user["gender"] == "Male" || $user['gender'] == 1) {
            $gender = "2";
            $photo = "female.jpg";
        } else if ($user["gender"] == "Female" || $user['gender'] == 2) {
            $gender = "1";
            $photo = "male.jpg";
        }


        $this->db->select("r.id,name,age,ifnull(h.height,'') height,ifnull(c.sub_caste,'') belief,ifnull(native_place,'') native_place,ifnull(d.district,'') native_district,ifnull(job_name,'') job,case when photo='' then '$photo' else photo end photo ,ifnull(s.shortlist_id,0) shortlist,ifnull(i.interest_id,0) interest,ifnull(l.like_id,0) liked,r.phone,case when p.status=1 then 'Public' else r.photo_visibility end photo_visibility");
        $this->db->from("tbl_registration r");
        $this->db->join("tbl_subcaste c", "c.sid=r.caste", "left");
        $this->db->join("tbl_jobs j", "j.job_id=r.occupation", "left");
        $this->db->join("tbl_district d", "d.district_id=r.native_district", "left");
        $this->db->join("tbl_height h", "h.height_id=r.height", "left");
        $this->db->join("tbl_familyprofile f","f.user_id=r.id","left");
        $this->db->join("tbl_shortlist s", "s.receiver_id=r.id and s.sender_id=" . $id, "left");
        $this->db->join("tbl_interest i", "i.receiver_id=r.id and i.sender_id=" . $id, "left");
        $this->db->join("tbl_like l", "l.receiver_id=r.id and l.sender_id=" . $id, "left");
        $this->db->join("tbl_photorequest p","p.receiver_id=r.id and p.sender_id=".$id,"left");
        $this->db->where("r.id!=" . $id);
        $this->db->where("r.id not in (select receiver_id from tbl_ignored where sender_id='".$id."')");
        $this->db->where("r.name !=''");
        $this->db->where("r.status !=", 3);
       // echo $pref["partner_age_from"]."=".$pref["partner_age_to"];
         if(isset($pref["partner_age_from"]) && $pref["partner_age_to"]!="" && $pref["partner_age_from"]!="0" && $pref["partner_age_to"]!="0"  &&  $pref["partner_age_from"]!="NULL" && $pref["partner_age_from"]!="NULL" ){
             $this->db->where("r.age between '".$pref["partner_age_from"]."' and '".$pref["partner_age_to"]."'");
         }
         
         if(isset($pref["partner_height"]) && isset($pref["partner_height_to"]) && $pref["partner_height"]!="" && $pref["partner_height_to"]!="" && $pref["partner_height"]!="NULL" && $pref["partner_height_to"]!="NULL"){
             //echo $pref["partner_height"]."=".$pref["partner_height_to"];
             $this->db->where("r.height between ".$pref["partner_height"]." and ".$pref["partner_height_to"]."");
         }
         //echo $pref["partner_education"];
         if(isset($pref["partner_education"]) && $pref["partner_education"]!="" && $pref["partner_education"]!="NULL"){
             $this->db->where("r.education in (".$pref["partner_education"].")");
         }
//         if(isset($pref["partner_familytype"]) && $pref["partner_familytype"]!=""){
//             $this->db->where("f.financial_status in (SELECT GROUP_CONCAT( DISTINCT CONCAT("'", REPLACE(partner_familytype, "," , "','") , "'"))  FROM tbl_otherdetails where user_id=".$id.")");
//         }
        $this->db->where("r.gender", $gender);
        //$this->db->order_by("r.name");
        $this->db->order_by("r.photo",'desc');
       
        if ($mode == 0) {
            $this->db->limit($limit);
            $query = $this->db->get();
            //echo $this->db->last_query();
            if ($query->num_rows() > 0) {
                $json = $query->result_array();
            } else {
                 $this->db->select("r.id,name,age,ifnull(h.height,'') height,ifnull(c.sub_caste,'') belief,ifnull(native_place,'') native_place,ifnull(d.district,'') native_district,ifnull(job_name,'') job,case when photo='' then '$photo' else photo end photo ,ifnull(s.shortlist_id,0) shortlist,ifnull(i.interest_id,0) interest,ifnull(l.like_id,0) liked,r.phone,case when p.status=1 then 'Public' else r.photo_visibility end photo_visibility");
        $this->db->from("tbl_registration r");
        $this->db->join("tbl_subcaste c", "c.sid=r.caste", "left");
        $this->db->join("tbl_jobs j", "j.job_id=r.occupation", "left");
        $this->db->join("tbl_district d", "d.district_id=r.native_district", "left");
        $this->db->join("tbl_height h", "h.height_id=r.height", "left");
        $this->db->join("tbl_familyprofile f","f.user_id=r.id","left");
        $this->db->join("tbl_shortlist s", "s.receiver_id=r.id and s.sender_id=" . $id, "left");
        $this->db->join("tbl_interest i", "i.receiver_id=r.id and i.sender_id=" . $id, "left");
        $this->db->join("tbl_like l", "l.receiver_id=r.id and l.sender_id=" . $id, "left");
        $this->db->join("tbl_photorequest p","p.receiver_id=r.id and p.sender_id=".$id,"left");
        $this->db->where("r.id!=" . $id);
        $this->db->where("r.id not in (select receiver_id from tbl_ignored where sender_id='".$id."')");
        $this->db->where("r.name !=''");
         $this->db->where("r.gender", $gender);
         $this->db->where("r.status !=", 3);
        //$this->db->order_by("r.name");
        $this->db->order_by("r.photo",'desc');
        $this->db->limit($limit);
              $query=$this->db->get();
              if($query->num_rows()>0){
                  $json = $query->result_array();
              }else{
                  $json["error"] = true;
                $json["error_msg"] = "Data Not Found";
              }
            }
            return json_encode($json);
        } else {
            $query = $this->db->get();
            return $query->num_rows();
        }
    }

    public function Search() {
        $json = file_get_contents('php://input');
        //print_r($json);
        //echo "Name:".$json["Name"];
        $data = json_decode($json, true);
        $id = $data['id'];

        $this->db->select("*");
        $this->db->from("tbl_registration");
        $this->db->where("id", $data['id']);
        $user = $this->db->get()->row_array();
        $maritalStatus = [0 => "All", 1 => "Unmarried", 2 => "Divorced", 3 => "Widow"];

        $gender = "";
        $photo = "";
        if ($user["gender"] == "1") {
            $gender = "2";
            $photo = "female.jpg";
        } else if ($user["gender"] == "2") {
            $gender = "1";
            $photo = "male.jpg";
        }
        $strbelief = array();
        $resbelief = "";
        if (isset($data['belief']) && $data['belief'] != "") {
            //echo $data['belief'];
            $strbelief = explode(",", $data['belief']);
            $res = "'" . implode("', '", $strbelief) . "'";
            $resbelief = $res;
        }
        $reseducation = "";
        if (isset($data['education']) && $data['education'] != "") {
            //echo $data['belief'];
            $streducation = array();
            $streducation = explode(",", $data['education']);
            // print_r($streducation);
            if (count($streducation) > 0) {
                $res = "'" . implode("', '", $streducation) . "'";
                $reseducation = $res;
            }
        }
        $heightfrom = "";
        $heightto = "";
        if (isset($data['height'])) {
            $spltd = explode(",", $data['height']);
            $this->db->select("height_id");
            $this->db->from("tbl_height");
            $this->db->like("height", $spltd[0]);
            $height = $this->db->get()->row_array();

            $heightfrom = $height["height_id"];

            $this->db->select("height_id");
            $this->db->from("tbl_height");
            $this->db->like("height", $spltd[1]);
            $height2 = $this->db->get()->row_array();
            $heightto = $height2["height_id"];
        }


        $this->db->select("r.id,name,age,h.height,ifnull(c.sub_caste,'') belief,native_place,d.district native_district,ifnull(job_name,'') job,case when photo='' then '$photo' else photo end photo ,ifnull(s.shortlist_id,0) shortlist,ifnull(i.interest_id,0) interest,ifnull(l.like_id,0) liked,r.phone,case when p.status=1 then 'Public' else r.photo_visibility end photo_visibility");
        $this->db->from("tbl_registration r");
        if ($resbelief != "") {
            $this->db->join("tbl_subcaste c", "c.sid=r.caste and c.sub_caste in (" . $resbelief . ")");
        } else {
            $this->db->join("tbl_subcaste c", "c.sid=r.caste", "left");
        }

        if ($reseducation != "") {
            $this->db->join("tbl_jobs j", "j.job_id=r.occupation and j.job_name in (" . $reseducation . ")");
        } else {
            $this->db->join("tbl_jobs j", "j.job_id=r.occupation", "left");
        }

        $this->db->join("tbl_district d", "d.district_id=r.native_district", "left");
        $this->db->join("tbl_height h", "h.height_id=r.height", "left");
        $this->db->join("tbl_shortlist s", "s.receiver_id=r.id and s.sender_id=" . $id, "left");
        $this->db->join("tbl_interest i", "i.receiver_id=r.id and i.sender_id=" . $id, "left");
        $this->db->join("tbl_like l", "l.receiver_id=r.id and l.sender_id=" . $id, "left");
        $this->db->join("tbl_photorequest p","p.receiver_id=r.id and p.sender_id=".$id,"left");
        $this->db->where("r.id!=" . $id);
        $this->db->where("r.status !=", 3);
        $this->db->where("r.id not in (select receiver_id from tbl_ignored where sender_id='".$id."')");
        if (isset($data['state']) && $data['state'] != "") {
            $this->db->where("r.state", $data['state']);
        }
        if (isset($data['city']) && $data['city'] != "") {
            $this->db->where("r.native_place", $data['city']);
        }
        if (isset($data['district']) && $data['district'] != "0") {
            $this->db->where("r.native_district", $data['district']);
        }

        $this->db->where("r.gender", $gender);
        if (isset($data['age'])) {
            $spltd = explode(",", $data['age']);
            // print_r($spltd);
            $this->db->where("r.age between " . $spltd[0] . " and " . $spltd[1]);
        }
        if ($heightfrom != "" && $heightto != "") {
            $this->db->where("r.height between " . $heightfrom . " and " . $heightto);
        }
        if (isset($data['maritalstatus']) && $data['maritalstatus'] != 0) {
            $index = $data['maritalstatus'];
            $mstatus = $maritalStatus[$index];
            //echo $maritalStatus[$index];
            $this->db->where("r.marital_status", $mstatus);
        }
        //$this->db->order_by("r.name");
         $this->db->order_by("r.photo",'desc');
        $query = $this->db->get();
        $json = array();
        if ($query->num_rows() > 0) {
            $json = $query->result_array();
        } else {
            $json[0]["error"] = true;
            $json[0]["error_msg"] = "Data Not Found";
        }
        return json_encode($json);
    }

    public function Explore() {
        $id = $_GET['mode'];
        $m = $_GET['m'];
        $limit = 10;

        $this->db->select("*");
        $this->db->from("tbl_registration");
        $this->db->where("id", $id);
        $user = $this->db->get()->row_array();

        $gender = "";
        $photo = "";
        if ($user["gender"] == "1") {
            $gender = "2";
            $photo = "female.jpg";
        } else if ($user["gender"] == "2") {
            $gender = "1";
            $photo = "male.jpg";
        }

        $this->db->select("r.id,name,age,h.height,ifnull(c.sub_caste,'') belief,native_place,d.district native_district,ifnull(job_name,'') job,case when photo='' then '$photo' else photo end photo ,ifnull(s.shortlist_id,0) shortlist,ifnull(i.interest_id,0) interest,ifnull(l.like_id,0) liked,r.phone,case when p.status=1 then 'Public' else r.photo_visibility end photo_visibility");
        $this->db->from("tbl_registration r");
        $this->db->join("tbl_subcaste c", "c.sid=r.caste", "left");
        $this->db->join("tbl_jobs j", "j.job_id=r.occupation", "left");
        $this->db->join("tbl_district d", "d.district_id=r.native_district", "left");
        $this->db->join("tbl_height h", "h.height_id=r.height", "left");
        $this->db->join("tbl_photorequest p","p.receiver_id=r.id and p.sender_id=".$id,"left");

        if ($m == 1) {
            $this->db->join("tbl_interest i", "i.receiver_id=r.id and i.sender_id=" . $id);
        } else {
            $this->db->join("tbl_interest i", "i.receiver_id=r.id and i.sender_id=" . $id, "left");
        }
        if ($m == 2) {
            $this->db->join("tbl_viewed_profiles p", "p.receiver_id=r.id and p.sender_id=" . $id);
        }
        if ($m == 3) {
            $this->db->join("tbl_contact_viewed cv", "cv.receiver_id=r.id and cv.sender_id=" . $id);
        }
        if ($m == 4) {
            $this->db->join("tbl_shortlist s", "s.receiver_id=r.id and s.sender_id=" . $id);
        } else {
            $this->db->join("tbl_shortlist s", "s.receiver_id=r.id and s.sender_id=" . $id, "left");
        }
        if ($m == 5) {
            $this->db->join("tbl_block b", "b.receiver_id=r.id and b.sender_id=" . $id);
        }

        if($m==6){
            $this->db->join("tbl_ignored g", "g.receiver_id=r.id and g.sender_id=" . $id);
        }
        if ($m == 7) {
            $this->db->join("tbl_interest rc", "rc.receiver_id=" . $id . " and rc.sender_id=r.id and rc.status=0");
        }
        if ($m == 8) {
            $this->db->join("tbl_interest rc", "rc.receiver_id=" . $id . " and rc.sender_id=r.id and rc.status=1");
        }
        if ($m == 9) {
            $this->db->join("tbl_interest rc", "rc.receiver_id=" . $id . " and rc.sender_id=r.id and rc.status='2'", false);
        }
        if ($m == 10) {
            $this->db->join("tbl_photorequest pr", "pr.sender_id=" . $id . " and pr.receiver_id=r.id and pr.status=0 ", false);
        }
        if ($m == 11) {
            $this->db->join("tbl_photorequest pr", "pr.sender_id=" . $id . " and pr.receiver_id=r.id and pr.status=1 ", false);
        }
        if ($m == 12) {
            $this->db->join("tbl_photorequest pr", "pr.sender_id=" . $id . " and pr.receiver_id=r.id and pr.status=2 ", false);
        }
         if ($m == 13) {
            $this->db->join("tbl_photorequest pr", "pr.receiver_id=" . $id . " and pr.sender_id=r.id and pr.status=0 ", false);
        }
         if ($m == 14) {
            $this->db->join("tbl_photorequest pr", "pr.receiver_id=" . $id . " and pr.sender_id=r.id and pr.status=1 ", false);
        }
         if ($m == 15) {
            $this->db->join("tbl_photorequest pr", "pr.receiver_id=" . $id . " and pr.sender_id=r.id and pr.status=2", false);
        }
        $this->db->join("tbl_like l", "l.receiver_id=r.id and l.sender_id=" . $id, "left");
        $this->db->where("r.id!=" . $id);
        $this->db->where("r.gender", $gender);
        $this->db->order_by("r.name");
        //$this->db->limit($limit);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            $json = $query->result_array();
        } else {
            $json[0]["error"] = true;
            $json[0]["error_msg"] = "Data Not Found";
        }
        return json_encode($json);
    }

    public function PlanDetails() {
        $this->db->select("*");
        $this->db->from("tbl_plan");
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            $json = $query->result_array();
        } else {
            $json["error"] = true;
            $json["error_msg"] = "Data Not Found";
        }
        return json_encode($json);
    }

    public function Payment() {
        $json = file_get_contents('php://input');
        //print_r($json);
        //echo "Name:".$json["Name"];
        $data = json_decode($json, true);
        $data['date'] = date('Y-m-d');

        $this->db->select("*");
        $this->db->from("tbl_plan");
        $this->db->where("plan_id", $data['plan_id']);
        $plandetails = $this->db->get()->row_array();

        $expiry = date('Y-m-d', strtotime($data['date'] . ' +' . $plandetails['months'] . ' months'));
        $data['expiry_date'] = $expiry;
        $data['status'] = 1;

//print_r($data);
        $res = $this->db->insert("tbl_payement", $data);
        echo $this->db->last_query();
        $jsonres = array();
        if ($res) {
            $jsonres["status"] = "1";
        } else {
            $jsonres["error"] = true;
            $jsonres["error_msg"] = "Data Not Found";
        }
        return json_encode($jsonres);
    }

    public function SendActivity() {
        error_reporting(E_ALL);
        ini_set('display_errors', '1');
        $mode = $_GET['mode'];
        $json = file_get_contents('php://input');
        //print_r($json);
        //echo "Name:".$json["Name"];
        $data = json_decode($json, true);
        $res=0;
        if ($mode == 0) {
            $this->db->select("*");
            $this->db->from("tbl_shortlist");
            $this->db->where("receiver_id", $data['receiver_id']);
            $this->db->where("sender_id", $data['sender_id']);
            $query = $this->db->get();
            if ($query->num_rows() > 0) {
                $shorlistid = $query->row_array();
                $this->db->where("shortlist_id", $shorlistid["shortlist_id"]);
                $res = $this->db->delete("tbl_shortlist");
            } else {
                $data['date'] = date("Y-m-d");
                $res = $this->db->insert("tbl_shortlist", $data);
            }
        } else if ($mode == 1) {
            $this->db->select("*");
            $this->db->from("tbl_interest");
            $this->db->where("receiver_id", $data['receiver_id']);
            $this->db->where("sender_id", $data['sender_id']);
            $query = $this->db->get();
            if ($query->num_rows() > 0) {
                $shorlistid = $query->row_array();
                $this->db->where("interest_id", $shorlistid["interest_id"]);
                $res = $this->db->delete("tbl_interest");
            } else {
                $data['date'] = date("Y-m-d");
                $res = $this->db->insert("tbl_interest", $data);
            }
        } else if ($mode == 2) {
            $this->db->select("*");
            $this->db->from("tbl_like");
            $this->db->where("receiver_id", $data['receiver_id']);
            $this->db->where("sender_id", $data['sender_id']);
            $query = $this->db->get();
            if ($query->num_rows() > 0) {
                $shorlistid = $query->row_array();
                $this->db->where("like_id", $shorlistid["like_id"]);
                $res = $this->db->delete("tbl_like");
            } else {
                $data['date'] = date("Y-m-d");
                $res = $this->db->insert("tbl_like", $data);
            }
        } else if ($mode == 3) {
            $this->db->select("*");
            $this->db->from("tbl_interest");
            $this->db->where("receiver_id", $data['receiver_id']);
            $this->db->where("sender_id", $data['sender_id']);
            $query = $this->db->get();
            if ($query->num_rows() > 0) {
                $shorlistid = $query->row_array();
                $arrdata['status'] = 1;
                $this->db->where("interest_id", $shorlistid["interest_id"]);
                $res = $this->db->update("tbl_interest", $arrdata);
            }
        } else if ($mode == 4) {
            $this->db->select("*");
            $this->db->from("tbl_interest");
            $this->db->where("receiver_id", $data['receiver_id']);
            $this->db->where("sender_id", $data['sender_id']);
            $query = $this->db->get();
            if ($query->num_rows() > 0) {
                $shorlistid = $query->row_array();
                $data['status'] = 2;
                $this->db->where("interest_id", $shorlistid["interest_id"]);
                $res = $this->db->update("tbl_interest", $data);
            }
        } else if ($mode == 5) {
            $res = $this->ModifyImg($data);
        } else if ($mode == 6) {
            $id = $data['user_id'];
            $imgurl = $data['imageurl'];
            $arrdata['photo'] = $imgurl;
            $this->db->where("id", $id);
            $res = $this->db->update("tbl_registration", $arrdata);
        } else if ($mode == 7) {
            
            $this->db->select("id");
            $this->db->from("tbl_payement");
            $this->db->where("user_id",$data["sender_id"]);
            $arplan=$this->db->get();
            
            
            
            $sender_id = $data['sender_id'];
            $receiver_id = $data['receiver_id'];

            $arrdata["sender_id"] = $sender_id;
            $arrdata["receiver_id"] = $receiver_id;
            $arrdata["messages"] = $data['messages'];
            $arrdata['date'] = date("Y-m-d");
            $arrdata["time"] = date("Y-m-d H:m:s");
            if($arplan->num_rows()>0){
                $arplan=$arplan->row_array();
                $arrdata["planid"]=$arplan["id"];
            }
            $res = $this->db->insert("tbl_chating", $arrdata);
        } else if ($mode == 8) {
            $userid = $data['sender_id'];
            $token = $data['messages'];
            $arrdata = array();
            $arrdata['user_id'] = $userid;
            $arrdata['firebase_token'] = $token;

            $this->db->select("*");
            $this->db->from("tbl_firebase_token");
            $this->db->where("user_id", $userid);
            $query = $this->db->get();
            if ($query->num_rows() > 0) {
                unset($arrdata['user_id']);

                $this->db->where("user_id", $userid);
                $res = $this->db->update("tbl_firebase_token", $arrdata);
            } else {
                $res = $this->db->insert("tbl_firebase_token", $arrdata);
            }
        } else if ($mode == 9) {
            $userid = $data['sender_id'];
            $complainte = $data['messages'];
            $arrdata = array();
            $arrdata['sender_id'] = $userid;
            $arrdata['receiver_id'] = $data['receiver_id'];
            $arrdata['complaint'] = $data['messages'];
            $this->db->insert("tbl_block", $arrdata);
        } else if ($mode == 10) {

            $phone = $data['phone'];
            // echo $phone;
            $this->db->select("*");
            $this->db->from("tbl_registration");
            $this->db->where("phone", $phone);
            $query = $this->db->get();
            $jsonres = array();
            if ($query->num_rows() > 0) {

                $jsonres["status"] = false;
            } else {
                $jsonres["status"] = true;
            }
            return json_encode($jsonres);
        }else if ($mode == 11) {
            
                 $data['date'] = date("Y-m-d");
                $res = $this->db->insert("tbl_ignored", $data);
            
        }else if($mode==12){
            $this->db->select("*");
            $this->db->from("tbl_photorequest");
            $this->db->where("sender_id",$data['sender_id']);
            $this->db->where("receiver_id",$data['receiver_id']);
            $query=$this->db->get();
            if($query->num_rows()==0){
                 $ardata=array();
            $ardata["sender_id"]=$data['sender_id'];
            $ardata["receiver_id"]=$data['receiver_id'];
            $ardata["date"]=date("Y-m-d");
            $res=$this->db->insert("tbl_photorequest",$ardata);
            }           
           
        }else if ($mode == 13) {
            $this->db->select("*");
            $this->db->from("tbl_photorequest");
            $this->db->where("receiver_id", $data['receiver_id']);
            $this->db->where("sender_id", $data['sender_id']);
            $query = $this->db->get();
            if ($query->num_rows() > 0) {
                $shorlistid = $query->row_array();
                $arrdata['status'] = 1;
                $this->db->where("id", $shorlistid["id"]);
                $res = $this->db->update("tbl_photorequest", $arrdata);
            }
        } else if ($mode == 14) {
            //echo "enter";
            $this->db->select("*");
            $this->db->from("tbl_photorequest");
            $this->db->where("receiver_id", $data['receiver_id']);
            $this->db->where("sender_id", $data['sender_id']);
            $query = $this->db->get();
            if ($query->num_rows() > 0) {
                $shorlistid = $query->row_array();
                $data['status'] = 2;
                $this->db->where("id", $shorlistid["id"]);
                $res = $this->db->update("tbl_photorequest", $data);
            }
        }
        else if ($mode == 15) {
            $this->db->select("*");
            $this->db->from("tbl_photorequest");
            $this->db->where("receiver_id", $data['receiver_id']);
            $this->db->where("sender_id", $data['sender_id']);
            $query = $this->db->get();
            if ($query->num_rows() > 0) {
                $shorlistid = $query->row_array();
                $data['status'] = 2;
                $this->db->where("id", $shorlistid["id"]);
                $res = $this->db->delete("tbl_photorequest");
            }
        }


        $jsonres = array();
        if ($res) {
            $jsonres["status"] = "1";
        } else {
            $jsonres["error"] = true;
            $jsonres["error_msg"] = "Data Not Found";
        }
        return json_encode($jsonres);
    }

    public function RetrieveData() {
        $mode = $_GET['mode'];
        $json = file_get_contents('php://input');
        //print_r($json);
        //echo "Name:".$json["Name"];
        $data = json_decode($json, true);
        $profid = $data['receiver_id'];
        $id = $data['sender_id'];
        if ($mode == 1) {
            $this->db->select("count(*) totcount");
            $this->db->from("tbl_contact_viewed");
            $this->db->where("sender_id", $id);
            $count = $this->db->get()->row_array();

            $this->db->select("count(*) totcount");
            $this->db->from("tbl_contact_viewed");
            $this->db->where("sender_id", $id);
            $this->db->where("receiver_id", $profid);
            $exists = $this->db->get()->row_array();

            $this->db->select("tbl_payement.*,tbl_plan.months,tbl_plan.contacts,tbl_plan.messages");
            $this->db->from("tbl_payement");
            $this->db->join("tbl_plan", "tbl_plan.plan_id=tbl_payement.plan_id");
            $this->db->where("tbl_payement.expiry_date>CURDATE()");
            $this->db->where("tbl_payement.status", 1);
            $this->db->where("user_id", $id);
            $query = $this->db->get();
            
            $flag = 0;
            $arplan=array();
            if($query->num_rows()>0){
                 $arplan=$query->row_array();
                // print_r($arplan);
            }
            if ($exists["totcount"] > 0) {
                $flag = 1;
            } else if ($query->num_rows() > 0) {
                
               
                if($count["totcount"]<$arplan["contacts"]){
                    $flag=1;
                }
            }else if($query->num_rows()==0 && $count["totcount"]<15){
                $flag=1;
            }
            $jsonres = array();

             $this->db->select("distinct (receiver_id) totmessage");
            $this->db->from("tbl_chating");
            $this->db->where("sender_id", $id);
            $this->db->group_by("receiver_id");
            $totmsg = $this->db->get();
            $phonestatus=0;
            if ($totmsg->num_rows() > 0) {
                //$totmsg = $totmsg->row_array();
                //echo $totmsg->num_rows()."=".$arplan["messages"];
                if ($totmsg->num_rows() < $arplan["messages"]) {
                   $phonestatus = 1;
                } else{
                    $phonestatus = 0;
                }
            } else {
               $phonestatus = 1;
            }


            //echo $flag;
            if ((int) $flag == 1) {
                // echo "tnere";
                $this->db->select("phone,mail,other_contact_number,address");
                $this->db->from("tbl_registration");
                $this->db->where("id", $profid);
                $query = $this->db->get();

                $jsonres = $query->row_array();
                $jsonres["status"] = $flag;
                $jsonres["phonestatus"]=$phonestatus;
                if ((int) $exists["totcount"] === 0) {
                    $arrdata = array();
                    $arrdata["sender_id"] = $id;
                    $arrdata["receiver_id"] = $profid;
                    if(isset($arplan["id"])){
                        $arrdata["planid"]=$arplan["id"];
                    }
                    $this->db->insert("tbl_contact_viewed", $arrdata);
                }
            } else {
                $jsonres["status"] = $flag;
                $jsonres["phonestatus"] = $phonestatus;
            }
            //print_r($jsonres);
            return json_encode($jsonres);
        } else if ($mode == 2) {
            return $this->ChatList($data);
        } else if ($mode == 3) {
            return $this->Chatting($data);
        } else if ($mode == 4) {
            
            $this->db->select("tbl_payement.*,tbl_plan.months,tbl_plan.contacts,tbl_plan.messages");
            $this->db->from("tbl_payement");
            $this->db->join("tbl_plan", "tbl_plan.plan_id=tbl_payement.plan_id");
            $this->db->where("tbl_payement.expiry_date>CURDATE()");
            $this->db->where("tbl_payement.status", 1);
            $this->db->where("user_id", $id);
            $query = $this->db->get();
            
            $flag = 0;
            $arplan=array();
            if($query->num_rows()>0){
                 $arplan=$query->row_array();
                // print_r($arplan);
            }
            
            // echo $profid."=".$id;
            $this->db->select("*");
            $this->db->from("tbl_interest");
            $this->db->where("sender_id ", $id);
            $this->db->where("receiver_id", $profid);
            $query = $this->db->get();
            $jsonres = array();
            if ($query->num_rows() > 0) {
                $jsonres["status"] = 1;
            } else {
                $jsonres["status"] = 0;
            }
             $this->db->select("distinct (receiver_id) totmessage");
            $this->db->from("tbl_chating");
            $this->db->where("sender_id", $id);
            $this->db->group_by("receiver_id");
            $totmsg = $this->db->get();
            $phonestatus=0;
            if ($totmsg->num_rows() > 0 && count($arplan)>0) {
                //$totmsg = $totmsg->row_array();
                //echo $totmsg->num_rows()."=".$arplan["messages"];
                if ($totmsg->num_rows() < $arplan["messages"]) {
                   $phonestatus = 1;
                } else{
                    $phonestatus = 0;
                }
            } else if(count($arplan)>0) {
               $phonestatus = 1;
            }
            $jsonres["phonestatus"]=$phonestatus;
            
            $this->db->select("case when p.status=1 then 'Public' else r.photo_visibility end photo_visibility");
            $this->db->from("tbl_registration r");
            $this->db->join("tbl_photorequest p","p.receiver_id=r.id and p.sender_id=".$id,"left");
            $this->db->where("r.id",$profid);
            $query=$this->db->get();
            $query=$query->row_array();
            $jsonres["photoprotected"]=$query["photo_visibility"];
            


            return json_encode($jsonres);
        }else if($mode==5){
            //$where="(happynikah_id='".$id."' or phone='".$id."')";
            $where="(happynikah_id='".$id."' or concat(countrycode,phone)='".$id."' or phone='".$id."')";
            $this->db->select("id");
            $this->db->from("tbl_registration");
            $this->db->where($where);
            
            $query=$this->db->get();
            $jsonres=array();
            if($query->num_rows()>0){
                $query=$query->row_array();
                $newpwd=md5($profid);
                $arrdata=array();
                $arrdata['password']=$newpwd;
                $this->db->where("user_id",$query["id"]);
                $this->db->update("tbl_userlogin",$arrdata);
                $jsonres['status']=1;
            }else{
                $jsonres['status']=0;
            }
            
            return json_encode($jsonres);
        }else if($mode==6){
             $this->db->select("tbl_payement.*,tbl_plan.months,tbl_plan.contacts,tbl_plan.messages");
            $this->db->from("tbl_payement");
            $this->db->join("tbl_plan", "tbl_plan.plan_id=tbl_payement.plan_id");
            $this->db->where("tbl_payement.expiry_date>CURDATE()");
            $this->db->where("status", 1);
            $this->db->where("user_id", $id);
            $query = $this->db->get();
            
            $flag = 0;
            $arplan=array();
            if($query->num_rows()>0){
                 $arplan=$query->row_array();
                // print_r($arplan);
            }
            
            $this->db->select("distinct (receiver_id) totmessage");
            $this->db->from("tbl_chating");
            $this->db->where("sender_id", $id);
            $this->db->group_by("receiver_id");
            $totmsg = $this->db->get();
            $phonestatus=0;
            if ($totmsg->num_rows() > 0 && count($arplan)>0) {
                //$totmsg = $totmsg->row_array();
                //echo $totmsg->num_rows()."=".$arplan["messages"];
                if ($totmsg->num_rows() < $arplan["messages"]) {
                   $phonestatus = 1;
                } else{
                    $phonestatus = 0;
                }
            } else if(count($arplan)>0) {
               $phonestatus = 1;
            }
            $jsonres["phonestatus"]=$phonestatus;


            return json_encode($jsonres);
        }else if($mode==7){
            $this->db->select("photo_visibility,photopassword,showtoexpress,showtopremium");
            $this->db->from("tbl_registration");
            $this->db->where("id",$id);
            $query=$this->db->get();
            $query=$query->row_array();
            return json_encode($query);
        }
    }

    public function UpdateProfVisit() {
        $mode = $_GET['mode'];
        $json = file_get_contents('php://input');
        //print_r($json);
        //echo "Name:".$json["Name"];
        $data = json_decode($json, true);

        $this->db->select("*");
        $this->db->from("tbl_viewed_profiles");
        $this->db->where("sender_id", $data['sender_id']);
        $this->db->where("receiver_id", $data['receiver_id']);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            $id = $query->row_array();
            $data['statusdate'] = date("Y-m-d");
            $this->db->where("viewed_id", $id['viewed_id']);
            $res = $this->db->update("tbl_viewed_profiles", $data);
        } else {
            $data['date'] = date("Y-m-d");
            $res = $this->db->insert("tbl_viewed_profiles", $data);
        }
        $jsonres = array();
        if ($res) {
            $jsonres["status"] = "1";
        } else {
            $jsonres["error"] = true;
            $jsonres["error_msg"] = "Data Not Found";
        }
        return json_encode($jsonres);
    }

    public function ModifyImg($data) {
        $id = $data['user_id'];
        $imgurl = $data['imageurl'];

        $this->db->select("*");
        $this->db->from("tbl_registration");
        $this->db->where("id", $id);
        $this->db->where("photo", $imgurl);
        $res = $this->db->get();

        if ($res->num_rows() > 0) {

            $this->db->select("user_image");
            $this->db->from("tbl_userimages");
            $this->db->where("user_id", $id);
            $this->db->where("user_image !=", $imgurl);
            $query = $this->db->get();
            if ($query->num_rows() > 0) {
                $query = $query->row_array();
                // print_r($query);
                $upimgurl['photo'] = $query["user_image"];

                $this->db->where("id", $id);
                $this->db->update("tbl_registration", $upimgurl);
            } else {
                $upimgurl['photo'] = "";

                $this->db->where("id", $id);
                $this->db->update("tbl_registration", $upimgurl);
            }
        }






        $this->db->where("user_id", $id);
        $this->db->where("user_image", $imgurl);
        $res = $this->db->delete("tbl_userimages");
        if ($imgurl != "") {
            $path = "assets/photo_storage/" . $imgurl;
            unset($path);
        }
        return $res;
    }

    public function ChatList($data) {
        $id = $data['sender_id'];

        $this->db->select("r.id,r.name,case when r.photo='' then case when r.gender=1 then 'male.jpg' else 'female.jpg' end else r.photo end photo,r.age,ifnull(h.height,'') height,ifnull(q.qualification,'') qualification,DATE_FORMAT(c.date,'%d/%m/%Y') date,DATE_FORMAT(c.time,'%h:%i %p') time,c.status");
        $this->db->from("tbl_registration r");
        $this->db->join("tbl_height h", "h.height_id=r.height", "left");
        $this->db->join("tbl_qualification q", "q.qualification_id=r.education", "left");
        $this->db->join("tbl_chating c", "c.sender_id=r.id");
        $this->db->where("c.receiver_id", $id);
        $this->db->group_by("c.receiver_id");
        $chatreceiver = $this->db->get();

        $this->db->select("r.id,r.name,case when r.photo='' then case when r.gender=1 then 'male.jpg' else 'female.jpg' end else r.photo end photo,r.age,ifnull(h.height,'') height,ifnull(q.qualification,'') qualification,DATE_FORMAT(c.date,'%d/%m/%Y') date,DATE_FORMAT(c.time,'%h:%i %p') time,c.status");
        $this->db->from("tbl_registration r");
        $this->db->join("tbl_height h", "h.height_id=r.height", "left");
        $this->db->join("tbl_qualification q", "q.qualification_id=r.education", "left");
        $this->db->join("tbl_chating c", "c.receiver_id=r.id");
        $this->db->where("c.sender_id", $id);
        $this->db->where("c.receiver_id not in (select sender_id from tbl_chating where receiver_id=" . $id . ")");
        $this->db->group_by("r.id");
        $chatsender = $this->db->get();

        $chatreceiver = $chatreceiver->result_array();

        $chatsender = $chatsender->result_array();
        $result = array_merge($chatreceiver, $chatsender);

        return json_encode($result);
    }

    public function Chatting($data) {
        $sender_id = $data['sender_id'];
        $receiver_id = $data['receiver_id'];

        $this->db->select("r.id,r.name,case when r.photo='' then case when r.gender=1 then 'male.jpg' else 'female.jpg' end else r.photo end photo,r.age,h.height,q.qualification,DATE_FORMAT(c.date,'%d/%m/%Y') date,DATE_FORMAT(c.time,'%h:%i %p') time,c.status,c.messages,case when c.sender_id='" . $sender_id . "' then 1 else 0 end sendstatus");
        $this->db->from("tbl_registration r");
        $this->db->join("tbl_height h", "h.height_id=r.height", "left");
        $this->db->join("tbl_qualification q", "q.qualification_id=r.education", "left");
        $this->db->join("tbl_chating c", "c.sender_id=r.id");
        $this->db->where("(c.sender_id=" . $sender_id . " and c.receiver_id=" . $receiver_id . ") or (c.receiver_id=" . $sender_id . " and c.sender_id=" . $receiver_id . ") ");
        $this->db->order_by("c.date");
        $this->db->order_by("c.time");
        $chatreceiver = $this->db->get();

//        $this->db->select("r.id,r.name,case when r.photo='' then case when r.gender=1 then 'male.jpg' else 'female.jpg' end else r.photo end photo,r.age,h.height,q.qualification,DATE_FORMAT(c.date,'%d/%m/%Y') date,DATE_FORMAT(c.time,'%h:%i %p') time,c.status");
//        $this->db->from("tbl_registration r");
//        $this->db->join("tbl_height h","h.height_id=r.height","left");
//        $this->db->join("tbl_qualification q","q.qualification_id=r.education","left");
//        $this->db->join("tbl_chating c","c.receiver_id=r.id");
//        $this->db->where("c.sender_id",$id);
//        $this->db->where("c.receiver_id not in (select sender_id from tbl_chating where receiver_id=".$id.")");
//        $chatsender=$this->db->get();

        $result = $chatreceiver->result_array();

        $arrdata["status"] = 1;
        $this->db->where("receiver_id", $sender_id);
        $this->db->update("tbl_chating", $arrdata);

//        $chatsender=$chatsender->result_array();
//        $result= array_merge($chatreceiver,$chatsender);

        return json_encode($result);
    }
   function PushNotification(){
      include APPPATH . 'third_party/PushNotifications.php';
      

	// Message payload
	$msg_payload = array (
		'mtitle' => 'Test push notification title',
		'mdesc' => 'Test push notification body',
	);
//	
//	// For Android
	$regId = 'cGmD8hp_TSqvN25uAKPO1a:APA91bFpvxhqEjr7sniIo7ygAvGYtBt-k-BpFHYuTWxVZ7qdxia3mMgxyg_g7rfXdFLJjph124E4KuJ6MOQ-VKOHfWS6dHiriS6NUn7fysy5MiQqpfZ80VW_loaH7oEdsIko5Z0NMsFq';
        //$regId='chbfvbZrTWGGqW9Kobuljd:APA91bEHpV0ru5GZIO4Mt-FV_s1ySAgMf_xb6r-0vNrPo6Ex4SD6wbyowdKk5fDj3PmnCNLIChqTX9iBlLDhK4q4AwyVTLOBGbScvBpVjJM3x4aeLJU51XGj2nyUGdwvZpjx2q5NTi7u';
//	// For iOS
//	$deviceToken = 'FE66489F304DC75B8D6E8200DFF8A456E8DAEACEC428B427E9518741C92C6660';
//	// For WP8
//	$uri = 'http://s.notify.live.net/u/1/sin/HmQAAAD1XJMXfQ8SR0b580NcxIoD6G7hIYP9oHvjjpMC2etA7U_xy_xtSAh8tWx7Dul2AZlHqoYzsSQ8jQRQ-pQLAtKW/d2luZG93c3Bob25lZGVmYXVsdA/EKTs2gmt5BG_GB8lKdN_Rg/WuhpYBv02fAmB7tjUfF7DG9aUL4';
//	
//	// Replace the above variable values
//	
//        $push=new PushNotifications();
//        echo $push->android($msg_payload, $regId);
//        $token = $regId; // push token
//   $message = "Test notification message";
//   $this->load->library('fcm');
//   $this->fcm->setTitle('Test FCM Notification');
//   $this->fcm->setMessage($message);
//   
//   $json = $this->fcm->getPush();
//   $p = $this->fcm->send($token, $json);
//   echo $p;	
       echo $this->send($regId);
   }
   public function send($deviceid)
	{
		$device_token =$deviceid; //$this->request->getVar($deviceid);

		return $this->sendNotification($device_token,array(
                    "title"=>"Happy Nikah",
                    "body"=>"This is notification"
                ), array(
                        "click_action"=>"FLUTTER_NOTIFICATION_CLICK",
			"id" =>4,
                        "form"=>0
		));
	}

	public function sendNotification($device_token,$notification,$message)
    {
        $SERVER_API_KEY = 'AAAAi6yvty0:APA91bGbeHCnexM6qqd76TJZGgy1oj3UP8-A0GlvwEyjnNz5R7vFbSwEdXciQMTyPOQLDh340o5f1FVo14b0SwxJ2N1CEKfC9CaJTW7ynid7TZXowbVRFSZ7PjIKXgXrNgsUdGuFKC5c';
  
        // payload data, it will vary according to requirement
        $data = [
            "to" => $device_token, // for single device id
            "data" => $message,
            "notification"=>$notification
        ];
        $dataString = json_encode($data);
    
        $headers = [
            'Authorization: key=' . $SERVER_API_KEY,
            'Content-Type: application/json',
        ];
    
        $ch = curl_init();
      
        curl_setopt($ch, CURLOPT_URL, 'https://fcm.googleapis.com/fcm/send');
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $dataString);
               
        $response = curl_exec($ch);
      
        curl_close($ch);
      
        return $response;
    }
}