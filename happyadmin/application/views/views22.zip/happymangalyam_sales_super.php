<div id="app-sidepanel" class="app-sidepanel sidepanel-hidden">
			<div id="sidepanel-drop" class="sidepanel-drop"></div>
			<div class="sidepanel-inner d-flex flex-column">
				<a href="#" id="sidepanel-close" class="sidepanel-close d-xl-none">&times;</a>
					<div class="app-branding">
					<a class="app-logo" 
					href="<?php echo site_url('admin/dashboard_happymangalyam_sales_super'); ?>">
				
			  
				<img class="logo-icon me-2" src="<?php echo base_url(); ?>assets/images/hmgradient.png" 
			alt="logo"><span class="logo-text" style="font-family:Comic Sans MS, Comic Sans, cursive;color:#ef2857;font-size: 14px;">Happy Mangalyam</span></a>
				
					
						</div>

	<style type="text/css">
	.app-branding .logo-icon {
	width: 88%;
	height: 154px;
	margin-top: -45px;
	}
	</style>

				<!--//app-branding-->
				<nav id="" class="app-nav app-nav-main flex-grow-1">
					<ul class="app-menu list-unstyled accordion" id="menu-accordion">
						<li class="nav-item">
							<!--//Bootstrap Icons: https://icons.getbootstrap.com/ -->
							<a class="nav-link " href="<?php echo site_url('admin/dashboard_happymangalyam_sales_super'); ?> ">
								<span class="nav-icon">
									<svg width="1em" height="1em" viewBox="0 0 16 16" class="bi bi-house-door" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
										<path fill-rule="evenodd" d="M7.646 1.146a.5.5 0 0 1 .708 0l6 6a.5.5 0 0 1 .146.354v7a.5.5 0 0 1-.5.5H9.5a.5.5 0 0 1-.5-.5v-4H7v4a.5.5 0 0 1-.5.5H2a.5.5 0 0 1-.5-.5v-7a.5.5 0 0 1 .146-.354l6-6zM2.5 7.707V14H6v-4a.5.5 0 0 1 .5-.5h3a.5.5 0 0 1 .5.5v4h3.5V7.707L8 2.207l-5.5 5.5z" />
										<path fill-rule="evenodd" d="M13 2.5V6l-2-2V2.5a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 .5.5z" />
									</svg>
								</span>
								<span class="nav-link-text">Dashboard</span>
							</a>
							<!--//nav-link-->
						</li>
						<!--//nav-item-->
							<!--<li class="nav-item">
					       
					        <a class="nav-link" href="docs.html">
						        <span class="nav-icon">
						        <svg width="1em" height="1em" viewBox="0 0 16 16" class="bi bi-folder" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
										<path d="M9.828 4a3 3 0 0 1-2.12-.879l-.83-.828A1 1 0 0 0 6.173 2H2.5a1 1 0 0 0-1 .981L1.546 4h-1L.5 3a2 2 0 0 1 2-2h3.672a2 2 0 0 1 1.414.586l.828.828A2 2 0 0 0 9.828 3v1z"/>
										<path fill-rule="evenodd" d="M13.81 4H2.19a1 1 0 0 0-.996 1.09l.637 7a1 1 0 0 0 .995.91h10.348a1 1 0 0 0 .995-.91l.637-7A1 1 0 0 0 13.81 4zM2.19 3A2 2 0 0 0 .198 5.181l.637 7A2 2 0 0 0 2.826 14h10.348a2 2 0 0 0 1.991-1.819l.637-7A2 2 0 0 0 13.81 3H2.19z"/>
										</svg>
						         </span>
		                         <span class="nav-link-text">Docs</span>
					        </a>
					    </li> -->
			
			
			
			
			
				<li class="nav-item">
					<!--//Bootstrap Icons: https://icons.getbootstrap.com/ -->
					<a class="nav-link" href="<?php echo site_url('admin/search_profiles') ?>">
						<span class="nav-icon">
							<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-search-heart" viewBox="0 0 16 16">
								<path d="M6.5 4.482c1.664-1.673 5.825 1.254 0 5.018-5.825-3.764-1.664-6.69 0-5.018Z" />
								<path d="M13 6.5a6.471 6.471 0 0 1-1.258 3.844c.04.03.078.062.115.098l3.85 3.85a1 1 0 0 1-1.414 1.415l-3.85-3.85a1.007 1.007 0 0 1-.1-.115h.002A6.5 6.5 0 1 1 13 6.5ZM6.5 12a5.5 5.5 0 1 0 0-11 5.5 5.5 0 0 0 0 11Z" />
							</svg>
						</span>
						<span class="nav-link-text">Search Profile</span>
					</a>
					<!--//nav-link-->
				</li>
				
					    
            
            
            <!--<li class="nav-item">-->
     
            <!--<a class="nav-link" href="<?php echo site_url('admin/quickregister_gotonikah'); ?>">-->
            <!--<span class="nav-icon">-->
            <!--<svg width="1em" height="1em" viewBox="0 0 16 16" class="bi bi-card-list" fill="currentColor" xmlns="http://www.w3.org/2000/svg">-->
            <!--<path fill-rule="evenodd" d="M14.5 3h-13a.5.5 0 0 0-.5.5v9a.5.5 0 0 0 .5.5h13a.5.5 0 0 0 .5-.5v-9a.5.5 0 0 0-.5-.5zm-13-1A1.5 1.5 0 0 0 0 3.5v9A1.5 1.5 0 0 0 1.5 14h13a1.5 1.5 0 0 0 1.5-1.5v-9A1.5 1.5 0 0 0 14.5 2h-13z" />-->
            <!--<path fill-rule="evenodd" d="M5 8a.5.5 0 0 1 .5-.5h7a.5.5 0 0 1 0 1h-7A.5.5 0 0 1 5 8zm0-2.5a.5.5 0 0 1 .5-.5h7a.5.5 0 0 1 0 1h-7a.5.5 0 0 1-.5-.5zm0 5a.5.5 0 0 1 .5-.5h7a.5.5 0 0 1 0 1h-7a.5.5 0 0 1-.5-.5z" />-->
            <!--<circle cx="3.5" cy="5.5" r=".5" />-->
            <!--<circle cx="3.5" cy="8" r=".5" />-->
            <!--<circle cx="3.5" cy="10.5" r=".5" />-->
            <!--</svg>-->
            <!--</span>-->
            <!--<span class="nav-link-text">Quick Profiles</span>-->
            <!--</a>-->
      
            <!--</li>-->
    
         
				
				
				
			


				<!-- <li class="nav-item"> -->
				<!--//Bootstrap Icons: https://icons.getbootstrap.com/ -->
				<!-- <a class="nav-link" href="<?php echo site_url('admin/photoapprove'); ?>">
 						<span class="nav-icon">
 							<svg width="1em" height="1em" viewBox="0 0 16 16" class="bi bi-file-person" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
 								<path fill-rule="evenodd" d="M12 1H4a1 1 0 0 0-1 1v10.755S4 11 8 11s5 1.755 5 1.755V2a1 1 0 0 0-1-1zM4 0a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2H4z"></path>
 								<path fill-rule="evenodd" d="M8 10a3 3 0 1 0 0-6 3 3 0 0 0 0 6z"></path>
 							</svg>
 						</span>
 						<span class="nav-link-text">Photo Uploads</span>
 					</a> -->
				<!--//nav-link-->
				<!-- </li> -->
				<!--//nav-item-->
				
				

           
                <!--<li class="nav-item has-submenu">-->
                
                <!--<a class="nav-link submenu-toggle" href="#" data-bs-toggle="collapse" data-bs-target="#submenu-1" aria-expanded="true" aria-controls="submenu-1">-->
                <!--<span class="nav-icon">-->
                
                <!--<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-person-check" viewBox="0 0 16 16">-->
                <!--<path d="M12.5 16a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7Zm1.679-4.493-1.335 2.226a.75.75 0 0 1-1.174.144l-.774-.773a.5.5 0 0 1 .708-.708l.547.548 1.17-1.951a.5.5 0 1 1 .858.514ZM11 5a3 3 0 1 1-6 0 3 3 0 0 1 6 0ZM8 7a2 2 0 1 0 0-4 2 2 0 0 0 0 4Z" />-->
                <!--<path d="M8.256 14a4.474 4.474 0 0 1-.229-1.004H3c.001-.246.154-.986.832-1.664C4.484 10.68 5.711 10 8 10c.26 0 .507.009.74.025.226-.341.496-.65.804-.918C9.077 9.038 8.564 9 8 9c-5 0-6 3-6 4s1 1 1 1h5.256Z" />-->
                <!--</svg>-->
                <!--</span>-->
                <!--<span class="nav-link-text">Approvels</span>-->
                <!--<span class="submenu-arrow">-->
                <!--<svg width="1em" height="1em" viewBox="0 0 16 16" class="bi bi-chevron-down" fill="currentColor" xmlns="http://www.w3.org/2000/svg">-->
                <!--<path fill-rule="evenodd" d="M1.646 4.646a.5.5 0 0 1 .708 0L8 10.293l5.646-5.647a.5.5 0 0 1 .708.708l-6 6a.5.5 0 0 1-.708 0l-6-6a.5.5 0 0 1 0-.708z"></path>-->
                <!--</svg>-->
                <!--</span>-->
                
                <!--</a>-->
                
                <!--<div id="submenu-1" class="collapse submenu submenu-1" data-bs-parent="#menu-accordion">-->
                <!--<ul class="submenu-list list-unstyled">-->
                <!--<li class="submenu-item"><a class="submenu-link" style="text-decoration: none;" href="<?php echo site_url('admin/users_gotonikah/profile_approval'); ?>"> Profile Approvels</a></li>-->
                <!--<li class="submenu-item"><a class="submenu-link" style="text-decoration: none;" href="<?php echo site_url('admin/photoapprove_gotonikah'); ?>">Photo Approvels </a></li>-->
                <!--<li class="submenu-item"><a class="submenu-link" style="text-decoration: none;" href="<?php echo site_url('admin/users_gotonikah/3'); ?>">Deleted Profile</a></li>-->
                <!--<li class="submenu-item"><a class="submenu-link" style="text-decoration: none;" href="<?php echo site_url('admin/users_gotonikah/1'); ?>">Approved Profile-->
                <!--</a></li>-->
                
                <!--</ul>-->
                <!--</div>-->
                <!--</li>-->
			
				
				
				
                        <li class="nav-item has-submenu">
                        
                        <a class="nav-link submenu-toggle" href="#" data-bs-toggle="collapse" data-bs-target="#submenu-11" aria-expanded="true" aria-controls="submenu-11">
                        <span class="nav-icon">
                        
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-pen" viewBox="0 0 16 16">
                        <path d="m13.498.795.149-.149a1.207 1.207 0 1 1 1.707 1.708l-.149.148a1.5 1.5 0 0 1-.059 2.059L4.854 14.854a.5.5 0 0 1-.233.131l-4 1a.5.5 0 0 1-.606-.606l1-4a.5.5 0 0 1 .131-.232l9.642-9.642a.5.5 0 0 0-.642.056L6.854 4.854a.5.5 0 1 1-.708-.708L9.44.854A1.5 1.5 0 0 1 11.5.796a1.5 1.5 0 0 1 1.998-.001zm-.644.766a.5.5 0 0 0-.707 0L1.95 11.756l-.764 3.057 3.057-.764L14.44 3.854a.5.5 0 0 0 0-.708l-1.585-1.585z" />
                        </svg>
                        </span>
                        <span class="nav-link-text">Paid Creation</span>
                        <span class="submenu-arrow">
                        <svg width="1em" height="1em" viewBox="0 0 16 16" class="bi bi-chevron-down" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                        <path fill-rule="evenodd" d="M1.646 4.646a.5.5 0 0 1 .708 0L8 10.293l5.646-5.647a.5.5 0 0 1 .708.708l-6 6a.5.5 0 0 1-.708 0l-6-6a.5.5 0 0 1 0-.708z"></path>
                        </svg>
                        </span>
                        
                        </a>
                        
                        <div id="submenu-11" class="collapse submenu submenu-11" data-bs-parent="#menu-accordion">
                        <ul class="submenu-list list-unstyled">
                  <li class="submenu-item"><a class="submenu-link" style="text-decoration: none;" href="<?php echo site_url('admin/tdypaymentcreation_mangalyam'); ?>">Today's Sale
                        </a></li>
                        
                        </ul>
                        <ul class="submenu-list list-unstyled">
                        <li class="submenu-item"><a class="submenu-link" style="text-decoration: none;" href="<?php echo site_url('admin/totalpaymentcreation_mangalyam'); ?>">Total Sale
                        </a></li>
                        
                        </ul>
                        </div>
                        </li>
						
				
				
				
				
				 <li class="nav-item">
                <!--//Bootstrap Icons: https://icons.getbootstrap.com/ -->
                <a class="nav-link " href="<?php echo site_url('admin/assign_target_mangalyam'); ?>">
                <span class="nav-icon">
                
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-wallet2" viewBox="0 0 16 16">
            <path d="M12.136.326A1.5 1.5 0 0 1 14 1.78V3h.5A1.5 1.5 0 0 1 16 4.5v9a1.5 1.5 0 0 1-1.5 1.5h-13A1.5 1.5 0 0 1 0 13.5v-9a1.5 1.5 0 0 1 1.432-1.499L12.136.326zM5.562 3H13V1.78a.5.5 0 0 0-.621-.484L5.562 3zM1.5 4a.5.5 0 0 0-.5.5v9a.5.5 0 0 0 .5.5h13a.5.5 0 0 0 .5-.5v-9a.5.5 0 0 0-.5-.5h-13z"/>
                </svg>
                </span>
                <span class="nav-link-text">Assign Target</span>
                </a>
                <!--//nav-link-->
                </li>
                
                
                 <li class="nav-item">
                <!--//Bootstrap Icons: https://icons.getbootstrap.com/ -->
                <a class="nav-link " href="<?php echo site_url('admin/assign_approve_calls_mangalyam'); ?>">
                <span class="nav-icon">
                
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-wallet2" viewBox="0 0 16 16">
            <path d="M12.136.326A1.5 1.5 0 0 1 14 1.78V3h.5A1.5 1.5 0 0 1 16 4.5v9a1.5 1.5 0 0 1-1.5 1.5h-13A1.5 1.5 0 0 1 0 13.5v-9a1.5 1.5 0 0 1 1.432-1.499L12.136.326zM5.562 3H13V1.78a.5.5 0 0 0-.621-.484L5.562 3zM1.5 4a.5.5 0 0 0-.5.5v9a.5.5 0 0 0 .5.5h13a.5.5 0 0 0 .5-.5v-9a.5.5 0 0 0-.5-.5h-13z"/>
                </svg>
                </span>
                <span class="nav-link-text">Assign Approve Calls</span>
                </a>
                <!--//nav-link-->
                </li>
                
                
                 <li class="nav-item">
                <!--//Bootstrap Icons: https://icons.getbootstrap.com/ -->
     <a class="nav-link " href="<?php echo site_url('admin/assign_active_calls_mangalyam'); ?>">
                <span class="nav-icon">
                
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-wallet2" viewBox="0 0 16 16">
              <path d="M12.136.326A1.5 1.5 0 0 1 14 1.78V3h.5A1.5 1.5 0 0 1 16 4.5v9a1.5 1.5 0 0 1-1.5 1.5h-13A1.5 1.5 0 0 1 0 13.5v-9a1.5 1.5 0 0 1 1.432-1.499L12.136.326zM5.562 3H13V1.78a.5.5 0 0 0-.621-.484L5.562 3zM1.5 4a.5.5 0 0 0-.5.5v9a.5.5 0 0 0 .5.5h13a.5.5 0 0 0 .5-.5v-9a.5.5 0 0 0-.5-.5h-13z"/>
                </svg>
                </span>
                <span class="nav-link-text">Assign Active Calls</span>
                </a>
                <!--//nav-link-->
                </li>
                
                
              <!--  <li class="nav-item">-->
            
              <!--  <a class="nav-link " href="<?php echo site_url('admin/profilephoto_unavailable_gotonikah'); ?>">-->
              <!--  <span class="nav-icon">-->
                
              <!--  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-wallet2" viewBox="0 0 16 16">-->
              <!--<path d="M12.136.326A1.5 1.5 0 0 1 14 1.78V3h.5A1.5 1.5 0 0 1 16 4.5v9a1.5 1.5 0 0 1-1.5 1.5h-13A1.5 1.5 0 0 1 0 13.5v-9a1.5 1.5 0 0 1 1.432-1.499L12.136.326zM5.562 3H13V1.78a.5.5 0 0 0-.621-.484L5.562 3zM1.5 4a.5.5 0 0 0-.5.5v9a.5.5 0 0 0 .5.5h13a.5.5 0 0 0 .5-.5v-9a.5.5 0 0 0-.5-.5h-13z"/>-->
              <!--  </svg>-->
              <!--  </span>-->
              <!--  <span class="nav-link-text">Unavailbale Profile Photos</span>-->
              <!--  </a>-->
            
              <!--  </li>-->
                
                
                
                
                	<li class="nav-item has-submenu">
							<!--//Bootstrap Icons: https://icons.getbootstrap.com/ -->
							<a class="nav-link submenu-toggle" href="#" data-bs-toggle="collapse" data-bs-target="#submenu-12" aria-expanded="true" aria-controls="submenu-12">
								<span class="nav-icon">
									<!--//Bootstrap Icons: https://icons.getbootstrap.com/ -->
									<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-pen" viewBox="0 0 16 16">
										<path d="m13.498.795.149-.149a1.207 1.207 0 1 1 1.707 1.708l-.149.148a1.5 1.5 0 0 1-.059 2.059L4.854 14.854a.5.5 0 0 1-.233.131l-4 1a.5.5 0 0 1-.606-.606l1-4a.5.5 0 0 1 .131-.232l9.642-9.642a.5.5 0 0 0-.642.056L6.854 4.854a.5.5 0 1 1-.708-.708L9.44.854A1.5 1.5 0 0 1 11.5.796a1.5 1.5 0 0 1 1.998-.001zm-.644.766a.5.5 0 0 0-.707 0L1.95 11.756l-.764 3.057 3.057-.764L14.44 3.854a.5.5 0 0 0 0-.708l-1.585-1.585z" />
									</svg>
								</span>
								<span class="nav-link-text">Data Report</span>
								<span class="submenu-arrow">
									<svg width="1em" height="1em" viewBox="0 0 16 16" class="bi bi-chevron-down" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
										<path fill-rule="evenodd" d="M1.646 4.646a.5.5 0 0 1 .708 0L8 10.293l5.646-5.647a.5.5 0 0 1 .708.708l-6 6a.5.5 0 0 1-.708 0l-6-6a.5.5 0 0 1 0-.708z"></path>
									</svg>
								</span>
								<!--//submenu-arrow-->
							</a>
							<!--//nav-link-->


							
				<div id="submenu-12" class="collapse submenu submenu-12" data-bs-parent="#menu-accordion">
				<ul class="submenu-list list-unstyled">
				<li class="submenu-item"><a class="submenu-link" style="text-decoration: none;" href="<?php echo site_url('admin/total_calls_mangalyam'); ?>">
				Total Calls
				</a></li>

				</ul>
				<ul class="submenu-list list-unstyled">
				<li class="submenu-item"><a class="submenu-link" style="text-decoration: none;" href="<?php echo site_url('admin/total_postpone_mangalyam'); ?>">
				Total Postpone
				</a></li>

				</ul>
				</div>
				</li>




            <!--<li class="nav-item">-->
         
            <!--<a class="nav-link" href="<?php echo site_url('admin/staff_create'); ?>">-->
            <!--<span class="nav-icon">-->
            
            <!--<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-person-check" viewBox="0 0 16 16">-->
            <!--<path d="M12.5 16a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7Zm1.679-4.493-1.335 2.226a.75.75 0 0 1-1.174.144l-.774-.773a.5.5 0 0 1 .708-.708l.547.548 1.17-1.951a.5.5 0 1 1 .858.514ZM11 5a3 3 0 1 1-6 0 3 3 0 0 1 6 0ZM8 7a2 2 0 1 0 0-4 2 2 0 0 0 0 4Z"></path>-->
            <!--<path d="M8.256 14a4.474 4.474 0 0 1-.229-1.004H3c.001-.246.154-.986.832-1.664C4.484 10.68 5.711 10 8 10c.26 0 .507.009.74.025.226-.341.496-.65.804-.918C9.077 9.038 8.564 9 8 9c-5 0-6 3-6 4s1 1 1 1h5.256Z"></path>-->
            <!--</svg>-->
            
            <!--</span>-->
            <!--<span class="nav-link-text">Staff Creation</span>-->
            <!--</a>-->
          
            <!--</li>-->
                
            
		<li class="nav-item has-submenu">
		<!--//Bootstrap Icons: https://icons.getbootstrap.com/ -->
		<a class="nav-link submenu-toggle" href="#" data-bs-toggle="collapse" data-bs-target="#submenu-10" aria-expanded="true" aria-controls="submenu-1">
		<span class="nav-icon">
		<!--//Bootstrap Icons: https://icons.getbootstrap.com/ -->

		<svg width="1em" height="1em" viewBox="0 0 16 16" class="bi bi-card-list" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
		<path fill-rule="evenodd" d="M14.5 3h-13a.5.5 0 0 0-.5.5v9a.5.5 0 0 0 .5.5h13a.5.5 0 0 0 .5-.5v-9a.5.5 0 0 0-.5-.5zm-13-1A1.5 1.5 0 0 0 0 3.5v9A1.5 1.5 0 0 0 1.5 14h13a1.5 1.5 0 0 0 1.5-1.5v-9A1.5 1.5 0 0 0 14.5 2h-13z" />
		<path fill-rule="evenodd" d="M5 8a.5.5 0 0 1 .5-.5h7a.5.5 0 0 1 0 1h-7A.5.5 0 0 1 5 8zm0-2.5a.5.5 0 0 1 .5-.5h7a.5.5 0 0 1 0 1h-7a.5.5 0 0 1-.5-.5zm0 5a.5.5 0 0 1 .5-.5h7a.5.5 0 0 1 0 1h-7a.5.5 0 0 1-.5-.5z" />
		<circle cx="3.5" cy="5.5" r=".5" />
		<circle cx="3.5" cy="8" r=".5" />
		<circle cx="3.5" cy="10.5" r=".5" />
		</svg>

		</span>
		<span class="nav-link-text">Profile Approval</span>
		<span class="submenu-arrow">
		<svg width="1em" height="1em" viewBox="0 0 16 16" class="bi bi-chevron-down" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
		<path fill-rule="evenodd" d="M1.646 4.646a.5.5 0 0 1 .708 0L8 10.293l5.646-5.647a.5.5 0 0 1 .708.708l-6 6a.5.5 0 0 1-.708 0l-6-6a.5.5 0 0 1 0-.708z"></path>
		</svg>
		</span>
		<!--//submenu-arrow-->
		</a>
		<!--//nav-link-->
		<div id="submenu-10" class="collapse submenu submenu-10" data-bs-parent="#menu-accordion">
		<ul class="submenu-list list-unstyled">
		<li class="submenu-item"><a class="submenu-link" style="text-decoration: none;" href="<?php echo site_url('admin/quickregister_mangalyam'); ?>">
		Quick Register
		</a></li>

		</ul>
		<ul class="submenu-list list-unstyled">
		<li class="submenu-item"><a class="submenu-link" style="text-decoration: none;" href="<?php echo site_url('admin/stagethree_mangalyam'); ?>">
		Stage Three
		</a></li>

		</ul>
		<ul class="submenu-list list-unstyled">
		<li class="submenu-item"><a class="submenu-link" style="text-decoration: none;" href="<?php echo site_url('admin/Gulfdata_mangalyam'); ?>">
		Gulf Approvels
		</a></li>

		</ul>
		</div>
		</li>	

						
						
						
						         
                    <li class="nav-item has-submenu">
                    <a class="nav-link submenu-toggle" href="#" data-bs-toggle="collapse" data-bs-target="#submenu-17" aria-expanded="true" aria-controls="submenu-17">
                    <span class="nav-icon">
                    <!--<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-pen" viewBox="0 0 16 16">-->
                    <!--<path d="m13.498.795.149-.149a1.207 1.207 0 1 1 1.707 1.708l-.149.148a1.5 1.5 0 0 1-.059 2.059L4.854 14.854a.5.5 0 0 1-.233.131l-4 1a.5.5 0 0 1-.606-.606l1-4a.5.5 0 0 1 .131-.232l9.642-9.642a.5.5 0 0 0-.642.056L6.854 4.854a.5.5 0 1 1-.708-.708L9.44.854A1.5 1.5 0 0 1 11.5.796a1.5 1.5 0 0 1 1.998-.001zm-.644.766a.5.5 0 0 0-.707 0L1.95 11.756l-.764 3.057 3.057-.764L14.44 3.854a.5.5 0 0 0 0-.708l-1.585-1.585z" />-->
                    <!--</svg>-->
                    
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-person-check" viewBox="0 0 16 16">
                <path d="M12.5 16a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7Zm1.679-4.493-1.335 2.226a.75.75 0 0 1-1.174.144l-.774-.773a.5.5 0 0 1 .708-.708l.547.548 1.17-1.951a.5.5 0 1 1 .858.514ZM11 5a3 3 0 1 1-6 0 3 3 0 0 1 6 0ZM8 7a2 2 0 1 0 0-4 2 2 0 0 0 0 4Z"></path>
                <path d="M8.256 14a4.474 4.474 0 0 1-.229-1.004H3c.001-.246.154-.986.832-1.664C4.484 10.68 5.711 10 8 10c.26 0 .507.009.74.025.226-.341.496-.65.804-.918C9.077 9.038 8.564 9 8 9c-5 0-6 3-6 4s1 1 1 1h5.256Z"></path>
                </svg>
                
                    </span>
                    <span class="nav-link-text">Support Admin</span>
                    <span class="submenu-arrow">
                    <svg width="1em" height="1em" viewBox="0 0 16 16" class="bi bi-chevron-down" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                    <path fill-rule="evenodd" d="M1.646 4.646a.5.5 0 0 1 .708 0L8 10.293l5.646-5.647a.5.5 0 0 1 .708.708l-6 6a.5.5 0 0 1-.708 0l-6-6a.5.5 0 0 1 0-.708z"></path>
                    </svg>
                    </span>
                    <!--//submenu-arrow-->
                    </a>
                    <!--//nav-link-->
                    <div id="submenu-17" class="collapse submenu submenu-17" data-bs-parent="#menu-accordion">
                  
                    <ul class="submenu-list list-unstyled">
                    <li class="submenu-item"><a class="submenu-link" style="text-decoration: none;" href="<?php echo site_url('admin/photoapprove_mangalyam'); ?>">
                    Photo Approvels
                    </a></li>
                    
                    </ul>
                    
                     
                     <ul class="submenu-list list-unstyled">
                    <li class="submenu-item">
                    <a class="submenu-link" style="text-decoration: none;" href="<?php echo site_url('admin/profile_approve_all_mangalyam'); ?>">
                    Approved Profile
                    </a></li>
                    
                    </ul>
                    
                    <ul class="submenu-list list-unstyled">
                    <li class="submenu-item"><a class="submenu-link" style="text-decoration: none;" href="<?php echo site_url('admin/profile_deleted_all_mangalyam'); ?>">
                    Deleted Profile
                    </a></li>
                    
                    </ul>
                    <ul class="submenu-list list-unstyled">
                    <li class="submenu-item"><a class="submenu-link" style="text-decoration: none;" href="<?php echo site_url('admin/profilephoto_unavailable_mangalyam'); ?>">
                    Unavailbale Profile Photos
                    </a></li>
                    
                    </ul>
                    <ul class="submenu-list list-unstyled">
                    <li class="submenu-item"><a class="submenu-link" style="text-decoration: none;" href="<?php echo site_url('admin/reportid_mangalyam'); ?>">
                    Report ID's
                    </a></li>
                    
                    </ul>
                    <ul class="submenu-list list-unstyled">
                    <li class="submenu-item"><a class="submenu-link" style="text-decoration: none;" href="<?php echo site_url('admin/update_logs_mangalyam'); ?>">
                    Profile Verification
                    </a></li>
                    
                    </ul>
                    
                    <ul class="submenu-list list-unstyled">
                    <li class="submenu-item">
                    <a class="submenu-link" style="text-decoration: none;" href="<?php echo site_url('admin/otherstate_mangalyam'); ?>">
                    Other State
                    </a>
                    </li>
                    </ul>
                    
                    
                       <ul class="submenu-list list-unstyled">
                    <li class="submenu-item">
                    <a class="submenu-link" style="text-decoration: none;" href="<?php echo site_url('admin/refer_and_earn_mangalyam'); ?>">
                    Refer And Earn
                    </a>
                    </li>
                    </ul>
                    
                    </div>
                    </li>
                    
                    
                           
                      <li class="nav-item has-submenu">
                    <a class="nav-link submenu-toggle" href="#" data-bs-toggle="collapse" data-bs-target="#submenu-28" aria-expanded="true" aria-controls="submenu-18">
                    
                 
                    
                    <span class="nav-icon">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-pen" viewBox="0 0 16 16">
                    <path d="m13.498.795.149-.149a1.207 1.207 0 1 1 1.707 1.708l-.149.148a1.5 1.5 0 0 1-.059 2.059L4.854 14.854a.5.5 0 0 1-.233.131l-4 1a.5.5 0 0 1-.606-.606l1-4a.5.5 0 0 1 .131-.232l9.642-9.642a.5.5 0 0 0-.642.056L6.854 4.854a.5.5 0 1 1-.708-.708L9.44.854A1.5 1.5 0 0 1 11.5.796a1.5 1.5 0 0 1 1.998-.001zm-.644.766a.5.5 0 0 0-.707 0L1.95 11.756l-.764 3.057 3.057-.764L14.44 3.854a.5.5 0 0 0 0-.708l-1.585-1.585z" />
                    </svg>
                    </span>
                    <span class="nav-link-text">ChatSupport Admin</span>
                    <span class="submenu-arrow">
                    <svg width="1em" height="1em" viewBox="0 0 16 16" class="bi bi-chevron-down" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                    <path fill-rule="evenodd" d="M1.646 4.646a.5.5 0 0 1 .708 0L8 10.293l5.646-5.647a.5.5 0 0 1 .708.708l-6 6a.5.5 0 0 1-.708 0l-6-6a.5.5 0 0 1 0-.708z"></path>
                    </svg>
                    </span>
                    <!--//submenu-arrow-->
                    </a>
                    <!--//nav-link-->
                    <div id="submenu-28" class="collapse submenu submenu-28" data-bs-parent="#menu-accordion">
                  
                    <ul class="submenu-list list-unstyled">
                    <li class="submenu-item"><a class="submenu-link" style="text-decoration: none;" href="<?php echo site_url('admin/doorstepcollection_mangalyam'); ?>">
                    Door Step Collection
                    </a></li>
                    
                    </ul>
                    <ul class="submenu-list list-unstyled">
                    <li class="submenu-item"><a class="submenu-link" style="text-decoration: none;" href="<?php echo site_url('admin/paymentvisitcount_mangalyam'); ?>">
                    Payment Page Visit
                    </a></li>
                    
                    </ul>
                    
                                        <!--<ul class="submenu-list list-unstyled">-->
                    <!--<li class="submenu-item"><a class="submenu-link" style="text-decoration: none;" href="<?php echo site_url('admin/paymentsupport'); ?>">-->
                    <!--  Payment Support-->
                    <!--</a></li>-->
                    
                    <!--</ul>          -->
                    
								
                    </div>
                    </li>
                    
                    
                    
         
            
            <li class="nav-item has-submenu">
                    <a class="nav-link submenu-toggle" href="#" data-bs-toggle="collapse" data-bs-target="#submenu-29" aria-expanded="true" aria-controls="submenu-19">                  
                    <span class="nav-icon">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-pen" viewBox="0 0 16 16">
                    <path d="m13.498.795.149-.149a1.207 1.207 0 1 1 1.707 1.708l-.149.148a1.5 1.5 0 0 1-.059 2.059L4.854 14.854a.5.5 0 0 1-.233.131l-4 1a.5.5 0 0 1-.606-.606l1-4a.5.5 0 0 1 .131-.232l9.642-9.642a.5.5 0 0 0-.642.056L6.854 4.854a.5.5 0 1 1-.708-.708L9.44.854A1.5 1.5 0 0 1 11.5.796a1.5 1.5 0 0 1 1.998-.001zm-.644.766a.5.5 0 0 0-.707 0L1.95 11.756l-.764 3.057 3.057-.764L14.44 3.854a.5.5 0 0 0 0-.708l-1.585-1.585z" />
                    </svg>
                    </span>
                    <span class="nav-link-text">District Count</span>
                    <span class="submenu-arrow">
                    <svg width="1em" height="1em" viewBox="0 0 16 16" class="bi bi-chevron-down" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                    <path fill-rule="evenodd" d="M1.646 4.646a.5.5 0 0 1 .708 0L8 10.293l5.646-5.647a.5.5 0 0 1 .708.708l-6 6a.5.5 0 0 1-.708 0l-6-6a.5.5 0 0 1 0-.708z"></path>
                    </svg>
                    </span>
                    <!--//submenu-arrow-->
                    </a>
                    <!--//nav-link-->
                    <div id="submenu-29" class="collapse submenu submenu-29" data-bs-parent="#menu-accordion">
                  
                    <ul class="submenu-list list-unstyled">
                    <li class="submenu-item"><a class="submenu-link" style="text-decoration: none;" href="<?php echo site_url('admin/district_count_female_mangalyam'); ?>">
                    District Female
                    </a></li>
                    
                    </ul>
                    <ul class="submenu-list list-unstyled">
                    <li class="submenu-item"><a class="submenu-link" style="text-decoration: none;" href="<?php echo site_url('admin/district_count_male_mangalyam'); ?>">
                   District Male
                    </a></li>
                    
                    </ul>
                    </div>
                    </li>
                    
                    <li class="nav-item has-submenu">
                    <a class="nav-link submenu-toggle" href="#" data-bs-toggle="collapse" data-bs-target="#submenu-30" aria-expanded="true" aria-controls="submenu-21">
                                      
                    <span class="nav-icon">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-pen" viewBox="0 0 16 16">
                    <path d="m13.498.795.149-.149a1.207 1.207 0 1 1 1.707 1.708l-.149.148a1.5 1.5 0 0 1-.059 2.059L4.854 14.854a.5.5 0 0 1-.233.131l-4 1a.5.5 0 0 1-.606-.606l1-4a.5.5 0 0 1 .131-.232l9.642-9.642a.5.5 0 0 0-.642.056L6.854 4.854a.5.5 0 1 1-.708-.708L9.44.854A1.5 1.5 0 0 1 11.5.796a1.5 1.5 0 0 1 1.998-.001zm-.644.766a.5.5 0 0 0-.707 0L1.95 11.756l-.764 3.057 3.057-.764L14.44 3.854a.5.5 0 0 0 0-.708l-1.585-1.585z" />
                    </svg>
                    </span>
                    <span class="nav-link-text">Date Vise Profiles</span>
                    <span class="submenu-arrow">
                    <svg width="1em" height="1em" viewBox="0 0 16 16" class="bi bi-chevron-down" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                    <path fill-rule="evenodd" d="M1.646 4.646a.5.5 0 0 1 .708 0L8 10.293l5.646-5.647a.5.5 0 0 1 .708.708l-6 6a.5.5 0 0 1-.708 0l-6-6a.5.5 0 0 1 0-.708z"></path>
                    </svg>
                    </span>
                    <!--//submenu-arrow-->
                    </a>
                    <!--//nav-link-->
                    <div id="submenu-30" class="collapse submenu submenu-30" data-bs-parent="#menu-accordion">
                  
                    <ul class="submenu-list list-unstyled">
                    <li class="submenu-item"><a class="submenu-link" style="text-decoration: none;" href="<?php echo site_url('admin/date_count_female_mangalyam'); ?>">
                    Date Vise Female Profiles
                    </a></li>
                    
                    </ul>
                    <ul class="submenu-list list-unstyled">
                    <li class="submenu-item"><a class="submenu-link" style="text-decoration: none;" href="<?php echo site_url('admin/date_count_male_mangalyam'); ?>">
                    Date Vise Male Profiles
                    </a></li>
                    
                    </ul>
                    </div>
                    </li>  
                    
                        <li class="nav-item">           
            <a class="nav-link" href="<?php echo site_url('admin/multiple_contacts_mangalyam'); ?>">
            <span class="nav-icon">            
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-person-check" viewBox="0 0 16 16">
            <path d="M12.5 16a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7Zm1.679-4.493-1.335 2.226a.75.75 0 0 1-1.174.144l-.774-.773a.5.5 0 0 1 .708-.708l.547.548 1.17-1.951a.5.5 0 1 1 .858.514ZM11 5a3 3 0 1 1-6 0 3 3 0 0 1 6 0ZM8 7a2 2 0 1 0 0-4 2 2 0 0 0 0 4Z"></path>
            <path d="M8.256 14a4.474 4.474 0 0 1-.229-1.004H3c.001-.246.154-.986.832-1.664C4.484 10.68 5.711 10 8 10c.26 0 .507.009.74.025.226-.341.496-.65.804-.918C9.077 9.038 8.564 9 8 9c-5 0-6 3-6 4s1 1 1 1h5.256Z"></path>
            </svg>
            
            </span>
            <span class="nav-link-text">Customer Viewed Count</span>
            </a>
            <!--//nav-link-->
            </li>
            
            
          
	<li class="nav-item">           
	<a class="nav-link" href="<?php echo site_url('admin/contact_viewed_search_mangalyam'); ?>">
	<span class="nav-icon">            
	<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-person-check" viewBox="0 0 16 16">
	<path d="M12.5 16a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7Zm1.679-4.493-1.335 2.226a.75.75 0 0 1-1.174.144l-.774-.773a.5.5 0 0 1 .708-.708l.547.548 1.17-1.951a.5.5 0 1 1 .858.514ZM11 5a3 3 0 1 1-6 0 3 3 0 0 1 6 0ZM8 7a2 2 0 1 0 0-4 2 2 0 0 0 0 4Z"></path>
	<path d="M8.256 14a4.474 4.474 0 0 1-.229-1.004H3c.001-.246.154-.986.832-1.664C4.484 10.68 5.711 10 8 10c.26 0 .507.009.74.025.226-.341.496-.65.804-.918C9.077 9.038 8.564 9 8 9c-5 0-6 3-6 4s1 1 1 1h5.256Z"></path>
	</svg>        
	</span>
	<span class="nav-link-text">Viewed Contacts</span>
	</a>
	<!--//nav-link-->
	</li>
            
            
            

<!--   <li class="nav-item">-->
         
<!--            <a class="nav-link" href="<?php echo site_url('admin/changepass2'); ?>">-->
<!--            <span class="nav-icon">-->
            
<!--           <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-key" viewBox="0 0 16 16">-->
<!--  <path d="M0 8a4 4 0 0 1 7.465-2H14a.5.5 0 0 1 .354.146l1.5 1.5a.5.5 0 0 1 0 .708l-1.5 1.5a.5.5 0 0 1-.708 0L13 9.207l-.646.647a.5.5 0 0 1-.708 0L11 9.207l-.646.647a.5.5 0 0 1-.708 0L9 9.207l-.646.647A.5.5 0 0 1 8 10h-.535A4 4 0 0 1 0 8zm4-3a3 3 0 1 0 2.712 4.285A.5.5 0 0 1 7.163 9h.63l.853-.854a.5.5 0 0 1 .708 0l.646.647.646-.647a.5.5 0 0 1 .708 0l.646.647.646-.647a.5.5 0 0 1 .708 0l.646.647.793-.793-1-1h-6.63a.5.5 0 0 1-.451-.285A3 3 0 0 0 4 5z"/>-->
<!--  <path d="M4 8a1 1 0 1 1-2 0 1 1 0 0 1 2 0z"/>-->
<!--</svg>-->
            
<!--            </span>-->
<!--            <span class="nav-link-text">Change Password</span>-->
<!--            </a>-->
        
<!--            </li>-->



				<!--<li class="nav-item">-->
				
				<!--	<a class="nav-link" href="<?php echo site_url('admin/bucket_change'); ?>">-->
				<!--		<span class="nav-icon">-->
				<!--			<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-pencil-square" viewBox="0 0 16 16">-->
				<!--				<path d="M15.502 1.94a.5.5 0 0 1 0 .706L14.459 3.69l-2-2L13.502.646a.5.5 0 0 1 .707 0l1.293 1.293zm-1.75 2.456-2-2L4.939 9.21a.5.5 0 0 0-.121.196l-.805 2.414a.25.25 0 0 0 .316.316l2.414-.805a.5.5 0 0 0 .196-.12l6.813-6.814z" />-->
				<!--				<path fill-rule="evenodd" d="M1 13.5A1.5 1.5 0 0 0 2.5 15h11a1.5 1.5 0 0 0 1.5-1.5v-6a.5.5 0 0 0-1 0v6a.5.5 0 0 1-.5.5h-11a.5.5 0 0 1-.5-.5v-11a.5.5 0 0 1 .5-.5H9a.5.5 0 0 0 0-1H2.5A1.5 1.5 0 0 0 1 2.5v11z" />-->
				<!--			</svg>-->
				<!--		</span>-->
				<!--		<span class="nav-link-text">Bucket Change</span>-->
				<!--	</a>-->
				
				<!--</li>-->
				
				
          
				<!-- <li class="nav-item"> -->
				<!--//Bootstrap Icons: https://icons.getbootstrap.com/ -->
				<!-- <a class="nav-link" href="<?php echo site_url('admin/paymentsetting'); ?>">
 						<span class="nav-icon">
 							<svg width="1em" height="1em" viewBox="0 0 16 16" class="bi bi-gear" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
 								<path fill-rule="evenodd" d="M8.837 1.626c-.246-.835-1.428-.835-1.674 0l-.094.319A1.873 1.873 0 0 1 4.377 3.06l-.292-.16c-.764-.415-1.6.42-1.184 1.185l.159.292a1.873 1.873 0 0 1-1.115 2.692l-.319.094c-.835.246-.835 1.428 0 1.674l.319.094a1.873 1.873 0 0 1 1.115 2.693l-.16.291c-.415.764.42 1.6 1.185 1.184l.292-.159a1.873 1.873 0 0 1 2.692 1.116l.094.318c.246.835 1.428.835 1.674 0l.094-.319a1.873 1.873 0 0 1 2.693-1.115l.291.16c.764.415 1.6-.42 1.184-1.185l-.159-.291a1.873 1.873 0 0 1 1.116-2.693l.318-.094c.835-.246.835-1.428 0-1.674l-.319-.094a1.873 1.873 0 0 1-1.115-2.692l.16-.292c.415-.764-.42-1.6-1.185-1.184l-.291.159A1.873 1.873 0 0 1 8.93 1.945l-.094-.319zm-2.633-.283c.527-1.79 3.065-1.79 3.592 0l.094.319a.873.873 0 0 0 1.255.52l.292-.16c1.64-.892 3.434.901 2.54 2.541l-.159.292a.873.873 0 0 0 .52 1.255l.319.094c1.79.527 1.79 3.065 0 3.592l-.319.094a.873.873 0 0 0-.52 1.255l.16.292c.893 1.64-.902 3.434-2.541 2.54l-.292-.159a.873.873 0 0 0-1.255.52l-.094.319c-.527 1.79-3.065 1.79-3.592 0l-.094-.319a.873.873 0 0 0-1.255-.52l-.292.16c-1.64.893-3.433-.902-2.54-2.541l.159-.292a.873.873 0 0 0-.52-1.255l-.319-.094c-1.79-.527-1.79-3.065 0-3.592l.319-.094a.873.873 0 0 0 .52-1.255l-.16-.292c-.892-1.64.902-3.433 2.541-2.54l.292.159a.873.873 0 0 0 1.255-.52l.094-.319z"></path>
 								<path fill-rule="evenodd" d="M8 5.754a2.246 2.246 0 1 0 0 4.492 2.246 2.246 0 0 0 0-4.492zM4.754 8a3.246 3.246 0 1 1 6.492 0 3.246 3.246 0 0 1-6.492 0z"></path>
 							</svg>
 						</span>
 						<span class="nav-link-text">General Website Settings</span>
 					</a> -->
				<!--//nav-link-->
				<!-- </li> -->



				<!-- <li class="nav-item"> -->
				<!--//Bootstrap Icons: https://icons.getbootstrap.com/ -->
				<!-- <a class="nav-link " href="<?php echo site_url('admin/quickcontact'); ?>">
 						<span class="nav-icon">
 							<img src="https://www.svgrepo.com/show/21304/logout.svg">
 						</span>
 						<span class="nav-link-text">Logout</span>
 					</a> -->
				<!--//nav-link-->
				<!-- </li> -->
				<!--//nav-item-->
			</ul>
			<!--//app-menu-->
		</nav>
		<!--//app-nav-->

	</div>
	<!--//sidepanel-inner-->
</div>


<!--//app-sidepanel-->
</header>
<!--//app-header-->

<script>
// this function used for active link css 
  $(function(){
    var current = location.pathname;
    $('#app-sidepanel li a').each(function(){
        var $this = $(this);
        // if the current path is like this link, make it active
        if($this.attr('href').indexOf(current) !== -1){
            $this.addClass('active');
        }
    })
})

</script>

