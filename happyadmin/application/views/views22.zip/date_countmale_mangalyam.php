<!DOCTYPE html>
<?php include('header.php');
if($_SESSION['user_type']==='0' &&  $_SESSION['nikah_type']=='happymangalyam')
{
include('happymangalyam_sales_super.php'); 
}

?>

<!-- Google Font: Source Sans Pro -->
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
<!-- Font Awesome -->
<link rel="stylesheet" href="<?php echo base_url() ?>assets/plugins/fontawesome-free/css/all.min.css">
<!-- DataTables -->
<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.2/css/bootstrap.css">
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.13.1/css/dataTables.bootstrap4.min.css">

<!-- Theme style -->
<link rel="stylesheet" href="<?php echo base_url() ?>assets/dist/css/adminlte.min.css">
</head>

<!-- Content Wrapper. Contains page content -->
<div class="app-wrapper">
  <div class="app-content pt-3 p-md-3 p-lg-4">
    <div class="container">
      <div class="row g-3 mb-4 align-items-center justify-content-between">
        <!-- Content Header (Page header) -->
        <section class="content-header">
          <div class="container-fluid">
            <div class="row mb-2">
              <div class="col-sm-6">
                <h1><?= $page ?></h1>
              </div>
              <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                  <li class="breadcrumb-item"><a href="#">Home</a></li>
                  <li class="breadcrumb-item active"><?= $page ?></li>
                </ol>
              </div>
            </div>
          </div><!-- /.container-fluid -->
        </section>

        <!-- Main content -->
      <div class="tab-content" id="orders-table-tab-content">
          
                    <div class="tab-pane fade show active" id="orders-all" role="tabpanel" aria-labelledby="orders-all-tab">
                        <div class="app-card app-card-orders-table shadow-sm mb-5">
                             <div class="row">
                                 
                                 <div class="col-md-6">
                            
                        
                                </div>
                             </div><br>
          
                            <div class="app-card-body" style="padding-bottom: 40px;">
                             
                                  <div class="row" style="margin-left:20px;margin-top:31px;">

                                      <form id="filterForm">
                    
                              <label style="margin-left: 3px;margin-bottom: 10px;">Male  List:</label><br> 
                                       
                              Start Date<input type="date" id="from_date" name="from_date" required style="margin-left:10px;width:20%;">&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;
                              End Date<input type="date" name="to_date"  id="to_date" required style="margin-left:10px;width:20%;">
                                                             
                                 <div class="row" style="width:0px;margin-top: -31px;">  
                                  <div class="col-md-6">

                                   <input type="submit" value="Submit"style="margin-top: 0px;width: 80px;margin-left: 630px;height: 30px;" id="submit">
                                </div>

                    </div><br> 

                    <div id="customerData">
       
    </div><br>
              <button type="button" class="btn btn-success" id="exportto_malemangalyam" style="display: none;">Export to Excel</button>
                     </div>   </div>


           </div>
                    
                     </form>

   
                  
                 
                </div>
                <!-- /.card-body -->
        
              <!-- /.card -->
            </div>
            <!-- /.col -->
          </div>
          <!-- /.row -->
        </div>
        <!-- /.container-fluid -->

        <!-- /.content -->
       
      </div>
    </div>
  </div>
  
  <?php include('footer.php'); ?>
  <!-- jQuery -->

        <script>
        var from_date,to_date;
        $(document).ready(function() {
        $('#filterForm').submit(function(e) {
        e.preventDefault();
        from_date = $('#from_date').val();   
        to_date = $('#to_date').val();
        var formData = $(this).serialize();
        $.ajax({
        url: '<?php echo base_url('admin/get_date_male_mangalyam'); ?>',
        method: 'post',
        data: formData,
        dataType: 'html',
        success: function(data) {
        $('#customerData').html(data);
        $("#exportto_malemangalyam").show();
        }
        });
        });
        
        $('#exportto_malemangalyam').click(function() {
        from_date = $('#from_date').val();
        to_date = $('#to_date').val();
        $.ajax({
        type: 'POST',
        url: '<?= base_url() ?>admin/exportToExcel_male_datemangalyam', // Check this URL path
        data: {
        from_date:from_date,
        to_date:to_date
        },
        success: function(response) 
        {
        if (response.success) 
        {         
        
        var cacheBuster = new Date().getTime();
        var downloadUrl = '<?= base_url() ?>upload/male_list_datemangalyam.xlsx?cb=' + cacheBuster;
        window.location.href = downloadUrl;
        
        } 
        else 
        {                               
        var cacheBuster = new Date().getTime();
        var downloadUrl = '<?= base_url() ?>upload/male_list_datemangalyam.xlsx?cb=' + cacheBuster;
        window.location.href = downloadUrl;                
        }
        },
        error: function(error)
        {
        alert('Error exporting Excel file');
        }
        });
        });
        
        });
        
        </script>


    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
    <script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js" defer></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/script.js/2.0.2/script.min.js"></script>

    
  </body>

  </html>