<!DOCTYPE html>
<?php include('header.php'); 
 
if($_SESSION['user_type']==='3')
{
 include('menusales_mangalyam.php');
}

if($_SESSION['user_type'] === '7') 
{
include('menuchatsupport_mangalyam.php');
}


?>

<link rel="stylesheet" href="<?php echo base_url() ?>assets/plugins/datatables-bs4/css/dataTables.bootstrap4.min.css">
<link rel="stylesheet" href="<?php echo base_url() ?>assets/plugins/datatables-responsive/css/responsive.bootstrap4.min.css">

<link rel="stylesheet" href="<?php echo base_url() ?>assets/css/custom.css">

<style type="text/css">   
.asm::after{
        color:transparent;
}
</style>
<div class="app-wrapper">

                <div class="app-content pt-3 p-md-3 p-lg-4">
                <div class="container-xl">

                <div class="row g-3 mb-4 align-items-center justify-content-between">
                <div class="col-auto">
                <h6 style="color:darkgrey;">Today followup</h1>
                </div>

                <!-- Main content -->
                <section class="content">
                <div class="container-fluid">
                <div class="row">
                <div class="col-12">

                <div class="card">              
                <!-- /.card-header -->
                <div class="card-body">
                <h1 class="app-page-title mb-0">Today Followup
           
                </h1>
              
                <?php $todaydate =date('Y-m-d');?>
                <?php $todaydate2 = date('d-m-Y',strtotime($todaydate));?>
                <?php $user_id=$this->session->userdata('user_id_admin');?>
               
            <?php $today = $this->db->select('tbl_registration.*,tbl_followup.id as fid,tbl_followup.status as fstatus,tbl_followup.message as fmessage,tbl_followup.fdate,tbl_followup.login_id')
                          ->from('tbl_followup')->join('tbl_registration','tbl_registration.id=tbl_followup.uid')
                          ->where('fdate',$todaydate2)->where('login_id',$user_id)
                          ->where('tbl_followup.delete_status','Active')
                          ->where('tbl_registration.status','1')
                          ->where('tbl_registration.hmangalyam','1')
                          ->get()->result_array();?>

            <?php $todayfollow = $this->db->select('tbl_registration.*,tbl_followup.id as fid,tbl_followup.status as fstatus,tbl_followup.message as fmessage,tbl_followup.fdate,tbl_followup.login_id')
                                  ->from('tbl_followup')->join('tbl_registration','tbl_registration.id=tbl_followup.uid')
                                  ->where('fdate',$todaydate2)->where('login_id',$user_id)
                                  ->where('tbl_followup.delete_status','Active')
                                  ->where('tbl_registration.status','1')
                                  ->where('tbl_registration.hmangalyam','1')
                                  ->get();?>
                          
                          
                <h6 style="float: right;">Total records :
                <?php echo $todayfollow->num_rows(); ?></h6>
                </div>
                <br><br>

                <div class="table-scroll-y my-custom-scrollbar" style="height: 645px;">
                <table id="example" class="table table-bordered">
                <thead style="background-color: grey;border:1px solid black;">
                <tr>
                <th style="color:#fff;">HM ID</th>
                <th style="color:#fff;">Action</th>
                <th style="color:#fff;">Name/Age/Gender</th>
                <th style="color:#fff;">Address</th>
                <th style="color:#fff;">Location</th>

                </tr>
                </thead>
                <tbody>
                <?php $j=1;?>
                <?php foreach($today as $td) 
                {

                ?>
                <tr style="border: 1px solid black;" id="row-1">
                <td style="padding-top: 85px;">
                <li style="list-style-type:none;">
                <a class="asm" href="#"
                data-id="<?php echo $td['id'];?>"
                style="color:#15a362;" data-replace="Enter message">
                Enter Message</a>
                </li>
                <hr>
                <li style="list-style-type:none;">
                <div>
                <span>
                <?php echo $td['happynikah_id'];?>
                </span>
                </div>
                </li>
                <hr>
                <li style="list-style-type:none;">
                <div>
                <span>
            
            
                <?php if($td['reg_through']=='0')
                {?>
                <?php echo "Website";?>
                <?php }?>
                
                <?php if($td['reg_through']=='1')
                {?>
                <?php echo "Admin";?>
                <?php }?>
                
                <?php if($td['reg_through']=='2')
                {?>
                <?php echo "Mobile";?>
                <?php }?>

                </span>
                </div>
                </li>
                <hr>
                <li style="list-style-type:none;">
                
                    <a data-id="<?php echo $td['fid'];?>"  class="closefollowup">Close Follow up</a>
                </li>
                </td>
                <td style="padding-top: 50px;">

                <li style="list-style-type:none;">
                              
                <form method="post" action="<?= base_url() ?>admin/search_profiles">
                <div class="form-group">
                
                <input type="hidden" id="inputName" class="form-control" name="search_profile"  value="<?php echo $td['happynikah_id'] ?>"  required >
                
                </div>
                </div>
                <div class="col-lg-6">
                <!-- <div class="form-group"> -->

                <label for="inputName">&nbsp;</label>
               
                <button type="submit" name="search_profile_btn" class="btn btn-success" id="search_button"
                
                style="background: transparent;width: 114px;margin-left: -15px;color: #378fd3;">
                    
                    Basic Details
                </button>
                </form>
                
                </li>
            
                <hr>
                <li style="list-style-type:none;">
                <a class="asms" data-id="<?php echo $td['id'];?>"
                href="#" style="color:#15a362;" data-replace="Delete">Delete
                </a>
                </li>
                <hr>
                <li style="list-style-type:none;">
                    
                <a  class="bbb"  data-id="<?php echo $td['id'];?>" onclick="blockprofile();"  data-replace="Block Profile">Block</a>
                </li>
                           
                <hr>
                
                </td>
                <td style="padding-top: 85px;">
                <li style="list-style-type:none;">
                <div>
                <span>
              
                <?php echo $td['name'];?>
                </span>
                <br>
                <span>
             
                 <?php echo $td['age'];?>
                </span>
                <br>
                <span>
              
               <?php 
               if ($td['gender'] == '1')
                {
                $gender = "Male";
                }
                else
                {
                $gender = "Female";
                }
                ?>
               
                 <?php echo $gender;?>
                </span>
                </div>

                </li>
                <hr>
                <li style="list-style-type:none;">
                <div>
                <span style="background-color: greenyellow;">
                <!-- 25-01-2023 10:00 AM -->
                Reg Date:
                <?php $old_date= $td['reg_date'];?>
                
                <?php $new_date = date("d-m-Y", strtotime($old_date));?>

                <?php echo $new_date;?>
                </span>
                </div>
                </li>
                <hr>
                <li style="list-style-type:none;">
                <div>
                <span>
                <?php
                if ($td['status'] == '0') 
                {
                $status = "Pending";
                } 
                elseif ($td['status'] == '1')
                {
                $status = "Approved";
                } 
                elseif ($td['status'] == '2') 
                {
                $status = "Rejected";
                } 
                elseif ($td['status'] == '3') 
                {
                $status = "Deleted";
                }
                ?>
                <button class="btn btn-danger" style="color:white;">
                <!-- Paid -->
                <?php echo $status;?> 
                </button>
                </span>
                </div>
                </li>
                </td>
                <td>
                <li style="list-style-type:none;">
                <div>
                <span>
                <b> Followup Comments Details</b>
                <hr>
                </span>
                </div>
                </li>
                <li style="list-style-type:none;">
                <div>
                <span style="color: red;">

                    
                <b><?php echo $j++;?>)

                <?php
                if ($td['fstatus'] == 'Ring')
                {
                $tbl_status = "Ring Not Response(RNR)";
                ?>
                <?php echo $tbl_status;
                }?>
                <?php
                if ($td['fstatus'] == 'Add comments')
                {
                $tbl_status = "Add comments";
                ?>
                <?php echo $tbl_status;
                }?>

                <?php
                if ($td['fstatus'] == 'Interested')
                {
                $tbl_status = "Interested/Follow up";
                ?>
                <?php echo $tbl_status;
                }?>
                <?php
                if ($td['fstatus'] == 'busy')
                {
                $tbl_status = "Busy/call back";
                ?>
                <?php echo $tbl_status;
                }?>
                <?php
                if ($td['fstatus'] == 'Switched')
                {
                $tbl_status = "Switched off";
                ?>
                <?php echo $tbl_status;
                }?>


      
                </b>
                </span>
                <br>
                <div style="background-color:#F5F6FE;">

                <p> 
               <!--  Ring but not respond expiry date informed through watsup- 25-01-2023 10:00 AM -->
                <?php $msg=$td['fmessage'];?>
                <?php echo $msg;?>
                </p>
                </div>
                <br>
                <span style="color: red;">
                <b> 
                <?php $old_date5= $td['fdate'];?>         
                

                <?php echo $old_date5;?>

                Followup</b>
                </span>
                <br>
                <br>
                <br>
        
        
                </div>
                </li>
                </td>
                <td>
                <li style="list-style-type:none;">
                <br>
                <br><br><br><br><br>
                <div>
                <span>

               <?php echo $td['native_place'];?>
                </span>
                </div>
                </li>
                </td>
                </tr>
                <!-- next tr -->
                
                </tbody>
                <?php }?>
                </table>

                </div>
                <!-- /.card-body -->
                </div>
                <!-- /.card -->
                </div>
                <!-- /.col -->
                </div>
                <!-- /.row -->
                </div>
                <!-- /.container-fluid -->
                </section>
                <!-- /.content -->
                </div>
                <!-- /.content-wrapper -->


     <form id="contactdelete" method="post" action="<?php echo base_url(); ?>admin/profile_delete" onsubmit="setTimeout(function(){window.location.reload();},700);">
        <div class="modal fade" id="deletecnt" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
        <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle">
          Profile Delete</h5>

       
        <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
        <span aria-hidden="true">&times;</span>
        </button>
        </div>
        <div class="modal-body">  

        <div class="mb-3">
        <label for="inputName" class="form-label">Status</label>
        <select id="reason_status" class="form-control custom-select" name="reason_status" required>
        <option value="" selected disabled>--Please Select Status--</option>
        <option value="Profile Contains Abusive Contents(Vulgar or racist)">Profile Contains Abusive Contents(Vulgar or racist)</option>
        <option value="Vulgar/Invalid Photos">Vulgar/Invalid Photos</option>
        <option value="Invalid Data">Invalid Data</option>
        <option value="Invalid Contact Details">Invalid Contact Details</option>
        <option value="Contact number/link mentioned in restricted fields">Contact number/link mentioned in restricted fields</option>
        <option value="Multiple/Duplicate profiles">Multiple/Duplicate profiles</option>
        <option value="Fake Profiles">Fake Profiles</option>
        <option value="Abnormal Activity Found">Abnormal Activity Found</option>
        <option value="Marriage Fixed">Marriage Fixed</option>
        <option value="Minor Profiles">Minor Profiles</option>
        <option value="Others">Others</option>
        </select>
        </div>

        <div class="mb-3">
        <label for="inputName" class="form-label">Message</label>
        <textarea id="message" class="form-control"  required  name="message" style="height:100px;"></textarea>
        <!--(<?php echo $this->session->userdata('user_id_admin');?>)-->
        
       
        </div>
        </div>
        <div class="modal-footer">

              <input type="hidden" name="user_id" id="user_id">
       <input type="hidden" name="session" 
       value="<?php echo $this->session->userdata('user_id_admin');?>" id="session">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close
        </button>
       <!--  <button type="submit" class="btn btn-primary">Save changes</button> -->

       <button type="submit" class="btn btn-primary"  id="btn_update" style="color:#fff;">Save changes</button>

        </div>
       
        </div>
        </div>
        </div>
        </div>
        </form>



         <!--Payment Request-->
        
        <form id="contact" method="post" action="<?php echo base_url(); ?>admin/payment_request" onsubmit="setTimeout(function(){window.location.reload();},700);">
        <div class="modal fade" id="postpone" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
        <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle">Payment Request</h5>
        <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
        <span aria-hidden="true">&times;</span>
        </button>
        </div>
        
        <input type="hidden" name="payment_id" id="payment_id">
        
        <div class="modal-body">
        <div class="mb-3">
        <label for="inputName" class="form-label" style="color:black;"><b>Plan Type</b></label>
        <select id="plantype" class="form-control custom-select" 
        name="plantype">
        <option value="">--select--</option>
        <option value="normal">Normal</option>
        <option value="premium">Premium</option>
        
        </select>
        </div>
        <div class="mb-3">
        <label for="inputName" class="form-label" style="color: black;">
        <b>Membership Plan</b></label>
        <select id="membership_plan" class="form-control custom-select" name="membership_plan">
        <option value="">--select--</option>
        <option value="1">Bronze</option>
        <option value="2">Diamond</option>
        <option value="3">Crown</option>
        <option value="4">Master</option>
        <option value="5">Assisted</option>
        <option value="6">Assited Pro</option>
        <!--<option value="">Elite</option>-->
        </select>
        </div>
        <div class="mb-3">
        <label for="inputName" class="form-label" style="color: black;">
        <b>PostPone Date</b>
        </label>
        <input type="text" name="postpone_date" id="postpone_date" class="form-control" required>
        </div>
        
        <div class="mb-3">
        <label for="inputName" class="form-label" style="color: black;">
        <b>Message</b></label>
        <textarea id="message" class="form-control"  name="message" required style="height:100px;"></textarea>
      
      
       </div>
        </div>
        <div class="modal-footer">
        
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary" style="color:#fff;">Sumbit</button>
        </div>
        </div>
        </div>
        </div>
        </form>
        

    <!-- modal for block -->
        <div class="modal fade" id="block_" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
        <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLongTitle">Block Profile</h5>
        <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
        <span aria-hidden="true">&times;</span>
        </button>
        </div>
        
         <form id="contact" method="post" action="<?php echo base_url(); ?>admin/block_profile" onsubmit="setTimeout(function(){window.location.reload();},700);">
             
             
        <div class="modal-body">
        <div class="mb-3">

        <label for="inputName" class="form-label">Status</label>
        <select id="block_status" class="form-control custom-select" name="block_status" required>
        <option value="" selected disabled>--Please Select Status--</option>
        <option value="Profile Contains Abusive Contents ( Vulgar or racist )">Profile Contains Abusive Contents ( Vulgar or racist )</option>
        <option value="Vulgar / Invalid Photos">Vulgar / Invalid Photos </option>
        <option value="Invalid Data">Invalid Data </option>
        <option value="Invalid Contact Details">Invalid Contact Details</option>
        <option value="Contact number / link mentioned in restricted fields">Contact number / link mentioned in restricted fields </option>
        <option value="Multiple / Duplicate profiles">Multiple / Duplicate profiles </option>
        <option value="Fake Profiles">Fake Profiles</option>
        <option value="Abnormal Activity Found">Abnormal Activity Found </option>
        <option value="Marriage Fixed">Marriage Fixed</option>
        <option value="Minor Profiles">Minor Profiles</option>
        <option value="Others">Others</option>
        </select>

        </div>

        <div class="mb-3">
        <label for="inputName" class="form-label">Message</label>
        <textarea id="block_description" class="form-control"  required  name="block_description" style="height:100px;"></textarea>
        </div>
        </div>
        <div class="modal-footer">
            
            
         <input type="hidden" name="user_id2" id="user_id2">
       <input type="hidden" name="session" 
       value="<?php echo $this->session->userdata('user_id_admin');?>" id="session">
       
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary btnblk_" id="btnblk_" style="color:#fff;">Save changes</button>
        </div>
        </div>
        </div>
         </form>
        </div>
        <!--End modal block-->
        
        
        
        
        <form id="contact" method="post" action="<?php echo base_url(); ?>admin/closetodayfollowup"  onsubmit="setTimeout(function(){window.location.reload();},800);">
           <div class="modal fade" id="deleteEmpModal" tabindex="-1" role="dialog" aria-labelledby="deleteModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
        <div class="modal-header">
        
        <h5 class="modal-title" id="exampleModalLongTitle">
        Are You Sure want to close Followup ?
        
        <!--  <?php echo $this->session->userdata('user_id_admin');?>  -->
        
        </h5>
        <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
        <span aria-hidden="true">&times;</span>
        </button>
        </div>
        
        
        <input type="hidden" name="user_id2" id="user_id2" value="<?php echo $td['fid'];?>">
        
        <input type="hidden" name="login_id" 
        value="<?php echo $this->session->userdata('user_id_admin');?>" id="login_id">
        
        <div class="modal-body">
        
        <div class="mb-3">
        <label for="inputName" class="form-label">Reason</label>
        <select id="reason_status" class="form-control custom-select" name="reason_status" required>
        <option value="" selected disabled>---Please Select Reason---</option>
        <option value="Profile Contains Abusive Contents(Vulgar or racist)">Profile Contains Abusive Contents(Vulgar or racist)</option>
        <option value="Vulgar/Invalid Photos">Vulgar/Invalid Photos</option>
        <option value="Invalid Data">Invalid Data</option>
        <option value="Invalid Contact Details">Invalid Contact Details</option>
        <option value="Contact number/link mentioned in restricted fields">Contact number/link mentioned in restricted fields</option>
        <option value="Multiple/Duplicate profiles">Multiple/Duplicate profiles</option>
        <option value="Fake Profiles">Fake Profiles</option>
        <option value="Abnormal Activity Found">Abnormal Activity Found</option>
        <option value="Marriage Fixed">Marriage Fixed</option>
        <option value="Minor Profiles">Minor Profiles</option>
        <option value="Others">Others</option>
        </select>
        </div>
        
        <div class="mb-3">
        <label for="inputName" class="form-label" style="color: black;">
        <b>Message</b></label>
        <textarea id="message" class="form-control" required name="message" style="height:100px;"></textarea>
        </div>
        </div>
        <div class="modal-footer">
        
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary" style="color:#fff;">Sumbit</button>
        </div>
        </div>
        </div>
        </div>
        </form>


                <!-- Modal for enter message -->
                <div class="modal fade" id="enterMessage" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                <div class="modal-header">

            
                <h5 class="modal-title" id="exampleModalLongTitle">Enter Message

                <!--  <?php echo $this->session->userdata('user_id_admin');?>  -->
                
                </h5>
                <button type="button" class="close" data-bs-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
                </button>
                </div>

                 <form id="contact" method="post" action="<?php echo base_url(); ?>admin/today_followup_register" 
                 onsubmit="setTimeout(function(){window.location.reload();},700);">

               
                <input type="hidden" name="eventId" id="eventId"/>
                
                <div class="modal-body">
                <div class="mb-3">
                <label for="inputName" class="form-label">Status</label>
                <select id="status" class="form-control custom-select" name="status" required  style="padding-bottom: 2px;">
                <option value="" selected disabled>--Please Select Status--</option>
               
                <option value="Interested">Interested / Follow up</option>
                <option value="Ring">Ring not respond (RNR) </option>
                <option value="busy">Busy / call back</option>
                <option value="Add comments">Add Comments</option>
                <option value="Switched off">Switched off</option>
                <option value="Whatsapp connect">Whatsapp connect</option>
                 <option value="Marriage Fixed">Marriage Fixed</option>
                 <option value="Not Interested">Not Interested</option>
                 
                </select>
                </div>


                <div class="mb-3" id="follow">
                <label for="setting-input-3" class="form-label">Follow up date</label>          
                <input type="text" id="noSunday" name="fdate" required>
                </div>

                <div class="mb-3">
                <label for="inputName" class="form-label">Message</label>
                <textarea id="message" class="form-control"  rows="4" cols="50"  name="message" required style="height:100px;"></textarea>
                <!--&nbsp; &nbsp; &nbsp; &nbsp;Best Regards-->
                <?php $nh=$this->db->select('*')->from('tbl_registration')
                ->where('phone',$td['phone'])
                ->get()->result_array();?>
                <?php  foreach ($nh as  $value) {
                ?>

                <?php $k5=$value['name'];?>
                <!--<?php echo  $k5;?>-->
                <?php }?>   
             
               
                </div>
                </div>
                <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="submit"  id="save-project-btn3"  name="register" class="btn btn-primary" style="color:#fff;">Save changes</button>
                
                </div>
                </div>
                </div>
                </form>
                </div>


            <!-- end modal for Interest details  -->
            <?php include('footer.php'); ?>

            <script type="text/javascript">
            $(function() {
            $("a[class='asm']").click(function() {
            $("#enterMessage").modal("show");
            const eventId = $(this).attr('data-id');
            const field = $('#eventId');
            field.val(eventId);
            console.log(field[0]);     
            return false;
            });
            });


            $(document).ready(function () 
            {   
            
            $("#noSunday").datepicker({ 
            beforeShowDay: noSunday,
            dateFormat: 'dd-mm-yy',
            maxDate: "+2d",
            minDate:0
            });

            function noSunday(date)
            { 
            var day = date.getDay(); 
            return [(day > 0), '']; 
            }; 

            $("#noSunday2").datepicker({ 
            beforeShowDay: noSunday2,
            dateFormat: 'dd-mm-yy',
            maxDate: "+1d",
            minDate:0
            });

            function noSunday2(date)
            { 
            var day = date.getDay(); 
            return [(day > 0), '']; 
            }; 
            });
                     
            $(function() 
            {
            $("a[class='bbb']").click(function()
            {
            $("#block_").modal("show");
            
            const user_id2 = $(this).attr('data-id');
            const field = $('#user_id2');
            field.val(user_id2);
            console.log(field[0]);
            return false;
          
            });
            });

            $(function() 
            {
            $("a[class='asms']").click(function()
            {
            // $("#delete").modal("show");
            $("#deletecnt").modal("show");
            const user_id = $(this).attr('data-id');
            const field = $('#user_id');
            field.val(user_id);
            console.log(field[0]);
            return false;
            });
            });

           $(function() 
            {
            $("a[class='closefollowup']").click(function()
            {
         
            var empId = $(this).data('id');            
            $('#deleteEmpModal').modal('show');
            $('#deleteEmpId').val(empId);
            
            const user_id2 = $(this).attr('data-id');
            const field = $('#user_id2');
            field.val(user_id2);
            console.log(field[0]);
            return false;
            
            });
            });

            $('#deleteEmpForm').on('submit',function(){
            var empId = $('#deleteEmpId').val();
            $.ajax({
            type : "POST",
            url  : "delete_data",
            dataType : "JSON",  
            data : {id:empId},
            success: function(data){
            location.reload();
            $("#"+empId).remove();
            $('#deleteEmpId').val("");
            $('#deleteEmpModal').modal('hide');
            // listEmployee();
            }
            });
            return false;
            });
                        
            function blockprofile(){
            var url = '<?php echo base_url() ?>'
            var id = $('#user_id').val();
            var emp_id= $('#session').val();
            var phone=$('#phone').val();
            
            $('#btnblk_' + id).click(function() {
            var block_description=$('#block_description').val();
            var block_status=$('#block_status').val();
            $("#block_").modal('hide');
            setTimeout(function(){
            location.reload(); 
            }, 1000);
            $.ajax({
            dataType: 'json',
            type: 'POST',
            url: url + 'admin/block_profile',
            data: {
            id: id,
            emp_id: emp_id,
            phone:phone,
            block_description:block_description,
            block_status:block_status
            },
            
            success: function(result4) {
            
            },
            })
            });
            }
                      
            $(function() 
            {
            $("a[class='pp']").click(function() 
            {
            $("#postpone").modal("show");
            // var eventId = $(this).data('id');
            const payment_id = $(this).attr('data-id');
            const field = $('#payment_id');
            field.val(payment_id);
            console.log(field[0]);          
            // $('#idHolder').html( eventId );
            return false;
            });
            });
          
            $("#noSunday").datepicker({ 
            beforeShowDay: noSunday,
            dateFormat: 'dd-mm-yy',
            maxDate: "+4d",
            minDate:0
            });

            function noSunday(date)
            { 
            var day = date.getDay(); 
            return [(day > 0), '']; 
            }; 

            $("#noSunday2").datepicker({ 
            beforeShowDay: noSunday2,
             dateFormat: 'dd-mm-yy',
             
            maxDate: "+4d",
            minDate:0
            });

            function noSunday2(date)
            { 
            var day = date.getDay(); 
            return [(day > 0), '']; 
            }; 
                            
            $("#postpone_date").datepicker({ 
            beforeShowDay: postpone_date,
            dateFormat: 'dd-mm-yy',
            maxDate: "+3d",
            minDate:0
            });

            function postpone_date(date)
            { 
            var day = date.getDay(); 
            return [(day > 0), '']; 
            };          

            </script>

            <link href=
            'https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/themes/ui-lightness/jquery-ui.css'
            rel='stylesheet'>

            <script src=
            "https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js">
            </script>

            <script src=
            "https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js">
            </script>

            <!-- jQuery -->
     
            
            <!-- DataTables  & Plugins -->
            <script src="<?php echo base_url() ?>assets/plugins/datatables/jquery.dataTables.min.js"></script>
            <script src="<?php echo base_url() ?>assets/plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
            <script src="<?php echo base_url() ?>assets/plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
            <script src="<?php echo base_url() ?>assets/plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
           

            </html>