		<div id="app-sidepanel" class="app-sidepanel sidepanel-hidden">
		<div id="sidepanel-drop" class="sidepanel-drop"></div>
		<div class="sidepanel-inner d-flex flex-column">
		<a href="#" id="sidepanel-close" class="sidepanel-close d-xl-none">&times;</a>


		<div class="app-branding">
		<a class="app-logo" href="<?php echo site_url('admin/dashboard_happymangalyam'); ?>"><img class="logo-icon me-2" src="<?php echo base_url(); ?>assets/images/hmgradient.png" 
		alt="logo"><span class="logo-text" style="font-family:Comic Sans MS, Comic Sans, cursive;color:#ef2857;font-size: 14px;">Happy Mangalyam</span></a>

		</div>

		<style type="text/css">
		.app-branding .logo-icon {
		width: 88%;
		height: 154px;
		margin-top: -45px;
		}
		</style>		



		<!--//app-branding-->
		<nav id="" class="app-nav app-nav-main flex-grow-1">
		<ul class="app-menu list-unstyled accordion" id="menu-accordion">
		<li class="nav-item">
		<!--//Bootstrap Icons: https://icons.getbootstrap.com/ -->
		<a class="nav-link " href="<?php echo site_url('admin/dashboard_happymangalyam'); ?> ">
		<span class="nav-icon">
		<svg width="1em" height="1em" viewBox="0 0 16 16" class="bi bi-house-door" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
		<path fill-rule="evenodd" d="M7.646 1.146a.5.5 0 0 1 .708 0l6 6a.5.5 0 0 1 .146.354v7a.5.5 0 0 1-.5.5H9.5a.5.5 0 0 1-.5-.5v-4H7v4a.5.5 0 0 1-.5.5H2a.5.5 0 0 1-.5-.5v-7a.5.5 0 0 1 .146-.354l6-6zM2.5 7.707V14H6v-4a.5.5 0 0 1 .5-.5h3a.5.5 0 0 1 .5.5v4h3.5V7.707L8 2.207l-5.5 5.5z" />
		<path fill-rule="evenodd" d="M13 2.5V6l-2-2V2.5a.5.5 0 0 1 .5-.5h1a.5.5 0 0 1 .5.5z" />
		</svg>
		</span>
		<span class="nav-link-text">Dashboard</span>
		</a>
		<!--//nav-link-->
		</li>
		<!--//nav-item-->
		<!--<li class="nav-item">

		<a class="nav-link" href="docs.html">
		<span class="nav-icon">
		<svg width="1em" height="1em" viewBox="0 0 16 16" class="bi bi-folder" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
		<path d="M9.828 4a3 3 0 0 1-2.12-.879l-.83-.828A1 1 0 0 0 6.173 2H2.5a1 1 0 0 0-1 .981L1.546 4h-1L.5 3a2 2 0 0 1 2-2h3.672a2 2 0 0 1 1.414.586l.828.828A2 2 0 0 0 9.828 3v1z"/>
		<path fill-rule="evenodd" d="M13.81 4H2.19a1 1 0 0 0-.996 1.09l.637 7a1 1 0 0 0 .995.91h10.348a1 1 0 0 0 .995-.91l.637-7A1 1 0 0 0 13.81 4zM2.19 3A2 2 0 0 0 .198 5.181l.637 7A2 2 0 0 0 2.826 14h10.348a2 2 0 0 0 1.991-1.819l.637-7A2 2 0 0 0 13.81 3H2.19z"/>
		</svg>
		</span>
		<span class="nav-link-text">Docs</span>
		</a>
		</li> -->

		<!--//nav-item-->
		<li class="nav-item">
		<!--//Bootstrap Icons: https://icons.getbootstrap.com/ -->
		<a class="nav-link" href="<?php echo site_url('admin/search_profiles') ?>">
		<span class="nav-icon">
		<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-search-heart" viewBox="0 0 16 16">
		<path d="M6.5 4.482c1.664-1.673 5.825 1.254 0 5.018-5.825-3.764-1.664-6.69 0-5.018Z" />
		<path d="M13 6.5a6.471 6.471 0 0 1-1.258 3.844c.04.03.078.062.115.098l3.85 3.85a1 1 0 0 1-1.414 1.415l-3.85-3.85a1.007 1.007 0 0 1-.1-.115h.002A6.5 6.5 0 1 1 13 6.5ZM6.5 12a5.5 5.5 0 1 0 0-11 5.5 5.5 0 0 0 0 11Z" />
		</svg>
		</span>
		<span class="nav-link-text">Search Profile</span>
		</a>
		<!--//nav-link-->
		</li>

              
            
            

		<li class="nav-item">
		<!--//Bootstrap Icons: https://icons.getbootstrap.com/ -->
		<a class="nav-link" href="<?php echo site_url('admin/register_mangalyam'); ?>">
		<span class="nav-icon">
		<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" 
		class="bi bi-pencil-square" viewBox="0 0 16 16">
		<path d="M15.502 1.94a.5.5 0 0 1 0 .706L14.459 3.69l-2-2L13.502.646a.5.5 0 0 1 .707 0l1.293 1.293zm-1.75 2.456-2-2L4.939 9.21a.5.5 0 0 0-.121.196l-.805 2.414a.25.25 0 0 0 .316.316l2.414-.805a.5.5 0 0 0 .196-.12l6.813-6.814z" />
		<path fill-rule="evenodd" d="M1 13.5A1.5 1.5 0 0 0 2.5 15h11a1.5 1.5 0 0 0 1.5-1.5v-6a.5.5 0 0 0-1 0v6a.5.5 0 0 1-.5.5h-11a.5.5 0 0 1-.5-.5v-11a.5.5 0 0 1 .5-.5H9a.5.5 0 0 0 0-1H2.5A1.5 1.5 0 0 0 1 2.5v11z" />
		</svg>
		</span>
		<span class="nav-link-text">User Registration</span>
		</a>
		<!--//nav-link-->
		</li>
				
			
           

             <li class="nav-item has-submenu">
            <!--//Bootstrap Icons: https://icons.getbootstrap.com/ -->
            <a class="nav-link submenu-toggle" href="#" data-bs-toggle="collapse" data-bs-target="#submenu-1" aria-expanded="true" aria-controls="submenu-1">
            <span class="nav-icon">
            <!--//Bootstrap Icons: https://icons.getbootstrap.com/ -->
            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-pen" viewBox="0 0 16 16">
            <path d="m13.498.795.149-.149a1.207 1.207 0 1 1 1.707 1.708l-.149.148a1.5 1.5 0 0 1-.059 2.059L4.854 14.854a.5.5 0 0 1-.233.131l-4 1a.5.5 0 0 1-.606-.606l1-4a.5.5 0 0 1 .131-.232l9.642-9.642a.5.5 0 0 0-.642.056L6.854 4.854a.5.5 0 1 1-.708-.708L9.44.854A1.5 1.5 0 0 1 11.5.796a1.5 1.5 0 0 1 1.998-.001zm-.644.766a.5.5 0 0 0-.707 0L1.95 11.756l-.764 3.057 3.057-.764L14.44 3.854a.5.5 0 0 0 0-.708l-1.585-1.585z" />
            </svg>
            </span>
            <span class="nav-link-text">Creation</span>
            <span class="submenu-arrow">
            <svg width="1em" height="1em" viewBox="0 0 16 16" class="bi bi-chevron-down" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
            <path fill-rule="evenodd" d="M1.646 4.646a.5.5 0 0 1 .708 0L8 10.293l5.646-5.647a.5.5 0 0 1 .708.708l-6 6a.5.5 0 0 1-.708 0l-6-6a.5.5 0 0 1 0-.708z"></path>
            </svg>
            </span>
            <!--//submenu-arrow-->
            </a>
            <!--//nav-link-->
            <div id="submenu-1" class="collapse submenu submenu-1" data-bs-parent="#menu-accordion">
            <ul class="submenu-list list-unstyled">
            <li class="submenu-item"><a class="submenu-link" style="text-decoration: none;" href="<?php echo site_url('admin/tdycreation_mangalyam'); ?>">Today's Creation
            </a></li>
            
            </ul>
            <ul class="submenu-list list-unstyled">
            <li class="submenu-item"><a class="submenu-link" style="text-decoration: none;" href="<?php echo site_url('admin/totalcreation_mangalyam'); ?>">Total Creation
            </a></li>
            
            </ul>
            </div>
            </li>
						      
                 
		
						
							
					 
						
			
			</ul>
			<!--//app-menu-->
		</nav>
		<!--//app-nav-->

	</div>
	<!--//sidepanel-inner-->
</div>


<!--//app-sidepanel-->
</header>
<!--//app-header-->

<script>
// this function used for active link css 
  $(function(){
    var current = location.pathname;
    $('#app-sidepanel li a').each(function(){
        var $this = $(this);
        // if the current path is like this link, make it active
        if($this.attr('href').indexOf(current) !== -1){
            $this.addClass('active');
        }
    })
})

</script>

